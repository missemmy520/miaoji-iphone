import Foundation

enum FoodType: String, Codable, CaseIterable, Identifiable {
    case dry, wet, treat, other
    var id: String { rawValue }
    var title: String {
        switch self {
        case .dry: return "干粮"
        case .wet: return "湿粮"
        case .treat: return "猫条"
        case .other: return "其他"
        }
    }
}

enum StoolCondition: String, Codable, CaseIterable, Identifiable {
    case normal, dry, soft, diarrhea, other
    var id: String { rawValue }
    var title: String {
        switch self {
        case .normal: return "正常"
        case .dry: return "偏干"
        case .soft: return "偏软"
        case .diarrhea: return "腹泻"
        case .other: return "其他"
        }
    }
}
