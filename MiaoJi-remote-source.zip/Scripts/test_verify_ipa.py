"""Tests use synthetic ZIP/Mach-O fixtures, never installable app binaries."""
import importlib.util
from pathlib import Path
import plistlib
import struct
import tempfile
import unittest
from zipfile import ZipFile

spec = importlib.util.spec_from_file_location('verify_ipa', Path(__file__).with_name('verify-ipa.py'))
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

class VerifyIPATests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory(prefix='miaoji-verifier-tests-')
        self.addCleanup(self.folder.cleanup)
        self.root = Path(self.folder.name)
    def make(self, platform=2, family=(1,), extra=None):
        info = {'CFBundleSupportedPlatforms':['iPhoneOS'], 'UIDeviceFamily':list(family),
                'CFBundleIdentifier':'com.personal.miaoji','CFBundleExecutable':'MiaoJi','CFBundleShortVersionString':'0.5'}
        header = struct.pack('<8I',0xFEEDFACF,0x0100000C,0,2,1,24,0,0)
        build_command = struct.pack('<6I',0x32,24,platform,0x110000,0x1a0000,0)
        path = self.root/'synthetic-fixture.zip'
        with ZipFile(path,'w') as archive:
            archive.writestr('Payload/MiaoJi.app/Info.plist',plistlib.dumps(info))
            archive.writestr('Payload/MiaoJi.app/MiaoJi',header+build_command)
            if extra: archive.writestr(extra,b'fixture')
        return path
    def test_expected_device_structure(self):
        self.assertEqual(module.verify(self.make())['CFBundleIdentifier'],'com.personal.miaoji')
    def test_reject_simulator_even_if_plist_claims_device(self):
        with self.assertRaisesRegex(ValueError,'simulator'): module.verify(self.make(platform=7))
    def test_reject_ipad_only_app(self):
        with self.assertRaisesRegex(ValueError,'support iPhone'): module.verify(self.make(family=(2,)))
    def test_reject_traversal(self):
        with self.assertRaisesRegex(ValueError,'Invalid archive path'): module.verify(self.make(extra='../outside'))
    def test_reject_source_zip(self):
        path = self.root/'source.zip'
        with ZipFile(path,'w') as archive: archive.writestr('Package.swift','// source only')
        with self.assertRaisesRegex(ValueError,'Payload'): module.verify(path)
    def test_reject_truncated_binary(self):
        path = self.root/'broken.zip'
        with ZipFile(self.make()) as original, ZipFile(path,'w') as archive:
            for member in original.namelist(): archive.writestr(member,b'bad' if member.endswith('/MiaoJi') else original.read(member))
        with self.assertRaisesRegex(ValueError,'Mach-O'): module.verify(path)

if __name__ == '__main__': unittest.main()
