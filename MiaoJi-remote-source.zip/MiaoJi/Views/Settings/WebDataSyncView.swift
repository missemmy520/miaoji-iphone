import SwiftUI
import SwiftData
import WebKit
import UniformTypeIdentifiers
import UIKit

struct ExcelDataView: View {
    let petID: UUID
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    @State private var importing = false
    @State private var pending: Data?
    @State private var confirmsImport = false
    @State private var message = ""
    @State private var share: SyncFile?
    @State private var selectedFile: URL?
    @State private var reading = false
    @State private var importedCount = 0
    struct SyncFile: Identifiable { let url: URL; var id: URL { url } }
    var body: some View {
        NavigationStack {
            VStack(spacing: 8) {
                Group {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("离线导入和导出 Excel，无需登录或连接网络。一个文件包含全部宠物、日常记录、库存和校准。")
                        Text("导入前会确认是否覆盖同 ID 记录，不会删除其他记录。旧版单宠物明细表导入当前宠物；多宠物备份按宠物 ID 识别。")
                        HStack {
                            Button("导出全部宠物 Excel") { exportFile() }
                            Spacer()
                            Button("导入 Excel") { message = ""; importing = true }.disabled(reading)
                        }
                    }.font(.caption).padding(.vertical, 10)
                }.padding(.horizontal, 16)
                if reading { ProgressView("正在读取 Excel，请稍候…").padding() }
                if !message.isEmpty { Text(message).font(.caption).foregroundStyle(DiaryStyle.pink).textSelection(.enabled).padding(.horizontal, 16) }
                if confirmsImport, pending != nil {
                    DiaryCard {
                        VStack(alignment: .leading, spacing: 12) {
                            Text("文件已读取 · \(importedCount) 条记录").font(.headline)
                            Text("即将写入手机本地数据库，不会上传网络。默认只补充新记录；覆盖会更新同 ID 内容。其他记录不会删除。").font(.caption)
                            Button("仅补充到手机本地") { merge(overwrite: false); confirmsImport = false }
                            Button("覆盖本地同 ID 记录", role: .destructive) { merge(overwrite: true); confirmsImport = false }
                            Button("取消导入", role: .cancel) { pending = nil; confirmsImport = false }
                        }
                    }.padding(.horizontal, 16)
                }
                Spacer(minLength: 0)
            }.background(DiaryStyle.background).navigationTitle("Excel 导入导出").navigationBarTitleDisplayMode(.inline)
                .toolbar { Button("完成") { dismiss() } }
                .sheet(isPresented: $importing, onDismiss: { loadSelectedFile() }) {
                    ExcelDocumentPicker { url in selectedFile = url; importing = false }
                }
                .sheet(item: $share) { item in SyncShareView(url: item.url) }
        }
    }
    private func loadSelectedFile() {
        guard let url = selectedFile else { message = "已取消选择，未修改记录。"; return }
        selectedFile = nil; reading = true; confirmsImport = false; pending = nil
        message = "已选择：" + url.lastPathComponent
        let targetPetID = petID
        Task { @MainActor in
            defer { reading = false }
            do {
                let parsed = try await Task.detached(priority: .userInitiated) {
                    guard url.pathExtension.lowercased() == "xlsx" else { throw ExcelWorkbookReader.ReadError.unsupported }
                    let access = url.startAccessingSecurityScopedResource()
                    defer { if access { url.stopAccessingSecurityScopedResource() } }
                    let coordinator = NSFileCoordinator()
                    var coordinationError: NSError?
                    var result: Result<Data, Error> = .failure(ExcelWorkbookReader.ReadError.invalid)
                    coordinator.coordinate(readingItemAt: url, options: .withoutChanges, error: &coordinationError) { readable in
                        result = Result {
                            let size = try readable.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
                            guard size <= 10_000_000 else { throw ExcelWorkbookReader.ReadError.tooLarge }
                            let bytes = try Data(contentsOf: readable)
                            return try ExcelInterchangeService.parse(bytes, legacyPetID: targetPetID)
                        }
                    }
                    if let coordinationError { throw coordinationError }
                    return try result.get()
                }.value
                importedCount = try DataInterchangeService.parse(parsed).count
                pending = parsed; confirmsImport = true; message = "文件已读取，请在下方确认导入。"
            } catch { message = "无法读取文件：" + error.localizedDescription }
        }
    }
    private func merge(overwrite: Bool) {
        guard let pending else { return }
        do { message = try DataInterchangeService.apply(DataInterchangeService.parse(pending), overwrite: overwrite, preservePetIDs: true, in: context).text; self.pending = nil }
        catch { context.rollback(); message = error.localizedDescription }
    }
    private func exportFile() {
        do {
            let url = try ExcelInterchangeService.export(in: context)
            share = SyncFile(url: url)
        } catch { message = error.localizedDescription }
    }
}

struct WebDataSyncView: View {
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    @State private var pending: Data?
    @State private var confirmsImport = false
    @State private var message = ""
    var body: some View {
        NavigationStack {
            VStack(spacing: 10) {
                Text("登录你的喵记专用账号后，手动读取或传递记录。Excel 文件请到设置中的「Excel 导入导出」。")
                    .font(.caption).foregroundStyle(.secondary).padding(.horizontal, 16)
                if !message.isEmpty { Text(message).font(.caption).foregroundStyle(DiaryStyle.pink).padding(.horizontal, 16) }
                SyncWebView(modelContext: context, receive: { data in
                    do { _ = try DataInterchangeService.parse(data); pending = data; confirmsImport = true }
                    catch { message = error.localizedDescription }
                }, report: { message = $0 })
            }.background(DiaryStyle.background)
                .navigationTitle("联网数据同步").navigationBarTitleDisplayMode(.inline)
                .toolbar { Button("完成") { dismiss() } }
                .alert("导入云端记录", isPresented: $confirmsImport) {
                    Button("仅补充新记录") { merge(overwrite: false) }
                    Button("覆盖同 ID 记录", role: .destructive) { merge(overwrite: true) }
                    Button("取消", role: .cancel) { pending = nil }
                } message: { Text("默认只补充新记录。覆盖会更新同 ID 的内容，不会删除其他记录。") }
        }
    }
    private func merge(overwrite: Bool) {
        guard let pending else { return }
        do { message = try DataInterchangeService.apply(DataInterchangeService.parse(pending), overwrite: overwrite, preservePetIDs: true, in: context).text; self.pending = nil }
        catch { context.rollback(); message = error.localizedDescription }
    }
}

private struct ExcelDocumentPicker: UIViewControllerRepresentable {
    let selected: (URL?) -> Void
    func makeCoordinator() -> Coordinator { Coordinator(selected: selected) }
    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.data], asCopy: true)
        picker.allowsMultipleSelection = false
        picker.delegate = context.coordinator
        return picker
    }
    func updateUIViewController(_ picker: UIDocumentPickerViewController, context: Context) {}
    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        let selected: (URL?) -> Void
        init(selected: @escaping (URL?) -> Void) { self.selected = selected }
        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) { selected(urls.first) }
        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) { selected(nil) }
    }
}

private struct SyncWebView: UIViewRepresentable {
    let modelContext: ModelContext
    let receive: (Data) -> Void
    let report: (String) -> Void
    func makeCoordinator() -> Coordinator { Coordinator(parent: self) }
    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        configuration.userContentController.add(context.coordinator, name: "miaoji")
        let web = WKWebView(frame: .zero, configuration: configuration)
        web.navigationDelegate = context.coordinator
        web.isOpaque = false; web.backgroundColor = .black
        if let url = URL(string: DataInterchangeService.website) { web.load(URLRequest(url: url)) }
        return web
    }
    func updateUIView(_ webView: WKWebView, context: Context) { context.coordinator.parent = self }
    static func dismantleUIView(_ webView: WKWebView, coordinator: Coordinator) { webView.configuration.userContentController.removeScriptMessageHandler(forName: "miaoji") }
    final class Coordinator: NSObject, WKScriptMessageHandler, WKNavigationDelegate {
        var parent: SyncWebView
        init(parent: SyncWebView) { self.parent = parent }
        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) { parent.report("网页暂时无法打开：" + error.localizedDescription + "。仍可导入导出 Excel 文件。") }
        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            // Authentication pages and third-party frames must never access local diary data.
            guard message.frameInfo.isMainFrame,
                  message.frameInfo.securityOrigin.protocol == "https",
                  message.frameInfo.securityOrigin.host == URL(string: DataInterchangeService.website)?.host,
                  let body = message.body as? [String: Any] else { return }
            do {
                if body["action"] as? String == "export" {
                    let data = try DataInterchangeService.export(in: parent.modelContext)
                    guard let document = try JSONSerialization.jsonObject(with: data) as? [String: Any], let records = document["records"] else { return }
                    let encoded = try JSONSerialization.data(withJSONObject: records)
                    guard let json = String(data: encoded, encoding: .utf8) else { return }
                    message.webView?.evaluateJavaScript("window.miaojiReceiveNative?.(" + json + ")", completionHandler: { _, error in if let error { self.parent.report(error.localizedDescription) } })
                } else if body["action"] as? String == "import" {
                    parent.receive(try JSONSerialization.data(withJSONObject: body))
                }
            } catch { parent.report(error.localizedDescription) }
        }
    }
}
private struct SyncShareView: UIViewControllerRepresentable {
    let url: URL
    func makeUIViewController(context: Context) -> UIActivityViewController { UIActivityViewController(activityItems: [url], applicationActivities: nil) }
    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}
