import Foundation
import SwiftData

@Model
final class WeightRecord {
    @Attribute(.unique) var id: UUID
    var petID: UUID? = nil
    var weightKg: Double
    var eventAt: Date
    private(set) var createdAt: Date
    var note: String?

    init(weightKg: Double, eventAt: Date = .now, note: String? = nil) {
        self.id = UUID()
        self.weightKg = weightKg
        self.eventAt = eventAt
        self.createdAt = .now
        self.note = note
    }
}

