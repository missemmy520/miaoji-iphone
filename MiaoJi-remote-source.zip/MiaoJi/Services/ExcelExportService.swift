import Foundation

enum ExcelCell: Sendable { case text(String), number(Double), empty }
struct ExcelSheet: Sendable { let name: String; let rows: [[ExcelCell]] }

enum ExcelExportService {
    @MainActor static func sheets(feedings: [FeedingRecord], stools: [StoolRecord], weights: [WeightRecord]) -> [ExcelSheet] {
        let calendar = Calendar.current
        let formatter = DateFormatter()
        formatter.calendar = calendar; formatter.locale = Locale(identifier: "en_US_POSIX"); formatter.timeZone = .current
        formatter.dateFormat = "yyyy-MM-dd HH:mm"
        func time(_ date: Date) -> ExcelCell { .text(formatter.string(from: date)) }
        func headers(_ labels: [String]) -> [ExcelCell] { labels.map { .text($0) } }
        let index = StatisticsService.dayIndex(feedings: feedings, stools: stools, weights: weights, calendar: calendar)
        var daily = [headers(["日期", "干粮(g)", "湿粮(g)", "猫条(g)", "其他(g)", "总进食量(g)", "排便次数", "当日最新体重(kg)"])]
        for day in index.keys.sorted() {
            guard let summary = index[day] else { continue }
            formatter.dateFormat = "yyyy-MM-dd"
            var row: [ExcelCell] = [.text(formatter.string(from: day))]
            row += FoodType.allCases.map { summary.food[$0].map { .number($0) } ?? .empty }
            row += [summary.totalGram.map { .number($0) } ?? .empty,
                    summary.stoolCount.map { .number(Double($0)) } ?? .empty,
                    summary.weight.map { .number($0.weightKg) } ?? .empty]
            daily.append(row)
        }
        formatter.dateFormat = "yyyy-MM-dd HH:mm"
        let feedingRows: [[ExcelCell]] = [headers(["实际进食时间", "录入时间", "食物类型", "摄入量(g)", "备注"])] + feedings.sorted { $0.eventAt < $1.eventAt }.map {
            [time($0.eventAt), time($0.createdAt), .text($0.foodType.title), .number($0.amountGram), .text($0.note ?? "")]
        }
        let stoolRows: [[ExcelCell]] = [headers(["实际排便时间", "录入时间", "次数", "状态", "大小/描述", "备注"])] + stools.sorted { $0.eventAt < $1.eventAt }.map {
            [time($0.eventAt), time($0.createdAt), .number(Double($0.count)), .text($0.condition?.title ?? ""), .text($0.descriptionText ?? ""), .text($0.note ?? "")]
        }
        let weightRows: [[ExcelCell]] = [headers(["实际测量时间", "录入时间", "体重(kg)", "备注"])] + weights.sorted { $0.eventAt < $1.eventAt }.map {
            [time($0.eventAt), time($0.createdAt), .number($0.weightKg), .text($0.note ?? "")]
        }
        return [ExcelSheet(name: "每日汇总", rows: daily), ExcelSheet(name: "进食明细", rows: feedingRows),
                ExcelSheet(name: "排便明细", rows: stoolRows), ExcelSheet(name: "体重明细", rows: weightRows)]
    }
    static func write(_ sheets: [ExcelSheet], petName: String) throws -> URL {
        guard sheets.allSatisfy({ $0.rows.count <= 1_048_576 }) else { throw WorkbookZIP.ZIPError.tooLarge }
        var zip = WorkbookZIP()
        let declaration = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
        let main = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
        let relation = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
        let packageRelation = "http://schemas.openxmlformats.org/package/2006/relationships"
        var types = declaration + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>"
        var workbook = declaration + "<workbook xmlns=\"\(main)\" xmlns:r=\"\(relation)\"><sheets>"
        var rels = declaration + "<Relationships xmlns=\"\(packageRelation)\">"
        for (index, sheet) in sheets.enumerated() {
            let number = index + 1
            types += "<Override PartName=\"/xl/worksheets/sheet\(number).xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>"
            workbook += "<sheet name=\"\(xml(sheet.name))\" sheetId=\"\(number)\" r:id=\"rId\(number)\"/>"
            rels += "<Relationship Id=\"rId\(number)\" Type=\"\(relation)/worksheet\" Target=\"worksheets/sheet\(number).xml\"/>"
            try zip.add("xl/worksheets/sheet\(number).xml", content: declaration + worksheet(sheet, namespace: main))
        }
        types += "</Types>"; workbook += "</sheets></workbook>"
        rels += "<Relationship Id=\"rIdStyles\" Type=\"\(relation)/styles\" Target=\"styles.xml\"/></Relationships>"
        try zip.add("[Content_Types].xml", content: types)
        try zip.add("_rels/.rels", content: declaration + "<Relationships xmlns=\"\(packageRelation)\"><Relationship Id=\"rId1\" Type=\"\(relation)/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>")
        try zip.add("xl/workbook.xml", content: workbook)
        try zip.add("xl/_rels/workbook.xml.rels", content: rels)
        try zip.add("xl/styles.xml", content: declaration + "<styleSheet xmlns=\"\(main)\"><fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font><font><b/><sz val=\"11\"/><name val=\"Calibri\"/></font></fonts><fills count=\"2\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill></fills><borders count=\"1\"><border/></borders><cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs><cellXfs count=\"3\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/><xf numFmtId=\"0\" fontId=\"1\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/><xf numFmtId=\"2\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyNumberFormat=\"1\"/></cellXfs><cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles></styleSheet>")
        let data = try zip.finish()
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent("MiaoJiExport-" + UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        let safeName = petName.components(separatedBy: CharacterSet(charactersIn: "/\\:*?\"<>|\n\r")).joined(separator: "_")
        let formatter = DateFormatter(); formatter.locale = Locale(identifier: "en_US_POSIX"); formatter.timeZone = .current; formatter.dateFormat = "yyyy-MM-dd"
        let filename = String(safeName.prefix(50)) + "记录_" + formatter.string(from: .now) + ".xlsx"
        let url = folder.appendingPathComponent(filename)
        do { try data.write(to: url, options: .atomic); return url }
        catch { try? FileManager.default.removeItem(at: folder); throw error }
    }
    static func cleanup(_ url: URL) {
        let folder = url.deletingLastPathComponent()
        guard folder.lastPathComponent.hasPrefix("MiaoJiExport-"), folder.deletingLastPathComponent().standardizedFileURL.path == FileManager.default.temporaryDirectory.standardizedFileURL.path else { return }
        try? FileManager.default.removeItem(at: folder)
    }
    private static func worksheet(_ sheet: ExcelSheet, namespace: String) -> String {
        var output = "<worksheet xmlns=\"\(namespace)\"><sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews><cols><col min=\"1\" max=\"2\" width=\"23\" customWidth=\"1\"/><col min=\"3\" max=\"8\" width=\"20\" customWidth=\"1\"/></cols><sheetData>"
        for (rowIndex, row) in sheet.rows.enumerated() {
            output += "<row r=\"\(rowIndex + 1)\">"
            for (col, cell) in row.enumerated() {
                let ref = String(UnicodeScalar(65 + col) ?? "A") + String(rowIndex + 1)
                switch cell {
                case .empty: continue
                case .number(let value):
                    if value.isFinite { output += "<c r=\"\(ref)\" s=\"\(sheet.name == "体重明细" && col == 2 || sheet.name == "每日汇总" && col == 7 ? 2 : 0)\"><v>\(value)</v></c>" }
                case .text(let text):
                    output += "<c r=\"\(ref)\" t=\"inlineStr\" s=\"\(rowIndex == 0 ? 1 : 0)\"><is><t xml:space=\"preserve\">\(xml(String(text.prefix(32767))))</t></is></c>"
                }
            }
            output += "</row>"
        }
        return output + "</sheetData></worksheet>"
    }
    private static func xml(_ text: String) -> String {
        let scalars = text.unicodeScalars.filter { s in
            s.value == 9 || s.value == 10 || s.value == 13 || (32...0xd7ff).contains(s.value) || (0xe000...0xfffd).contains(s.value) || (0x10000...0x10ffff).contains(s.value)
        }
        return String(String.UnicodeScalarView(scalars)).replacingOccurrences(of: "&", with: "&amp;").replacingOccurrences(of: "<", with: "&lt;").replacingOccurrences(of: ">", with: "&gt;").replacingOccurrences(of: "\"", with: "&quot;").replacingOccurrences(of: "'", with: "&apos;")
    }
}


