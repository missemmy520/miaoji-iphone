import Foundation

struct HealthSource: Identifiable {
    let id: String
    let title: String
    let organization: String
    let year: String
    let url: String
    let section: String
    let scope: String
    var checkedAt: String { "2026-10-24" }
}

struct HealthTopic: Identifiable {
    let id: String
    let title: String
    let keywords: [String]
    let searchTerms: String
    let answer: String
    let sourceIDs: [String]
}

// Reviewed paraphrases and bibliographic metadata, not copies of copyrighted articles.
// No model-generated diagnoses or drug doses are stored in this catalog.
enum HealthKnowledge {
    static let sources: [HealthSource] = [
        .init(id: "wsava", title: "Nutrition Guidelines / Global Nutrition Toolkit", organization: "WSAVA", year: "工具持续更新；热量表 2020", url: "https://wsava.org/Global-Guidelines/Global-Nutrition-Guidelines/", section: "Body condition / Muscle condition / Calorie needs", scope: "健康犬猫的营养评估工具；不能替代患病猫的个体营养方案。"),
        .init(id: "ckd2026", title: "2026 iCatCare consensus guidelines on the diagnosis and management of chronic kidney disease in cats", organization: "International Cat Care · Journal of Feline Medicine and Surgery", year: "2026", url: "https://doi.org/10.1177/1098612X261466553", section: "Clinical signs; Dietary intervention; Inappetence; Figure 18", scope: "猫慢性肾病共识指南。家庭记录辅助复诊，不用于自行分期、诊断或调药。"),
        .init(id: "urinary", title: "Feline Lower Urinary Tract Disease", organization: "American Veterinary Medical Association", year: "2024", url: "https://ebusiness.avma.org/Files/ProductDownloads/mcm-client-brochures-feline-lower-urinary-tract-disease-2024.pdf", section: "Urethral obstruction; supporting urinary health", scope: "兽医协会家长教育资料；排尿困难需要实际就诊评估。"),
        .init(id: "appetite", title: "Anorexia", organization: "Cornell Feline Health Center", year: "页面未标明发表年份", url: "https://www.vet.cornell.edu/departments-centers-and-institutes/cornell-feline-health-center/health-information/feline-health-topics/anorexia", section: "Loss of appetite; veterinary workup", scope: "大学兽医学院科普，不是针对某只猫的诊断。"),
        .init(id: "vomit", title: "Vomiting", organization: "Cornell Feline Health Center", year: "2021 更新", url: "https://www.vet.cornell.edu/departments-centers-and-institutes/cornell-feline-health-center/health-information/feline-health-topics/vomiting", section: "Frequent vomiting and accompanying signs", scope: "大学兽医学院科普；不能仅从呕吐物外观确定病因。"),
        .init(id: "hazards", title: "Common Cat Hazards", organization: "Cornell Feline Health Center", year: "页面未标明发表年份", url: "https://www.vet.cornell.edu/departments-centers-and-institutes/cornell-feline-health-center/health-information/feline-health-topics/common-cat-hazards", section: "What should I do if my cat has ingested something toxic?", scope: "误食应急信息；不提供家庭催吐或用药方案。")
    ]
    static let topics: [HealthTopic] = [
        .init(id: "intake", title: "今天吃的克数够不够？", keywords: ["克", "摄入", "吃够", "吃得", "热量", "营养", "干粮", "湿粮"], searchTerms: "feline nutritional assessment energy intake", answer: "你把每一餐记下来，已经为了解食欲变化打好了基础。干粮和湿粮的每克热量不同，克数总和不能直接说明营养够不够。请结合包装热量、体重、体况和兽医给出的目标评估；本页只整理实际摄入，不给健康打分。", sourceIDs: ["wsava", "ckd2026"]),
        .init(id: "appetite", title: "胃口差或不吃东西怎么办？", keywords: ["不吃", "没吃", "拒食", "胃口", "食欲", "少吃"], searchTerms: "feline inappetence anorexia guideline", answer: "胃口变化值得认真对待，不必责怪自己。请记录开始时间、实际吃了多少，以及精神、呕吐和用药情况，并及时联系兽医；完全不吃时不要等记录满一天才求助。食欲差可能有多种原因，不能仅凭记录认定是挑食，也不要自行强行灌食或使用开胃药。", sourceIDs: ["appetite"]),
        .init(id: "kidney", title: "慢性肾病日常要观察什么？", keywords: ["肾", "多囊", "ckd", "饮水", "喝水", "喝得多"], searchTerms: "feline chronic kidney disease monitoring guideline", answer: "饮食、饮水变化、体重和精神情况都可以整理给主治兽医。你持续的观察很有价值。肾病护理与饮食需要个体化，不能靠进食克数或尿团数推算肾功能，也不能据此自行调药或补液。", sourceIDs: ["ckd2026"]),
        .init(id: "weight", title: "体重有变化要紧吗？", keywords: ["体重", "瘦", "掉秤", "胖", "减重"], searchTerms: "feline weight loss body condition assessment", answer: "尽量在相近条件下称重，并保留真实数值。非计划性变瘦应与兽医沟通，体重之外还需评估肌肉和体况。一次波动不能直接判断病情；没有称重的日子也不代表体重不变。", sourceIDs: ["wsava", "ckd2026"]),
        .init(id: "urine", title: "几坨尿团算正常？", keywords: ["尿", "猫砂", "扁平", "鸡蛋", "几坨"], searchTerms: "feline lower urinary tract signs guideline", answer: "尿团个数、大小和形状便于和自家猫平时比较，但不是毫升尿量；猫砂、清理间隔及多猫共用都影响观察，不能统一规定每天几坨才健康。如果频繁蹲砂盆、用力却尿很少或没有尿，应立即联系急诊兽医，不要等待联网结果。", sourceIDs: ["urinary"]),
        .init(id: "vomit", title: "吐了，还要观察哪些信息？", keywords: ["吐", "反胃", "恶心"], searchTerms: "feline vomiting clinical review", answer: "可以补充次数、开始时间、是否能吃喝、精神状态，以及是否可能误食。频繁呕吐或伴随精神差、食欲下降、血液等情况需要尽快就医。请不要只凭颜色或“吐毛球”自行判断原因。能把这些细节带给医生，会很有帮助。", sourceIDs: ["vomit"]),
        .init(id: "hazards", title: "怀疑误食植物或药物怎么办？", keywords: ["误食", "中毒", "百合", "人药", "催吐", "清洁剂"], searchTerms: "feline poisoning toxic exposure", answer: "怀疑误食有毒物品时，立即联系兽医或当地动物急诊，带上包装、植物照片及发生时间。不要等症状出现，也不要自行催吐或喂药。", sourceIDs: ["hazards"]),
        .init(id: "context", title: "精神、环境和既往病史也有用吗？", keywords: ["精神", "躲", "环境", "应激", "病史", "牙", "睡", "活动"], searchTerms: "feline clinical history behavior appetite", answer: "有用。你可以一起描述精神、活动、环境变化、既往疾病、正在用的药及症状持续时间。食欲变化可能涉及身体或环境因素，单个表现不能确定病因。精神明显变差或与平时差别很大时，请及时联系兽医。", sourceIDs: ["appetite", "vomit"])
    ]
    static func sources(for ids: [String]) -> [HealthSource] { sources.filter { ids.contains($0.id) } }
    static func matches(_ text: String) -> [HealthTopic] {
        let input = text.lowercased()
        return topics.filter { topic in topic.keywords.contains { input.contains($0) } }
    }
}
