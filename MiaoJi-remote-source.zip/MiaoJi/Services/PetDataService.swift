import Foundation
import SwiftData

enum PetDataService {
    @MainActor static func prepare(in context: ModelContext) throws {
        var profiles = try context.fetch(FetchDescriptor<CatProfile>())
        if profiles.isEmpty {
            let pet = CatProfile()
            context.insert(pet)
            profiles = [pet]
        }
        // The original single-pet version belonged to 花卷. Assign legacy rows once.
        let original = profiles.first(where: { $0.name == "花卷" }) ?? profiles.sorted { $0.id.uuidString < $1.id.uuidString }.first
        guard let pet = original else { return }
        for record in try context.fetch(FetchDescriptor<FeedingRecord>()) where record.petID == nil { record.petID = pet.id }
        for record in try context.fetch(FetchDescriptor<StoolRecord>()) where record.petID == nil { record.petID = pet.id }
        for record in try context.fetch(FetchDescriptor<WeightRecord>()) where record.petID == nil { record.petID = pet.id }
        for bag in try context.fetch(FetchDescriptor<DryFoodInventory>()) where bag.petID == nil { bag.petID = pet.id }
        do { try context.save() } catch { context.rollback(); throw error }
    }
}
