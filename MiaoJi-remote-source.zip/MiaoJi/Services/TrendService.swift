import Foundation

enum StatisticsRange: String, CaseIterable, Identifiable {
    case week = "最近7天", month = "最近30天", currentMonth = "本月"
    var id: String { rawValue }
    func interval(at now: Date = .now, calendar: Calendar = .current) -> DateInterval {
        let start: Date
        switch self {
        case .week: start = calendar.date(byAdding: .day, value: -6, to: calendar.startOfDay(for: now)) ?? now
        case .month: start = calendar.date(byAdding: .day, value: -29, to: calendar.startOfDay(for: now)) ?? now
        case .currentMonth: start = calendar.dateInterval(of: .month, for: now)?.start ?? now
        }
        return DateInterval(start: start, end: now)
    }
}

enum TrendGrouping: String, CaseIterable { case daily = "每日", weekly = "每周", monthly = "每月"
    var component: Calendar.Component {
        switch self { case .daily: return .day; case .weekly: return .weekOfYear; case .monthly: return .month }
    }
}
struct FoodBucket: Identifiable {
    let date: Date
    let food: [FoodType: Double]
    var id: Date { date }
    var total: Double { food.values.reduce(0, +) }
}
extension StatisticsService {
    static func foodBuckets(_ records: [FeedingRecord], grouping: TrendGrouping, calendar: Calendar = .current) -> [FoodBucket] {
        let groups = Dictionary(grouping: records) { calendar.dateInterval(of: grouping.component, for: $0.eventAt)?.start ?? $0.eventAt }
        return groups.map { day, meals in
            FoodBucket(date: day, food: Dictionary(grouping: meals, by: \.foodType).mapValues { $0.reduce(0) { $0 + $1.amountGram } })
        }.sorted { $0.date < $1.date }
    }
}
