import SwiftUI
import Charts

/// A tap is enough to inspect a bar; vertical swipes remain available to the page.
struct ChartTapSelection: ViewModifier {
    @Binding var selected: Date?

    func body(content: Content) -> some View {
        content.chartOverlay { proxy in
            GeometryReader { geometry in
                Rectangle().fill(.clear).contentShape(Rectangle())
                    .gesture(SpatialTapGesture().onEnded { tap in
                        guard let anchor = proxy.plotFrame else { return }
                        let plot = geometry[anchor]
                        guard plot.contains(tap.location),
                              let date = proxy.value(atX: tap.location.x - plot.minX, as: Date.self) else { return }
                        selected = date
                    })
            }
        }
    }
}

struct FeedingBreakdown: View {
    let title: String
    let food: [FoodType: Double]
    let close: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text(title).font(.subheadline.bold())
                Spacer(minLength: 8)
                Button(action: close) { Image(systemName: "xmark.circle.fill").foregroundStyle(.secondary) }
                    .buttonStyle(.plain).accessibilityLabel("关闭进食明细")
            }
            if food.isEmpty {
                Text("当天未记录进食").font(.subheadline).foregroundStyle(.secondary)
            } else {
                HStack {
                    Text("总进食量").font(.subheadline)
                    Spacer()
                    Text(grams(food.values.reduce(0, +))).font(.headline).foregroundStyle(DiaryStyle.pink)
                }
                ForEach(FoodType.allCases.filter { $0 == .dry || $0 == .wet || food[$0] != nil }) { type in
                    HStack(spacing: 8) {
                        Circle().fill(type.color).frame(width: 6, height: 6)
                        Text(type.title)
                        Spacer()
                        Text(food[type].map(grams) ?? "未记录")
                            .monospacedDigit()
                    }.font(.subheadline)
                }
                Text("按已保存记录精确汇总，包含全部食物类型；未记录的分类不当作零。")
                    .font(.caption2).foregroundStyle(.secondary)
            }
        }
        .padding(14)
        .background(.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 16))
        .accessibilityElement(children: .contain)
    }

    private func grams(_ value: Double) -> String {
        value.formatted(.number.precision(.fractionLength(0...1))) + " g"
    }
}
