import Foundation

struct HealthObservation: Identifiable {
    let id: String
    let title: String
    let text: String
    let sourceIDs: [String]
}

enum HealthAnalysisService {
    static func observations(petID: UUID, feedings: [FeedingRecord], weights: [WeightRecord],
                             stools: [StoolRecord], urines: [UrineRecord], at now: Date = .now,
                             calendar: Calendar = .current) -> [HealthObservation] {
        let start = calendar.startOfDay(for: now)
        let recentStart = calendar.date(byAdding: .day, value: -6, to: start) ?? start
        let meals = feedings.filter { $0.petID == petID && $0.eventAt >= recentStart && $0.eventAt <= now }
        let today = meals.filter { $0.eventAt >= start }
        func grams(_ value: Double) -> String { value.formatted(.number.precision(.fractionLength(0...1))) + " g" }
        var result: [HealthObservation] = []
        if today.isEmpty {
            result.append(.init(id: "today", title: "今天的饮食还未记录", text: "未记录不等于没有吃。补上实际发生时间后，这里会自动整理今天的摄入。", sourceIDs: []))
        } else {
            let details = FoodType.allCases.compactMap { type -> String? in
                let rows = today.filter { $0.foodType == type }
                return rows.isEmpty ? nil : type.title + " " + grams(rows.reduce(0) { $0 + $1.amountGram })
            }
            result.append(.init(id: "today", title: "今天已记录 " + grams(today.reduce(0) { $0 + $1.amountGram }), text: details.joined(separator: " · ") + "。谢谢你认真记下这些小细节。今天还在继续，当前数字不代表全天总量或营养达标。", sourceIDs: ["wsava"]))
        }
        let recordedDays = Set(meals.map { calendar.startOfDay(for: $0.eventAt) }).count
        result.append(.init(id: "coverage", title: "最近 7 天有 \(recordedDays) 天饮食记录", text: "只汇总有记录的日期，不把空白日期算作零摄入。克数不能直接换算营养是否充足；需要食物热量、体况及个体目标。", sourceIDs: ["wsava"]))
        // Compare complete calendar days for each food separately; not a clinical threshold.
        let completed = meals.filter { $0.eventAt < start }
        let grouped = Dictionary(grouping: completed, by: { calendar.startOfDay(for: $0.eventAt) })
        let dates = grouped.keys.sorted()
        if dates.count >= 3, let last = dates.last, let lastRows = grouped[last] {
            for kind in [FoodType.dry, .wet] {
                let previous = dates.dropLast().compactMap { date -> Double? in
                    let rows = (grouped[date] ?? []).filter { $0.foodType == kind }
                    return rows.isEmpty ? nil : rows.reduce(0) { $0 + $1.amountGram }
                }
                let lastKind = lastRows.filter { $0.foodType == kind }
                guard previous.count >= 2, !lastKind.isEmpty else { continue }
                let mean = previous.reduce(0, +) / Double(previous.count)
                let amount = lastKind.reduce(0) { $0 + $1.amountGram }
                result.append(.init(id: "trend-" + kind.rawValue, title: kind.title + "记录对照", text: last.formatted(.dateTime.month().day()) + "记录 " + grams(amount) + "；此前 \(previous.count) 个有该类记录的日期平均 " + grams(mean) + "。这只是记录差异，漏记、换粮和每克热量都会影响比较；请结合实际食欲观察。", sourceIDs: []))
            }
        }
        let validWeights = weights.filter { $0.petID == petID && $0.eventAt <= now }.sorted { $0.eventAt < $1.eventAt }
        if let last = validWeights.last {
            var text = last.eventAt.formatted(date: .abbreviated, time: .shortened) + " 实测 " + last.weightKg.formatted(.number.precision(.fractionLength(2))) + " kg。"
            if validWeights.count > 1 {
                let before = validWeights[validWeights.count - 2]
                text += "上一次实测 " + before.weightKg.formatted(.number.precision(.fractionLength(2))) + " kg。"
                if last.weightKg < before.weightKg { text += "如果不是计划内减重，请把变化告诉兽医。" }
            }
            result.append(.init(id: "weight", title: "保留每次真实体重", text: text + "未称重日期不补值；继续使用相近的称重条件会更便于比较。", sourceIDs: ["wsava", "ckd2026"]))
        } else {
            result.append(.init(id: "weight", title: "还没有体重记录", text: "方便时记一次真实体重，就能逐渐看清变化。", sourceIDs: []))
        }
        let stoolRows = stools.filter { $0.petID == petID && $0.eventAt >= start && $0.eventAt <= now }
        let urineRows = urines.filter { $0.petID == petID && $0.eventAt >= start && $0.eventAt <= now }
        let stoolText = stoolRows.isEmpty ? "排便未记录" : "排便 \(stoolRows.reduce(0) { $0 + $1.count }) 次"
        let urineText = urineRows.isEmpty ? "尿团未记录" : "尿团 \(urineRows.reduce(0) { $0 + $1.clumpCount }) 坨"
        result.append(.init(id: "output", title: "今天的排泄记录", text: stoolText + " · " + urineText + "。尿团是观察记录，不是精确尿量；多猫共用砂盆时请注明是否能确认归属。", sourceIDs: []))
        return result
    }

    static func reply(to text: String, species: String) -> (text: String, topics: [HealthTopic]) {
        guard species == "猫" else { return ("目前的资料库仅适用于猫，不能套用于其他宠物。请咨询对应物种的兽医。", []) }
        // Conservative signpost, not diagnosis. Never suppress urgent guidance for reassuring tone.
        if ["尿不出", "尿不出来", "没尿", "没有尿", "无法排尿", "排不出尿", "呼吸困难", "张口呼吸", "抽搐", "昏迷", "误食", "中毒", "百合"].contains(where: text.contains) {
            let ids = text.contains("尿") ? ["urinary"] : ["hazards"]
            return ("你提到的情况可能需要紧急处理，请立即联系当地兽医急诊，不要等待联网检索，也不要自行用药或催吐。文字匹配无法判断严重程度。", HealthKnowledge.topics.filter { $0.sourceIDs.contains(where: ids.contains) })
        }
        let topics = HealthKnowledge.matches(text)
        return (topics.isEmpty ? "这部分超出了已核验的本地资料范围，我不能给出可靠的个体判断。可以使用下面的文献检索查找相关来源，再把信息交给兽医评估。" : "已根据你描述的主题找到以下已核验资料。补充信息不会被当作确诊；多种症状同时出现时请让兽医综合判断。", topics)
    }
}
