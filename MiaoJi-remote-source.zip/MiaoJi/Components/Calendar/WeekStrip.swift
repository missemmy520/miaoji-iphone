import SwiftUI

struct WeekStrip: View {
    @Binding var selectedDate: Date
    let feedings: [FeedingRecord]
    let stools: [StoolRecord]
    let weights: [WeightRecord]
    let urines: [UrineRecord]
    let dailyNotes: [DailyNoteRecord]
    @State private var feedback = 0
    private let weekdays = ["一", "二", "三", "四", "五", "六", "日"]

    var body: some View {
        DiaryCard {
            VStack(spacing: 18) {
                HStack {
                    Text(selectedDate.formatted(.dateTime.year().month(.wide))).font(.headline)
                    Spacer()
                    Button { shiftWeek(-1) } label: { Image(systemName: "chevron.left").padding(5) }
                        .accessibilityLabel("上一周")
                    Button { shiftWeek(1) } label: { Image(systemName: "chevron.right").padding(5) }
                        .accessibilityLabel("下一周")
                    Button("今天") { select(.now) }.font(.subheadline)
                }
                HStack(alignment: .top, spacing: 0) {
                    ForEach(Array(StatisticsService.week(containing: selectedDate).enumerated()), id: \.offset) { index, day in
                        Button { select(day) } label: {
                            VStack(spacing: 8) {
                                Text(weekdays[index]).font(.caption).foregroundStyle(.secondary)
                                Text(String(Calendar.current.component(.day, from: day)))
                                    .font(.subheadline.weight(.semibold))
                                    .lineLimit(1)
                                    .minimumScaleFactor(0.85)
                                    .frame(width: 34, height: 34)
                                    .foregroundStyle(dayColor(day))
                                    .background(Calendar.current.isDate(day, inSameDayAs: selectedDate) ? (DiaryDates.isFutureDay(day) ? DiaryStyle.card : DiaryStyle.pink) : .clear, in: Circle())
                                    .overlay(Circle().stroke(Calendar.current.isDateInToday(day) ? DiaryStyle.pink : .clear, lineWidth: 1))
                                HStack(spacing: 3) {
                                    ForEach(Array(dotColors(day).prefix(3).enumerated()), id: \.offset) { _, color in
                                        Circle().fill(color).frame(width: 4, height: 4)
                                    }
                                }.frame(height: 5)
                            }.frame(maxWidth: .infinity)
                        }.buttonStyle(.plain)
                         .accessibilityLabel(day.formatted(date: .complete, time: .omitted))
                         .accessibilityAddTraits(Calendar.current.isDate(day, inSameDayAs: selectedDate) ? .isSelected : [])
                    }
                }
            }
        }
        .sensoryFeedback(.selection, trigger: feedback)
    }

    private func select(_ date: Date) {
        withAnimation(.easeInOut(duration: 0.25)) { selectedDate = date }
        feedback += 1
    }
    private func dayColor(_ day: Date) -> Color {
        if DiaryDates.isFutureDay(day) { return .gray }
        return Calendar.current.isDate(day, inSameDayAs: selectedDate) ? DiaryStyle.background : .white
    }
    private func shiftWeek(_ value: Int) {
        if let day = Calendar.current.date(byAdding: .day, value: value * 7, to: selectedDate) { select(day) }
    }
    private func dotColors(_ date: Date) -> [Color] {
        let summary = StatisticsService.summary(on: date, feedings: feedings, stools: stools, weights: weights, urines: urines)
        var colors: [Color] = []
        if summary.food[.wet] != nil { colors.append(DiaryStyle.pink) }
        if summary.food[.dry] != nil { colors.append(DiaryStyle.green) }
        if summary.stoolCount != nil { colors.append(DiaryStyle.amber) }
        if summary.urineClumpCount != nil { colors.append(.cyan.opacity(0.7)) }
        if summary.weight != nil { colors.append(DiaryStyle.blue) }
        if colors.isEmpty && !summary.food.isEmpty { colors.append(.gray) }
        if dailyNotes.contains(where: { Calendar.current.isDate($0.eventAt, inSameDayAs: date) }) { colors.append(.gray) }
        return colors
    }
}
