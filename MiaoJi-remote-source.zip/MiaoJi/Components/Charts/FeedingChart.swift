import SwiftUI
import Charts

struct FeedingChart: View {
    let summaries: [DaySummary]
    @State private var filter = "进食量"
    @State private var selected: Date?
    private var types: [FoodType] {
        filter == "干粮" ? [.dry] : filter == "湿粮" ? [.wet] : FoodType.allCases
    }
    var body: some View {
        DiaryCard {
            VStack(alignment: .leading, spacing: 14) {
                HStack(alignment: .firstTextBaseline) {
                    Text("本周饮食").font(.title3.bold())
                    Spacer(minLength: 8)
                    Text(monthLabel).font(.caption).foregroundStyle(.secondary)
                        .lineLimit(1).minimumScaleFactor(0.8)
                }
                Picker("饮食分类", selection: $filter) {
                    ForEach(["进食量", "干粮", "湿粮"], id: \.self) { Text($0) }
                }.pickerStyle(.segmented)
                if summaries.allSatisfy({ $0.totalGram == nil }) {
                    ContentUnavailableView("还没有饮食记录", systemImage: "chart.bar",
                                           description: Text("记录几天后，这里会开始出现趋势"))
                } else {
                    Chart {
                        ForEach(summaries, id: \.date) { summary in
                            ForEach(types) { type in
                                if let amount = summary.food[type] {
                                    BarMark(x: .value("日期", summary.date, unit: .day),
                                            y: .value("克", amount))
                                    .foregroundStyle(by: .value("类型", type.title))
                                }
                            }
                        }
                        if let day = selectedDay {
                            RuleMark(x: .value("选中日期", day.date, unit: .day))
                                .foregroundStyle(DiaryStyle.pink.opacity(0.6))
                                .lineStyle(StrokeStyle(lineWidth: 1, dash: [4]))
                        }
                    }
                    .chartForegroundStyleScale(domain: FoodType.allCases.map(\.title),
                                               range: FoodType.allCases.map(\.color))
                    .chartXScale(domain: chartDomain)
                    .chartXAxis {
                        AxisMarks(values: summaries.map(\.date)) { value in
                            AxisValueLabel {
                                if let date = value.as(Date.self) {
                                    Text(String(Calendar.current.component(.day, from: date)))
                                        .font(.system(size: 11)).lineLimit(1)
                                }
                            }
                        }
                    }
                    .chartYAxisLabel("g")
                    .modifier(ChartTapSelection(selected: $selected))
                    .frame(height: 190)
                    .animation(.easeInOut(duration: 0.25), value: filter)
                    if let day = selectedDay {
                        FeedingBreakdown(title: day.date.formatted(.dateTime.month().day()) + " · 当日进食",
                                         food: day.food, close: { selected = nil })
                    } else {
                        Text("点击柱状条，查看当天总量、干粮和湿粮的精确克数")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }
                Text("最近 7 天 · 空白日期表示未记录，不代表摄入为零")
                    .font(.caption2).foregroundStyle(.secondary)
            }
        }
        .onChange(of: summaries.map(\.date)) { _, _ in selected = nil }
    }
    private var selectedDay: DaySummary? {
        guard let selected else { return nil }
        return summaries.first { Calendar.current.isDate($0.date, inSameDayAs: selected) }
    }
    private var chartDomain: ClosedRange<Date> {
        let first = summaries.first?.date ?? Calendar.current.startOfDay(for: .now)
        let last = summaries.last?.date ?? first
        return first...(Calendar.current.date(byAdding: .day, value: 1, to: last) ?? last)
    }
    private var monthLabel: String {
        guard let first = summaries.first?.date, let last = summaries.last?.date else { return "" }
        let calendar = Calendar.current
        let firstMonth = calendar.component(.month, from: first)
        let lastMonth = calendar.component(.month, from: last)
        if calendar.isDate(first, equalTo: last, toGranularity: .month) { return "\(lastMonth)月" }
        if calendar.isDate(first, equalTo: last, toGranularity: .year) { return "\(firstMonth)月—\(lastMonth)月" }
        return "\(calendar.component(.year, from: first))/\(firstMonth)—\(calendar.component(.year, from: last))/\(lastMonth)"
    }
}
