import SwiftUI
import SwiftData
import WebKit
import UniformTypeIdentifiers

struct WebDataSyncView: View {
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    @State private var importing = false
    @State private var pending: Data?
    @State private var confirmsImport = false
    @State private var message = ""
    @State private var share: SyncFile?
    struct SyncFile: Identifiable { let url: URL; var id: URL { url } }
    var body: some View {
        NavigationStack {
            VStack(spacing: 8) {
                DisclosureGroup("互通说明与文件备份") {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("网页和本地记录手动双向传递。先在网页登录同一个 ChatGPT 账号，再使用网页“数据与设置”里的互通按钮。不会上传头像，也不会自动跨端删除。")
                        Text("旧 Excel 不含记录 ID，转回 App 时会按时间和内容查重；仅日汇总无法恢复真实明细，会留在网页。请先保存备份。")
                        HStack {
                            Button("导出 JSON") { exportFile() }
                            Spacer()
                            Button("导入 JSON") { importing = true }
                        }
                    }.font(.caption).padding(.vertical, 10)
                }.padding(.horizontal, 16)
                if !message.isEmpty { Text(message).font(.caption).foregroundStyle(DiaryStyle.pink).padding(.horizontal, 16) }
                SyncWebView(modelContext: context, receive: { data in
                    do { _ = try DataInterchangeService.parse(data); pending = data; confirmsImport = true }
                    catch { message = error.localizedDescription }
                }, report: { message = $0 })
            }.background(DiaryStyle.background).navigationTitle("网页数据互通").navigationBarTitleDisplayMode(.inline)
                .toolbar { Button("完成") { dismiss() } }
                .fileImporter(isPresented: $importing, allowedContentTypes: [.json]) { result in
                    do {
                        let url = try result.get(); let access = url.startAccessingSecurityScopedResource()
                        defer { if access { url.stopAccessingSecurityScopedResource() } }
                        let bytes = try Data(contentsOf: url, options: .mappedIfSafe)
                        _ = try DataInterchangeService.parse(bytes); pending = bytes; confirmsImport = true
                    } catch { message = error.localizedDescription }
                }
                .alert("导入网页 / JSON 记录", isPresented: $confirmsImport) {
                    Button("仅补充新记录") { merge(overwrite: false) }
                    Button("覆盖同 ID 记录", role: .destructive) { merge(overwrite: true) }
                    Button("取消", role: .cancel) { pending = nil }
                } message: {
                    Text("即将读取 \(pending.flatMap { try? DataInterchangeService.parse($0).count } ?? 0) 条。建议先仅补充；覆盖会使用文件中的内容更新同 ID 记录。不会删除其他记录，只有日汇总的数据不伪造明细。")
                }
                .sheet(item: $share) { item in SyncShareView(url: item.url) }
        }
    }
    private func merge(overwrite: Bool) {
        guard let pending else { return }
        do { message = try DataInterchangeService.apply(DataInterchangeService.parse(pending), overwrite: overwrite, in: context).text; self.pending = nil }
        catch { context.rollback(); message = error.localizedDescription }
    }
    private func exportFile() {
        do {
            let url = FileManager.default.temporaryDirectory.appendingPathComponent("喵记互通_\(UUID().uuidString).json")
            try DataInterchangeService.export(in: context).write(to: url, options: .atomic)
            share = SyncFile(url: url)
        } catch { message = error.localizedDescription }
    }
}

private struct SyncWebView: UIViewRepresentable {
    let modelContext: ModelContext
    let receive: (Data) -> Void
    let report: (String) -> Void
    func makeCoordinator() -> Coordinator { Coordinator(parent: self) }
    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        configuration.userContentController.add(context.coordinator, name: "miaoji")
        let web = WKWebView(frame: .zero, configuration: configuration)
        web.navigationDelegate = context.coordinator
        web.isOpaque = false; web.backgroundColor = .black
        if let url = URL(string: DataInterchangeService.website) { web.load(URLRequest(url: url)) }
        return web
    }
    func updateUIView(_ webView: WKWebView, context: Context) { context.coordinator.parent = self }
    static func dismantleUIView(_ webView: WKWebView, coordinator: Coordinator) { webView.configuration.userContentController.removeScriptMessageHandler(forName: "miaoji") }
    final class Coordinator: NSObject, WKScriptMessageHandler, WKNavigationDelegate {
        var parent: SyncWebView
        init(parent: SyncWebView) { self.parent = parent }
        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) { parent.report("网页暂时无法打开：" + error.localizedDescription + "。仍可导入导出 JSON 文件。") }
        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            // Authentication pages and third-party frames must never access local diary data.
            guard message.frameInfo.isMainFrame,
                  message.frameInfo.securityOrigin.protocol == "https",
                  message.frameInfo.securityOrigin.host == URL(string: DataInterchangeService.website)?.host,
                  let body = message.body as? [String: Any] else { return }
            do {
                if body["action"] as? String == "export" {
                    let data = try DataInterchangeService.export(in: parent.modelContext)
                    guard let document = try JSONSerialization.jsonObject(with: data) as? [String: Any], let records = document["records"] else { return }
                    let encoded = try JSONSerialization.data(withJSONObject: records)
                    guard let json = String(data: encoded, encoding: .utf8) else { return }
                    message.webView?.evaluateJavaScript("window.miaojiReceiveNative?.(" + json + ")", completionHandler: { _, error in if let error { self.parent.report(error.localizedDescription) } })
                } else if body["action"] as? String == "import" {
                    parent.receive(try JSONSerialization.data(withJSONObject: body))
                }
            } catch { parent.report(error.localizedDescription) }
        }
    }
}
private struct SyncShareView: UIViewControllerRepresentable {
    let url: URL
    func makeUIViewController(context: Context) -> UIActivityViewController { UIActivityViewController(activityItems: [url], applicationActivities: nil) }
    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}
