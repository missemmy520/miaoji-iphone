import Foundation
import SwiftData

enum ExcelInterchangeService {
    static let format = "喵记多宠物 Excel 1"
    static let columns: [(String, String, String)] = [
        ("name", "名字", "text"),
        ("species", "物种", "text"),
        ("birthday", "生日", "text"),
        ("eventAt", "实际时间", "text"),
        ("createdAt", "录入时间", "text"),
        ("foodType", "食物类型代码", "text"),
        ("amountGram", "进食克数", "number"),
        ("count", "排便次数", "number"),
        ("condition", "排便状态", "text"),
        ("descriptionText", "排便描述", "text"),
        ("clumpCount", "尿团数", "number"),
        ("size", "尿团大小", "text"),
        ("shape", "尿团形状", "text"),
        ("weightKg", "体重kg", "number"),
        ("note", "备注", "text"),
        ("foodName", "粮食名称", "text"),
        ("bagTotalGram", "本批总克数", "number"),
        ("openedAt", "开袋时间", "text"),
        ("closedAt", "结束时间", "text"),
        ("manualAdjustmentGram", "初始校准克数", "number"),
        ("isCurrent", "当前批次", "boolean"),
        ("inventoryID", "库存ID", "text"),
        ("beforeGram", "校准前克数", "number"),
        ("afterGram", "校准后克数", "number"),
        ("dry", "汇总干粮g", "number"),
        ("wet", "汇总湿粮g", "number"),
        ("treat", "汇总猫条g", "number"),
        ("other", "汇总其他g", "number"),
        ("stool", "汇总排便次数", "number"),
        ("urine", "汇总尿团数", "number"),
        ("weight", "汇总体重kg", "number")
    ]
    static let kinds: [(String, String)] = [("pet", "宠物资料"), ("feeding", "进食记录"), ("stool", "排便记录"), ("urine", "排尿记录"), ("weight", "体重记录"), ("note", "当日备注"), ("inventory", "粮食库存"), ("adjustment", "库存校准"), ("summary", "历史汇总")]
    @MainActor static func export(in context: ModelContext) throws -> URL {
        let rows = try DataInterchangeService.parse(DataInterchangeService.export(in: context))
        let names = Dictionary(uniqueKeysWithValues: rows.filter { $0.kind == "pet" }.map { ($0.id, $0.string("name")) })
        var sheets = [ExcelSheet(name: "文件说明", rows: [[.text("文件格式"), .text(format)], [.text("设计者"), .text("emmyhuang")], [.text("时间格式"), .text("ISO 8601，保留时区与毫秒")]])]
        for (kind, title) in kinds {
            var values: [[ExcelCell]] = [["记录ID", "宠物ID", "宠物名字"].map { .text($0) } + columns.map { .text($0.1) }]
            for row in rows where row.kind == kind {
                guard let name = names[row.petID] else { throw ExcelWorkbookReader.ReadError.invalid }
                var cells: [ExcelCell] = [.text(row.id.uuidString.lowercased()), .text(row.petID.uuidString.lowercased()), .text(name)]
                for (key, _, type) in columns {
                    guard let value = row.data[key] else { cells.append(.empty); continue }
                    if type == "number", let n = value as? NSNumber { cells.append(.number(n.doubleValue)) }
                    else if type == "boolean", let n = value as? Bool { cells.append(.text(n ? "是" : "否")) }
                    else if let text = value as? String { cells.append(.text(text)) }
                    else { cells.append(.empty) }
                }
                values.append(cells)
            }
            sheets.append(ExcelSheet(name: title, rows: values))
        }
        return try ExcelExportService.write(sheets, petName: "喵记_全部宠物")
    }
    static func parse(_ bytes: Data) throws -> Data {
        let sheets = try ExcelWorkbookReader.read(bytes)
        guard let info = sheets.first(where: { $0.name == "文件说明" }), info.rows.first?.dropFirst().first == format else { throw ExcelWorkbookReader.ReadError.unsupported }
        var records: [[String: Any]] = []
        for (kind, name) in kinds {
            guard let sheet = sheets.first(where: { $0.name == name }), let headers = sheet.rows.first else { continue }
            guard Set(headers).count == headers.count, ["记录ID", "宠物ID"].allSatisfy(headers.contains) else { throw ExcelWorkbookReader.ReadError.invalid }
            for cells in sheet.rows.dropFirst() where cells.contains(where: { !$0.isEmpty }) {
                func text(_ key: String) -> String { guard let i = headers.firstIndex(of: key), cells.indices.contains(i) else { return "" }; return cells[i] }
                var data: [String: Any] = [:], food: [String: Double] = [:]
                for (key, label, type) in columns {
                    let value = text(label); if value.isEmpty { continue }
                    if type == "number" {
                        guard let number = Double(value), number.isFinite else { throw ExcelWorkbookReader.ReadError.invalid }
                        if kind == "summary" && ["dry", "wet", "treat", "other"].contains(key) { food[key] = number } else { data[key] = number }
                    } else if type == "boolean" {
                        guard ["是", "否", "true", "false"].contains(value) else { throw ExcelWorkbookReader.ReadError.invalid }; data[key] = value == "是" || value == "true"
                    } else { data[key] = value }
                }
                if kind == "summary" { data["food"] = food }
                records.append(["id": text("记录ID"), "petID": text("宠物ID"), "kind": kind, "version": 0, "data": data])
            }
        }
        let result = try JSONSerialization.data(withJSONObject: ["format": "miaoji-sync-1", "records": records])
        let parsed = try DataInterchangeService.parse(result)
        let petIDs = Set(parsed.filter { $0.kind == "pet" && $0.id == $0.petID }.map(\.id))
        guard parsed.allSatisfy({ petIDs.contains($0.petID) }) else { throw ExcelWorkbookReader.ReadError.invalid }
        return result
    }
}
