import Foundation
import SwiftData

// Exact pre-v0.9 inventory entity (no foodKindRaw). Compile separately with the
// same module name as the migration reader so this is a real stored-schema test.
@Model final class DryFoodInventory {
    @Attribute(.unique) var id: UUID
    var petID: UUID? = nil
    var foodName: String
    var bagTotalGram: Double
    var openedAt: Date
    var closedAt: Date?
    var manualAdjustmentGram: Double
    var isCurrent: Bool
    init() {
        id = UUID(); foodName = "旧干粮"; bagTotalGram = 2000
        openedAt = Date(timeIntervalSince1970: 1_700_000_000)
        closedAt = nil; manualAdjustmentGram = 0; isCurrent = true
    }
}
@main struct LegacyFixture {
    @MainActor static func main() throws {
        let schema = Schema([DryFoodInventory.self, FeedingRecord.self, InventoryAdjustment.self])
        let config = ModelConfiguration(schema: schema, url: URL(fileURLWithPath: CommandLine.arguments[1]))
        let db = try ModelContainer(for: schema, configurations: [config])
        let bag = DryFoodInventory()
        db.mainContext.insert(bag)
        db.mainContext.insert(FeedingRecord(foodType: .dry, amountGram: 15, eventAt: bag.openedAt.addingTimeInterval(10)))
        try db.mainContext.save()
    }
}
