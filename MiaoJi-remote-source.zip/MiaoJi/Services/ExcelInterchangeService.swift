import Foundation
import CryptoKit
import SwiftData

enum ExcelInterchangeService {
    static let format = "喵记多宠物 Excel 1"
    static let columns: [(String, String, String)] = [
        ("name", "名字", "text"),
        ("species", "物种", "text"),
        ("birthday", "生日", "text"),
        ("eventAt", "实际时间", "text"),
        ("createdAt", "录入时间", "text"),
        ("foodType", "食物类型代码", "text"),
        ("amountGram", "进食克数", "number"),
        ("count", "排便次数", "number"),
        ("condition", "排便状态", "text"),
        ("descriptionText", "排便描述", "text"),
        ("clumpCount", "尿团数", "number"),
        ("size", "尿团大小", "text"),
        ("shape", "尿团形状", "text"),
        ("weightKg", "体重kg", "number"),
        ("note", "备注", "text"),
        ("foodName", "粮食名称", "text"),
        ("bagTotalGram", "本批总克数", "number"),
        ("openedAt", "开袋时间", "text"),
        ("closedAt", "结束时间", "text"),
        ("manualAdjustmentGram", "初始校准克数", "number"),
        ("isCurrent", "当前批次", "boolean"),
        ("inventoryID", "库存ID", "text"),
        ("beforeGram", "校准前克数", "number"),
        ("afterGram", "校准后克数", "number"),
        ("dry", "汇总干粮g", "number"),
        ("wet", "汇总湿粮g", "number"),
        ("treat", "汇总猫条g", "number"),
        ("other", "汇总其他g", "number"),
        ("stool", "汇总排便次数", "number"),
        ("urine", "汇总尿团数", "number"),
        ("weight", "汇总体重kg", "number")
    ]
    static let kinds: [(String, String)] = [("pet", "宠物资料"), ("feeding", "进食记录"), ("stool", "排便记录"), ("urine", "排尿记录"), ("weight", "体重记录"), ("note", "当日备注"), ("inventory", "粮食库存"), ("adjustment", "库存校准"), ("summary", "历史汇总")]
    @MainActor static func export(in context: ModelContext) throws -> URL {
        let rows = try DataInterchangeService.parse(DataInterchangeService.export(in: context))
        let names = Dictionary(uniqueKeysWithValues: rows.filter { $0.kind == "pet" }.map { ($0.id, $0.string("name")) })
        var sheets = [ExcelSheet(name: "文件说明", rows: [[.text("文件格式"), .text(format)], [.text("设计者"), .text("emmyhuang")], [.text("时间格式"), .text("ISO 8601，保留时区与毫秒")]])]
        for (kind, title) in kinds {
            var values: [[ExcelCell]] = [["记录ID", "宠物ID", "宠物名字"].map { .text($0) } + columns.map { .text($0.1) }]
            for row in rows where row.kind == kind {
                guard let name = names[row.petID] else { throw ExcelWorkbookReader.ReadError.invalid }
                var cells: [ExcelCell] = [.text(row.id.uuidString.lowercased()), .text(row.petID.uuidString.lowercased()), .text(name)]
                for (key, _, type) in columns {
                    guard let value = row.data[key] else { cells.append(.empty); continue }
                    if type == "number", let n = value as? NSNumber { cells.append(.number(n.doubleValue)) }
                    else if type == "boolean", let n = value as? Bool { cells.append(.text(n ? "是" : "否")) }
                    else if let text = value as? String { cells.append(.text(text)) }
                    else { cells.append(.empty) }
                }
                values.append(cells)
            }
            sheets.append(ExcelSheet(name: title, rows: values))
        }
        return try ExcelExportService.write(sheets, petName: "喵记_全部宠物")
    }
    static func parse(_ bytes: Data, legacyPetID: UUID? = nil) throws -> Data {
        let sheets = try ExcelWorkbookReader.read(bytes)
        guard let info = sheets.first(where: { $0.name == "文件说明" }), info.rows.first?.dropFirst().first == format else {
            guard let legacyPetID else { throw ExcelWorkbookReader.ReadError.unsupported }
            return try parseLegacy(sheets, petID: legacyPetID)
        }
        var records: [[String: Any]] = []
        for (kind, name) in kinds {
            guard let sheet = sheets.first(where: { $0.name == name }), let headers = sheet.rows.first else { continue }
            guard Set(headers).count == headers.count, ["记录ID", "宠物ID"].allSatisfy(headers.contains) else { throw ExcelWorkbookReader.ReadError.invalid }
            for cells in sheet.rows.dropFirst() where cells.contains(where: { !$0.isEmpty }) {
                func text(_ key: String) -> String { guard let i = headers.firstIndex(of: key), cells.indices.contains(i) else { return "" }; return cells[i] }
                var data: [String: Any] = [:], food: [String: Double] = [:]
                for (key, label, type) in columns {
                    let value = text(label); if value.isEmpty { continue }
                    if type == "number" {
                        guard let number = Double(value), number.isFinite else { throw ExcelWorkbookReader.ReadError.invalid }
                        if kind == "summary" && ["dry", "wet", "treat", "other"].contains(key) { food[key] = number } else { data[key] = number }
                    } else if type == "boolean" {
                        guard ["是", "否", "true", "false"].contains(value) else { throw ExcelWorkbookReader.ReadError.invalid }; data[key] = value == "是" || value == "true"
                    } else { data[key] = value }
                }
                if kind == "summary" { data["food"] = food }
                records.append(["id": text("记录ID"), "petID": text("宠物ID"), "kind": kind, "version": 0, "data": data])
            }
        }
        let result = try JSONSerialization.data(withJSONObject: ["format": "miaoji-sync-1", "records": records])
        let parsed = try DataInterchangeService.parse(result)
        let petIDs = Set(parsed.filter { $0.kind == "pet" && $0.id == $0.petID }.map(\.id))
        guard parsed.allSatisfy({ petIDs.contains($0.petID) }) else { throw ExcelWorkbookReader.ReadError.invalid }
        return result
    }
    private static func parseLegacy(_ sheets: [ExcelWorkbookReader.Sheet], petID: UUID) throws -> Data {
        let definitions: [(String, String, [String])] = [
            ("进食明细", "feeding", ["实际进食时间", "录入时间", "食物类型", "摄入量(g)", "备注"]),
            ("排便明细", "stool", ["实际排便时间", "录入时间", "次数", "状态", "大小/描述", "备注"]),
            ("体重明细", "weight", ["实际测量时间", "录入时间", "体重(kg)", "备注"]),
            ("排尿明细", "urine", ["实际排尿记录时间", "录入时间", "尿团数(坨)", "大小参照", "形状", "备注"])
        ]
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX"); formatter.calendar = Calendar(identifier: .gregorian)
        formatter.timeZone = .current; formatter.dateFormat = "yyyy-MM-dd HH:mm"; formatter.isLenient = false
        let iso = ISO8601DateFormatter(); iso.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        var records: [[String: Any]] = [], occurrences: [String: Int] = [:]
        var found = false
        for (name, kind, expected) in definitions {
            guard let sheet = sheets.first(where: { $0.name == name }) else { continue }
            found = true
            guard let headers = sheet.rows.first, headers == expected else { throw ExcelWorkbookReader.ReadError.invalid }
            for cells in sheet.rows.dropFirst() where cells.contains(where: { !$0.isEmpty }) {
                func cell(_ i: Int) -> String { cells.indices.contains(i) ? cells[i] : "" }
                guard let event = formatter.date(from: cell(0)), formatter.string(from: event) == cell(0),
                      let created = formatter.date(from: cell(1)), formatter.string(from: created) == cell(1) else { throw ExcelWorkbookReader.ReadError.invalid }
                func number(_ i: Int) throws -> Double {
                    guard let n = Double(cell(i)), n.isFinite else { throw ExcelWorkbookReader.ReadError.invalid }; return n
                }
                var data: [String: Any] = ["eventAt": iso.string(from: event), "createdAt": iso.string(from: created)]
                switch kind {
                case "feeding":
                    guard let food = FoodType.allCases.first(where: { $0.title == cell(2) }) else { throw ExcelWorkbookReader.ReadError.invalid }
                    data["foodType"] = food.rawValue; data["amountGram"] = try number(3); data["note"] = cell(4)
                case "stool": data["count"] = try number(2); data["condition"] = cell(3); data["descriptionText"] = cell(4); data["note"] = cell(5)
                case "urine": data["clumpCount"] = try number(2); data["size"] = cell(3); data["shape"] = cell(4); data["note"] = cell(5)
                default: data["weightKg"] = try number(2); data["note"] = cell(3)
                }
                let key = petID.uuidString + name + String(decoding: try JSONSerialization.data(withJSONObject: data, options: [.sortedKeys]), as: UTF8.self)
                let occurrence = occurrences[key, default: 0]; occurrences[key] = occurrence + 1
                let hex = SHA256.hash(data: Data((key + "#" + String(occurrence)).utf8)).prefix(16).map { String(format: "%02x", $0) }.joined()
                let id = String(hex.prefix(8)) + "-" + String(hex.dropFirst(8).prefix(4)) + "-" + String(hex.dropFirst(12).prefix(4)) + "-" + String(hex.dropFirst(16).prefix(4)) + "-" + String(hex.dropFirst(20))
                records.append(["id": id, "petID": petID.uuidString, "kind": kind, "version": 0, "data": data])
            }
        }
        guard found else { throw ExcelWorkbookReader.ReadError.unsupported }
        let result = try JSONSerialization.data(withJSONObject: ["format": "miaoji-sync-1", "records": records])
        _ = try DataInterchangeService.parse(result)
        return result
    }
}
