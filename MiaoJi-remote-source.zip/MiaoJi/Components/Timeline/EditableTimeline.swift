import SwiftUI
import SwiftData

struct EditableTimeline: View {
    let date: Date
    let feedings: [FeedingRecord]
    let stools: [StoolRecord]
    let weights: [WeightRecord]
    let urines: [UrineRecord]
    @Environment(\.modelContext) private var context
    @State private var editing: RecordTarget?
    @State private var deleting: RecordTarget?
    @State private var errorMessage: String?
    private func target(_ id: UUID) -> RecordTarget? {
        if let r = feedings.first(where: { $0.id == id }) { return .feeding(r) }
        if let r = stools.first(where: { $0.id == id }) { return .stool(r) }
        if let r = weights.first(where: { $0.id == id }) { return .weight(r) }
        if let r = urines.first(where: { $0.id == id }) { return .urine(r) }
        return nil
    }
    var body: some View {
        RecordTimeline(entries: TimelineEntry.entries(on: date, feedings: feedings, stools: stools, weights: weights, urines: urines),
                       edit: { editing = target($0) }, delete: { deleting = target($0) })
        .sheet(item: $editing) { record in
            if let petID = record.petID { AddRecordView(petID: petID, editing: record) }
        }
        .confirmationDialog("删除这条记录？删除后将重新计算统计和库存。", isPresented: Binding(get: { deleting != nil }, set: { if !$0 { deleting = nil } }), titleVisibility: .visible) {
            Button("删除记录", role: .destructive) {
                do { try deleting?.delete(in: context); deleting = nil }
                catch { errorMessage = error.localizedDescription; deleting = nil }
            }
            Button("取消", role: .cancel) { deleting = nil }
        }
        .alert("删除失败", isPresented: Binding(get: { errorMessage != nil }, set: { if !$0 { errorMessage = nil } })) {
            Button("好", role: .cancel) { errorMessage = nil }
        } message: { Text(errorMessage ?? "请重试") }
    }
}
