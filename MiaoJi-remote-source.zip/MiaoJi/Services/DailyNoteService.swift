import Foundation
import SwiftData

enum DailyNoteService {
    static func note(on date: Date, petID: UUID, records: [DailyNoteRecord], calendar: Calendar = .current) -> DailyNoteRecord? {
        records.filter { $0.petID == petID && calendar.isDate($0.eventAt, inSameDayAs: date) }
            .max { $0.updatedAt < $1.updatedAt }
    }

    @MainActor static func save(_ text: String, on date: Date, petID: UUID, in context: ModelContext,
                                calendar: Calendar = .current) throws {
        let all = try context.fetch(FetchDescriptor<DailyNoteRecord>(predicate: #Predicate { $0.petID == petID }))
        let matches = all.filter { calendar.isDate($0.eventAt, inSameDayAs: date) }
        let content = text.trimmingCharacters(in: .whitespacesAndNewlines)
        if content.isEmpty {
            matches.forEach { context.delete($0) }
        } else if let existing = matches.max(by: { $0.updatedAt < $1.updatedAt }) {
            existing.text = content
            existing.updatedAt = .now
            matches.filter { $0.id != existing.id }.forEach { context.delete($0) }
        } else {
            context.insert(DailyNoteRecord(petID: petID, eventAt: calendar.startOfDay(for: date), text: content))
        }
        do { try context.save() }
        catch { context.rollback(); throw error }
    }
}
