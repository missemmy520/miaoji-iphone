import Foundation

struct LiteraturePaper: Decodable, Identifiable {
    let id: String
    let source: String
    let title: String
    let authorString: String?
    let pubYear: String?
    let doi: String?
    let abstractText: String?
    var url: URL? { URL(string: "https://europepmc.org/article/" + source + "/" + id) }
    var abstractPreview: String {
        let clean = (abstractText ?? "未提供摘要，请查看原文。")
            .replacingOccurrences(of: "<[^>]+>", with: " ", options: .regularExpression)
            .replacingOccurrences(of: "&lt;", with: "<").replacingOccurrences(of: "&gt;", with: ">")
            .replacingOccurrences(of: "&amp;", with: "&")
        let words = clean.split(whereSeparator: \.isWhitespace)
        return words.prefix(80).joined(separator: " ") + (words.count > 80 ? " …（摘要节选）" : "")
    }
}

enum LiteratureSearchService {
    enum SearchError: LocalizedError {
        case unavailable, invalidQuery
        var errorDescription: String? {
            switch self {
            case .unavailable: return "文献服务暂时无法连接，本地资料仍可使用。"
            case .invalidQuery: return "请在独立的关键词栏输入简短主题（建议英文，最多 300 字符）。"
            }
        }
    }
    private struct Response: Decodable {
        struct Results: Decodable { let result: [LiteraturePaper] }
        let resultList: Results
    }
    static func suggestedTerms(for text: String) -> String {
        // Only pre-reviewed public topic labels leave the device by default.
        // Never fall back to sending the original question or diary content.
        HealthKnowledge.matches(text).first?.searchTerms ?? ""
    }
    static func request(for terms: String) throws -> URLRequest {
        let trimmed = terms.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty, trimmed.count <= 300 else { throw SearchError.invalidQuery }
        let tokens = trimmed.components(separatedBy: CharacterSet.alphanumerics.inverted).filter { !$0.isEmpty && $0 != "OR" }
        guard !tokens.isEmpty else { throw SearchError.invalidQuery }
        let topic = tokens.prefix(20).map { "TITLE_ABS:" + $0 }.joined(separator: " AND ")
        let query = "(TITLE_ABS:feline OR TITLE_ABS:cat OR TITLE_ABS:cats) AND (" + topic + ") AND SRC:MED AND HAS_ABSTRACT:Y"
        var parts = URLComponents(string: "https://www.ebi.ac.uk/europepmc/webservices/rest/search")
        parts?.queryItems = [.init(name: "query", value: query), .init(name: "format", value: "json"),
                             .init(name: "resultType", value: "core"), .init(name: "pageSize", value: "3")]
        guard let url = parts?.url else { throw SearchError.invalidQuery }
        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 25)
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        return request
    }
    static func decode(_ data: Data) throws -> [LiteraturePaper] {
        try JSONDecoder().decode(Response.self, from: data).resultList.result.filter { $0.source == "MED" && !$0.title.isEmpty }
    }
    static func search(_ terms: String) async throws -> [LiteraturePaper] {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 25
        let session = URLSession(configuration: configuration)
        defer { session.invalidateAndCancel() }
        let (data, response) = try await session.data(for: request(for: terms))
        guard let http = response as? HTTPURLResponse, http.statusCode == 200, data.count <= 2_000_000 else { throw SearchError.unavailable }
        return try decode(data)
    }
}
