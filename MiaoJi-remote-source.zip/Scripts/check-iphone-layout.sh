#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p Build/iPhone
DEVICE_ID="$(xcrun simctl list devices available -j | python3 -c 'import json,sys; data=json.load(sys.stdin); phones=[d for devices in data["devices"].values() for d in devices if "iPhone" in d["name"] and d.get("isAvailable")]; preferred=[d for d in phones if d["name"] == "iPhone 16 Pro"]; print((preferred or phones)[0]["udid"])')"
xcrun simctl boot "$DEVICE_ID"
xcrun simctl bootstatus "$DEVICE_ID" -b
xcodebuild -project MiaoJi.xcodeproj -scheme MiaoJi -configuration Release -sdk iphonesimulator -destination "id=$DEVICE_ID" -derivedDataPath Build/Simulator CODE_SIGNING_ALLOWED=NO build > Build/iPhone/simulator.log 2>&1
xcrun simctl install "$DEVICE_ID" Build/Simulator/Build/Products/Release-iphonesimulator/MiaoJi.app
xcrun simctl launch "$DEVICE_ID" com.personal.miaoji -AppleLanguages '(zh-Hans)' -AppleLocale zh_CN
sleep 3
xcrun simctl io "$DEVICE_ID" screenshot Build/iPhone/iPhone-home.png
