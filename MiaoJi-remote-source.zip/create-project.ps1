$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$folders = @('App','Models','Views/Home','Views/Calendar','Views/AddRecord','Views/Statistics','Views/Inventory','Views/Settings','Components/Calendar','Components/Charts','Components/Cards','Components/Timeline','Services','Utilities')
foreach ($folder in $folders) { New-Item -ItemType Directory -Force -Path (Join-Path $root "MiaoJi/$folder") | Out-Null }
$files = Get-ChildItem (Join-Path $root 'MiaoJi') -Recurse -Filter *.swift | Sort-Object FullName
$refs = @(); $builds = @(); $children = @(); $sources = @(); $index = 1
foreach ($file in $files) {
    $ref = ('A{0:X23}' -f $index); $build = ('B{0:X23}' -f $index); $index++
    $relative = $file.FullName.Substring($root.Length + 1).Replace('\','/')
    $refs += "$ref = {isa = PBXFileReference; lastKnownFileType = sourcecode.swift; path = `"$relative`"; sourceTree = SOURCE_ROOT; };"
    $builds += "$build = {isa = PBXBuildFile; fileRef = $ref; };"
    $children += $ref; $sources += $build
}
$project = @"
// !`$*UTF8*`$!
{
archiveVersion = 1;
classes = {};
objectVersion = 56;
objects = {
$($refs -join "`n")
$($builds -join "`n")
C00000000000000000000001 = {isa = PBXProject; attributes = {LastUpgradeCheck = 1600; }; buildConfigurationList = C00000000000000000000002; compatibilityVersion = "Xcode 14.0"; developmentRegion = zh-Hans; knownRegions = ("zh-Hans", en, Base); mainGroup = C00000000000000000000003; productRefGroup = C00000000000000000000004; projectDirPath = ""; projectRoot = ""; targets = (C00000000000000000000005); };
C00000000000000000000002 = {isa = XCConfigurationList; buildConfigurations = (C00000000000000000000010,C00000000000000000000011); defaultConfigurationIsVisible = 0; defaultConfigurationName = Release; };
C00000000000000000000003 = {isa = PBXGroup; children = ($($children -join ','),C00000000000000000000015,C00000000000000000000004); sourceTree = "<group>"; };
C00000000000000000000004 = {isa = PBXGroup; children = (C00000000000000000000006); name = Products; sourceTree = "<group>"; };
C00000000000000000000005 = {isa = PBXNativeTarget; buildConfigurationList = C00000000000000000000007; buildPhases = (C00000000000000000000008,C00000000000000000000009,C00000000000000000000014); buildRules = (); dependencies = (); name = MiaoJi; productName = MiaoJi; productReference = C00000000000000000000006; productType = "com.apple.product-type.application"; };
C00000000000000000000006 = {isa = PBXFileReference; explicitFileType = wrapper.application; includeInIndex = 0; path = MiaoJi.app; sourceTree = BUILT_PRODUCTS_DIR; };
C00000000000000000000007 = {isa = XCConfigurationList; buildConfigurations = (C00000000000000000000012,C00000000000000000000013); defaultConfigurationIsVisible = 0; defaultConfigurationName = Release; };
C00000000000000000000008 = {isa = PBXSourcesBuildPhase; buildActionMask = 2147483647; files = ($($sources -join ',')); runOnlyForDeploymentPostprocessing = 0; };
C00000000000000000000009 = {isa = PBXFrameworksBuildPhase; buildActionMask = 2147483647; files = (); runOnlyForDeploymentPostprocessing = 0; };
C00000000000000000000014 = {isa = PBXResourcesBuildPhase; buildActionMask = 2147483647; files = (C00000000000000000000016); runOnlyForDeploymentPostprocessing = 0; };
C00000000000000000000015 = {isa = PBXFileReference; lastKnownFileType = folder.assetcatalog; path = "MiaoJi/Assets.xcassets"; sourceTree = SOURCE_ROOT; };
C00000000000000000000016 = {isa = PBXBuildFile; fileRef = C00000000000000000000015; };
C00000000000000000000010 = {isa = XCBuildConfiguration; buildSettings = {SDKROOT = iphoneos; IPHONEOS_DEPLOYMENT_TARGET = 17.0; CLANG_ENABLE_MODULES = YES; }; name = Debug; };
C00000000000000000000011 = {isa = XCBuildConfiguration; buildSettings = {SDKROOT = iphoneos; IPHONEOS_DEPLOYMENT_TARGET = 17.0; CLANG_ENABLE_MODULES = YES; }; name = Release; };
C00000000000000000000012 = {isa = XCBuildConfiguration; buildSettings = {CODE_SIGN_STYLE = Automatic; ASSETCATALOG_COMPILER_APPICON_NAME = AppIcon; GENERATE_INFOPLIST_FILE = YES; INFOPLIST_KEY_CFBundleDisplayName = "喵记"; INFOPLIST_KEY_UILaunchScreen_Generation = YES; INFOPLIST_KEY_UIApplicationSceneManifest_Generation = YES; INFOPLIST_KEY_UIApplicationSupportsIndirectInputEvents = YES; INFOPLIST_KEY_UISupportedInterfaceOrientations_iPhone = UIInterfaceOrientationPortrait; MARKETING_VERSION = 0.7.1; CURRENT_PROJECT_VERSION = 11; PRODUCT_BUNDLE_IDENTIFIER = com.personal.miaoji; PRODUCT_NAME = "`$(TARGET_NAME)"; SWIFT_VERSION = 5.0; SWIFT_OPTIMIZATION_LEVEL = "-Onone"; SWIFT_ACTIVE_COMPILATION_CONDITIONS = DEBUG; TARGETED_DEVICE_FAMILY = 1; }; name = Debug; };
C00000000000000000000013 = {isa = XCBuildConfiguration; buildSettings = {CODE_SIGN_STYLE = Automatic; ASSETCATALOG_COMPILER_APPICON_NAME = AppIcon; GENERATE_INFOPLIST_FILE = YES; INFOPLIST_KEY_CFBundleDisplayName = "喵记"; INFOPLIST_KEY_UILaunchScreen_Generation = YES; INFOPLIST_KEY_UIApplicationSceneManifest_Generation = YES; INFOPLIST_KEY_UIApplicationSupportsIndirectInputEvents = YES; INFOPLIST_KEY_UISupportedInterfaceOrientations_iPhone = UIInterfaceOrientationPortrait; MARKETING_VERSION = 0.7.1; CURRENT_PROJECT_VERSION = 11; PRODUCT_BUNDLE_IDENTIFIER = com.personal.miaoji; PRODUCT_NAME = "`$(TARGET_NAME)"; SWIFT_VERSION = 5.0; SWIFT_COMPILATION_MODE = wholemodule; TARGETED_DEVICE_FAMILY = 1; }; name = Release; };
};
rootObject = C00000000000000000000001;
}
"@
$projectDir = Join-Path $root 'MiaoJi.xcodeproj'
New-Item -ItemType Directory -Force -Path $projectDir | Out-Null
[IO.File]::WriteAllText((Join-Path $projectDir 'project.pbxproj'), $project, [Text.UTF8Encoding]::new($false))

