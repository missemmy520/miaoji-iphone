import Foundation
import SwiftData

@Model
final class DryFoodInventory {
    @Attribute(.unique) var id: UUID
    var petID: UUID? = nil
    var foodName: String
    var bagTotalGram: Double
    var openedAt: Date
    var closedAt: Date?
    var manualAdjustmentGram: Double
    var isCurrent: Bool
    // Keep the persisted entity name so existing dry-food stores migrate in place.
    var foodKindRaw: String = "dry"
    var foodKind: InventoryFoodKind { InventoryFoodKind(rawValue: foodKindRaw) ?? .dry }

    init(foodName: String, bagTotalGram: Double, openedAt: Date = .now, foodKind: InventoryFoodKind = .dry) {
        self.id = UUID()
        self.foodName = foodName
        self.bagTotalGram = bagTotalGram
        self.openedAt = openedAt
        self.closedAt = nil
        self.manualAdjustmentGram = 0
        self.isCurrent = true
        self.foodKindRaw = foodKind.rawValue
    }
}

enum InventoryFoodKind: String, CaseIterable, Identifiable {
    case dry, wet
    var id: String { rawValue }
    var title: String { self == .dry ? "干粮" : "湿粮" }
    var foodType: FoodType { self == .dry ? .dry : .wet }
    var newTitle: String { self == .dry ? "开新袋" : "新建湿粮库存" }
}

