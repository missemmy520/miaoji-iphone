import SwiftUI

struct SummaryCards: View {
    let summary: DaySummary
    let previous: DaySummary
    let latestWeight: WeightRecord?
    let isToday: Bool
    var dayWeightOnly = false

    var body: some View {
        LazyVGrid(columns: [GridItem(.adaptive(minimum: 140), alignment: .top)], spacing: 10) { cards }
    }

    @ViewBuilder private var cards: some View {
        metric(isToday ? "今日总进食" : "当日总进食", value: summary.totalGram.map { number($0) + " g" } ?? "未记录",
               detail: feedingDifference, color: DiaryStyle.green, symbol: "fork.knife")
        metric(isToday ? "今日排便" : "当日排便", value: summary.stoolCount.map { "\($0) 次" } ?? "未记录",
               detail: "按实际时间汇总", color: DiaryStyle.amber, symbol: "circle.grid.2x2.fill")
        metric(isToday ? "今日排尿" : "当日排尿", value: summary.urineClumpCount.map { "\($0) 坨" } ?? "未记录",
               detail: "尿团数 · 非毫升尿量", color: DiaryStyle.blue, symbol: "drop.fill")
        metric(dayWeightOnly ? "当日体重" : "最新体重", value: latestWeight.map { $0.weightKg.formatted(.number.precision(.fractionLength(2))) + " kg" } ?? "未记录",
               detail: latestWeight.map { $0.eventAt.formatted(.dateTime.month().day().hour().minute()) } ?? "等待一次称重",
               color: DiaryStyle.blue, symbol: "scalemass.fill")
    }

    private var feedingDifference: String {
        guard let current = summary.totalGram, let previous = previous.totalGram else { return "克 · 实际记录" }
        let change = current - previous
        return "比前日 " + (change > 0 ? "+" : "") + number(change) + " g"
    }
    private func number(_ value: Double) -> String { value.formatted(.number.precision(.fractionLength(0...1))) }

    private func metric(_ title: String, value: String, detail: String, color: Color, symbol: String) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Image(systemName: symbol).foregroundStyle(color).padding(10)
                .background(color.opacity(0.18), in: Circle())
            Text(title).font(.caption).foregroundStyle(.secondary)
            Text(value).font(.system(.title3, design: .rounded, weight: .semibold)).minimumScaleFactor(0.7)
            Text(detail).font(.caption2).foregroundStyle(color)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(12)
        .background(color.opacity(0.08).gradient, in: RoundedRectangle(cornerRadius: 20))
        .overlay(RoundedRectangle(cornerRadius: 20).stroke(color.opacity(0.16)))
    }
}

