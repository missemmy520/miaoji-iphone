import SwiftUI
import SwiftData

struct DailyNoteCard: View {
    let date: Date
    let petID: UUID
    let records: [DailyNoteRecord]
    @State private var showsEditor = false
    private var note: DailyNoteRecord? { DailyNoteService.note(on: date, petID: petID, records: records) }

    var body: some View {
        Button { showsEditor = true } label: {
            DiaryCard {
                VStack(alignment: .leading, spacing: 12) {
                    HStack {
                        Label("当日情况备注", systemImage: "note.text").font(.headline)
                        Spacer()
                        Label(note == nil ? "添加" : "编辑", systemImage: "square.and.pencil")
                            .font(.caption).foregroundStyle(DiaryStyle.pink)
                    }
                    Text(note?.text ?? "标记特殊情况，如呕吐、换粮、精神状态等")
                        .font(.subheadline).foregroundStyle(note == nil ? .secondary : .primary)
                        .multilineTextAlignment(.leading)
                }
            }
        }
        .buttonStyle(.plain)
        .sheet(isPresented: $showsEditor) {
            DailyNoteEditor(date: date, petID: petID, initialText: note?.text ?? "")
        }
    }
}

private struct DailyNoteEditor: View {
    let date: Date
    let petID: UUID
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    @State private var text: String
    @State private var errorMessage: String?
    @State private var confirmsClear = false
    @State private var feedback = 0
    private let hadNote: Bool

    init(date: Date, petID: UUID, initialText: String) {
        self.date = date
        self.petID = petID
        _text = State(initialValue: initialText)
        hadNote = !initialText.isEmpty
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    Text(date.formatted(date: .complete, time: .omitted))
                        .font(.subheadline).foregroundStyle(.secondary)
                    DiaryCard {
                        VStack(alignment: .leading, spacing: 12) {
                            Text("记录这一天的特殊情况").font(.headline)
                            TextField("例如：换了新猫粮，下午吐了一次，精神正常", text: $text, axis: .vertical)
                                .lineLimit(8...16).textFieldStyle(.plain)
                        }
                    }
                    if let errorMessage { Text(errorMessage).foregroundStyle(DiaryStyle.pink) }
                    Button("保存备注") {
                        if hadNote && text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                            confirmsClear = true
                        } else { save() }
                    }.buttonStyle(PinkButtonStyle())
                    if hadNote {
                        Button("清空当日备注", role: .destructive) { confirmsClear = true }
                            .frame(maxWidth: .infinity)
                    }
                }.padding(16)
            }
            .background(DiaryStyle.background)
            .navigationTitle("当日情况备注")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } } }
            .confirmationDialog("清空这一天的情况备注？", isPresented: $confirmsClear, titleVisibility: .visible) {
                Button("清空备注", role: .destructive) { text = ""; save() }
            }
            .sensoryFeedback(.success, trigger: feedback)
        }
        .preferredColorScheme(.dark)
        .tint(DiaryStyle.pink)
    }
    private func save() {
        do {
            try DailyNoteService.save(text, on: date, petID: petID, in: context)
            feedback += 1
            dismiss()
        } catch { errorMessage = "保存失败：" + error.localizedDescription }
    }
}
