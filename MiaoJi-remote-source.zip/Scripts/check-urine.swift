import Foundation
import SwiftData

@main
struct UrineCheck {
    enum Failure: Error { case failed(String) }
    @MainActor static func main() throws {
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent("UrineCheck-" + UUID().uuidString)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: folder) }
        let store = folder.appendingPathComponent("diary.store")
        let pet = UUID(), other = UUID()
        var cal = Calendar(identifier: .gregorian)
        cal.timeZone = TimeZone(identifier: "Asia/Shanghai") ?? .current
        guard let day = cal.date(from: DateComponents(year: 2020, month: 12, day: 31, hour: 23, minute: 50)),
              let next = cal.date(byAdding: .minute, value: 20, to: day) else { throw Failure.failed("dates") }
        func check(_ valid: Bool, _ label: String) throws { if !valid { throw Failure.failed(label) } }
        // The chart detail must use the saved per-food totals, without rounding each record.
        let dryA = FeedingRecord(foodType: .dry, amountGram: 10.5, eventAt: day)
        let dryB = FeedingRecord(foodType: .dry, amountGram: 2.3, eventAt: day)
        let wet = FeedingRecord(foodType: .wet, amountGram: 13.2, eventAt: day)
        let treat = FeedingRecord(foodType: .treat, amountGram: 4, eventAt: day)
        let tomorrow = FeedingRecord(foodType: .wet, amountGram: 99, eventAt: next)
        let feeding = StatisticsService.summary(on: day, feedings: [dryA, dryB, wet, treat, tomorrow], stools: [], weights: [], calendar: cal)
        try check(abs((feeding.totalGram ?? -1) - 30) < 0.000001, "chart total grams")
        try check(abs((feeding.food[.dry] ?? -1) - 12.8) < 0.000001, "chart dry decimal sum")
        try check(abs((feeding.food[.wet] ?? -1) - 13.2) < 0.000001 && feeding.food[.other] == nil, "chart wet and absent category")
        // Reopen an actual v0.7 seven-model disk store with the new eighth model.
        try autoreleasepool {
            let schema = Schema([FeedingRecord.self, StoolRecord.self, WeightRecord.self, CatProfile.self, DryFoodInventory.self, InventoryAdjustment.self, DailyNoteRecord.self])
            let db = try ModelContainer(for: schema, configurations: [ModelConfiguration(schema: schema, url: store)])
            let stool = StoolRecord(count: 2, condition: .normal, eventAt: day); stool.petID = pet
            db.mainContext.insert(stool)
            let note = DailyNoteRecord(petID: pet, eventAt: day, text: "旧备注")
            db.mainContext.insert(note)
            try db.mainContext.save()
        }
        let schema = Schema([FeedingRecord.self, StoolRecord.self, WeightRecord.self, CatProfile.self, DryFoodInventory.self, InventoryAdjustment.self, DailyNoteRecord.self, UrineRecord.self])
        try autoreleasepool {
            let db = try ModelContainer(for: schema, configurations: [ModelConfiguration(schema: schema, url: store)])
            let context = db.mainContext
            try check(try context.fetch(FetchDescriptor<StoolRecord>()).first?.count == 2, "upgrade changed old stool")
            try check(try context.fetch(FetchDescriptor<DailyNoteRecord>()).first?.text == "旧备注", "upgrade lost note")
            try check(try context.fetch(FetchDescriptor<UrineRecord>()).isEmpty, "upgrade fabricated urine")
            var d = RecordDraft(); d.kind = .urine; d.count = 2; d.urineSize = .small; d.urineShape = .flat; d.eventAt = day
            try RecordService.save(d, petID: pet, in: context)
            let rows = try context.fetch(FetchDescriptor<UrineRecord>())
            guard let first = rows.first else { throw Failure.failed("insert") }
            let created = first.createdAt
            d.count = 3
            try RecordService.save(d, petID: pet, editing: .urine(first), in: context)
            try check(first.createdAt == created && first.clumpCount == 3 && first.size == .small && first.shape == .flat, "edit")
            try check(RecordTarget.urine(first).draft.count == 3 && RecordTarget.urine(first).draft.urineShape == .flat, "edit draft")
            do {
                try RecordService.save(d, petID: other, editing: .urine(first), in: context)
                throw Failure.failed("cross-pet edit accepted")
            } catch RecordService.ValidationError.differentPet {}
            d.count = -1
            do {
                try RecordService.save(d, petID: pet, in: context)
                throw Failure.failed("negative accepted")
            } catch RecordService.ValidationError.invalidUrineCount {}
            d.count = 1; d.urineSize = .large; d.urineShape = .rounded
            try RecordService.save(d, petID: pet, in: context)
            d.count = 0; d.eventAt = next
            try RecordService.save(d, petID: pet, in: context)
            d.count = 99
            try RecordService.save(d, petID: other, in: context)
        }
        try autoreleasepool {
            let db = try ModelContainer(for: schema, configurations: [ModelConfiguration(schema: schema, url: store)])
            let context = db.mainContext
            let all = try context.fetch(FetchDescriptor<UrineRecord>())
            let rows = all.filter { $0.petID == pet }
            try check(rows.count == 3, "reopen persistence")
            let stools = try context.fetch(FetchDescriptor<StoolRecord>())
            let s = StatisticsService.summary(on: day, feedings: [], stools: stools, weights: [], urines: rows, calendar: cal)
            try check(s.stoolCount == 2 && s.urineClumpCount == 4, "separate daily totals")
            let zero = StatisticsService.summary(on: next, feedings: [], stools: [], weights: [], urines: rows, calendar: cal)
            try check(zero.urineClumpCount == 0 && zero.stoolCount == nil, "explicit zero")
            let empty = StatisticsService.summary(on: day.addingTimeInterval(-86400), feedings: [], stools: [], weights: [], urines: rows, calendar: cal)
            try check(empty.urineClumpCount == nil, "missing became zero")
            try check(StatisticsService.urineAverage(rows, calendar: cal) == 2, "observed-day average")
            let sheets = ExcelExportService.sheets(feedings: [], stools: stools, weights: [], urines: rows)
            try check(sheets.count == 5 && sheets[4].name == "排尿明细" && sheets[4].rows.count == 4, "urine details export")
            let noteOnly = ExcelExportService.sheets(feedings: [], stools: [], weights: [], urines: [rows.first { $0.clumpCount == 0 }].compactMap { $0 })
            try check(noteOnly[0].rows.count == 2 && noteOnly[0].rows[1].count == 10, "urine-only date export")
            if case .number(0) = noteOnly[0].rows[1][9] {} else { throw Failure.failed("export zero") }
            for cell in noteOnly[0].rows[1][1...8] { if case .empty = cell {} else { throw Failure.failed("export invented health data") } }
            guard let first = rows.first(where: { $0.clumpCount == 3 }) else { throw Failure.failed("delete target") }
            try RecordTarget.urine(first).delete(in: context)
            let remaining = try context.fetch(FetchDescriptor<UrineRecord>()).filter { $0.petID == pet }
            try check(StatisticsService.summary(on: day, feedings: [], stools: stools, weights: [], urines: remaining, calendar: cal).urineClumpCount == 1, "delete total")
            try check(try context.fetch(FetchDescriptor<StoolRecord>()).first?.count == 2, "urine affected stool")
        }
        print("Urine checks passed: v0.7 disk migration, CRUD, creation time, pet isolation, local-day/year, size+shape, missing/zero and five-sheet export.")
    }
}
