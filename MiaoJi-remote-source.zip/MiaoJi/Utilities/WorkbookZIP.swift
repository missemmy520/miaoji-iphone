import Foundation

/// ZIP STORE writer for the small, standards-based OOXML package. No external dependency.
/// Each member uses CRC-32, UTF-8 names, central-directory records and ZIP32 size checks.
struct WorkbookZIP {
    enum ZIPError: LocalizedError {
        case tooLarge
        var errorDescription: String? { "导出文件过大，请缩小日期范围。" }
    }
    private struct Member { let name: Data; let crc: UInt32; let size: UInt32; let offset: UInt32 }
    private var output = Data()
    private var members: [Member] = []
    mutating func add(_ name: String, content: String) throws {
        let bytes = Data(content.utf8), filename = Data(name.utf8)
        guard bytes.count < Int(UInt32.max), output.count < Int(UInt32.max), filename.count <= Int(UInt16.max) else { throw ZIPError.tooLarge }
        let crc = Self.crc32(bytes)
        let member = Member(name: filename, crc: crc, size: UInt32(bytes.count), offset: UInt32(output.count))
        output.le(UInt32(0x04034b50)); output.le(UInt16(20)); output.le(UInt16(0x0800)); output.le(UInt16(0))
        output.le(UInt16(0)); output.le(UInt16(33)); output.le(crc); output.le(member.size); output.le(member.size)
        output.le(UInt16(filename.count)); output.le(UInt16(0)); output.append(filename); output.append(bytes)
        members.append(member)
    }
    mutating func finish() throws -> Data {
        guard output.count < Int(UInt32.max), members.count <= Int(UInt16.max) else { throw ZIPError.tooLarge }
        let offset = UInt32(output.count)
        for m in members {
            output.le(UInt32(0x02014b50)); output.le(UInt16(20)); output.le(UInt16(20)); output.le(UInt16(0x0800)); output.le(UInt16(0))
            output.le(UInt16(0)); output.le(UInt16(33)); output.le(m.crc); output.le(m.size); output.le(m.size)
            output.le(UInt16(m.name.count)); output.le(UInt16(0)); output.le(UInt16(0)); output.le(UInt16(0)); output.le(UInt16(0))
            output.le(UInt32(0)); output.le(m.offset); output.append(m.name)
        }
        guard output.count < Int(UInt32.max) else { throw ZIPError.tooLarge }
        let size = UInt32(output.count) - offset
        output.le(UInt32(0x06054b50)); output.le(UInt16(0)); output.le(UInt16(0)); output.le(UInt16(members.count)); output.le(UInt16(members.count))
        output.le(size); output.le(offset); output.le(UInt16(0))
        return output
    }
    private static let table: [UInt32] = (0..<256).map { value in
        var crc = UInt32(value)
        for _ in 0..<8 { crc = (crc & 1) == 1 ? (crc >> 1) ^ 0xedb88320 : crc >> 1 }
        return crc
    }
    private static func crc32(_ bytes: Data) -> UInt32 {
        var crc: UInt32 = 0xffffffff
        for byte in bytes { crc = (crc >> 8) ^ table[Int((crc ^ UInt32(byte)) & 0xff)] }
        return crc ^ 0xffffffff
    }
}
private extension Data {
    mutating func le<T: FixedWidthInteger>(_ value: T) {
        var littleEndian = value.littleEndian
        Swift.withUnsafeBytes(of: &littleEndian) { append(contentsOf: $0) }
    }
}
