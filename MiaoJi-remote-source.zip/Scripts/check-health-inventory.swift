import Foundation
import SwiftData

@main struct HealthInventoryCheck {
    enum Failure: Error { case check(String) }
    @MainActor static func main() throws {
        func check(_ value: Bool, _ label: String) throws { if !value { throw Failure.check(label) } }
        let schema = Schema([DryFoodInventory.self, FeedingRecord.self, InventoryAdjustment.self])
        let config = ModelConfiguration(schema: schema, url: URL(fileURLWithPath: CommandLine.arguments[1]))
        let db = try ModelContainer(for: schema, configurations: [config])
        guard let old = try db.mainContext.fetch(FetchDescriptor<DryFoodInventory>()).first else { throw Failure.check("missing legacy bag") }
        let existing = try db.mainContext.fetch(FetchDescriptor<FeedingRecord>())
        try check(old.foodKind == .dry && old.foodKindRaw == "dry" && old.foodName == "旧干粮", "legacy property default migration")
        let now = old.openedAt.addingTimeInterval(1000)
        try check(InventoryService.snapshot(bag: old, feedings: existing, adjustments: [], at: now).remaining == 1985, "old inventory preserved")
        let wet = DryFoodInventory(foodName: "罐头批次", bagTotalGram: 800, openedAt: old.openedAt, foodKind: .wet)
        db.mainContext.insert(wet)
        let meal = FeedingRecord(foodType: .wet, amountGram: 30, eventAt: now.addingTimeInterval(-100))
        db.mainContext.insert(meal)
        try db.mainContext.save()
        try check(old.isCurrent && wet.isCurrent, "separate current inventories")
        try check(InventoryService.snapshot(bag: wet, feedings: existing + [meal], adjustments: [], at: now).remaining == 770, "wet subtract only wet")
        try check(InventoryService.snapshot(bag: old, feedings: existing + [meal], adjustments: [], at: now).remaining == 1985, "wet did not change dry")
        meal.amountGram = 40
        try check(InventoryService.snapshot(bag: wet, feedings: [meal], adjustments: [], at: now).remaining == 760, "edit recalculates")
        let adjustment = InventoryAdjustment(inventoryID: wet.id, beforeGram: 760, afterGram: 700, eventAt: now.addingTimeInterval(-50), note: nil)
        let later = FeedingRecord(foodType: .wet, amountGram: 12.5, eventAt: now)
        try check(InventoryService.snapshot(bag: wet, feedings: [meal, later], adjustments: [adjustment], at: now).remaining == 687.5, "calibrated baseline")
        try check(InventoryService.snapshot(bag: wet, feedings: [], adjustments: [], at: now).remaining == 800, "delete restores")
        let otherMeal = FeedingRecord(foodType: .wet, amountGram: 100, eventAt: now); otherMeal.petID = UUID()
        try check(InventoryService.snapshot(bag: wet, feedings: [otherMeal], adjustments: [], at: now).remaining == 800, "pet isolation")
        try check(InventoryService.snapshot(bag: wet, feedings: [], adjustments: [], at: now).days == nil, "no fabricated forecast")
        try db.mainContext.save()
        let pet = UUID()
        let empty = HealthAnalysisService.observations(petID: pet, feedings: [], weights: [], stools: [], urines: [], at: now)
        try check(empty.first?.text.contains("未记录不等于没有吃") == true, "missing not zero")
        try check(HealthAnalysisService.reply(to: "精神差而且呕吐", species: "猫").topics.contains { $0.id == "vomit" }, "supplementary context")
        try check(HealthAnalysisService.reply(to: "尿不出来", species: "猫").text.contains("立即"), "urgent urine guidance")
        try check(HealthAnalysisService.reply(to: "没见过的新疾病", species: "猫").topics.isEmpty, "unknown no hallucination")
        try check(HealthAnalysisService.reply(to: "不吃", species: "狗").topics.isEmpty, "no feline advice for dogs")
        let ids = Set(HealthKnowledge.sources.map(\.id))
        try check(ids.count == HealthKnowledge.sources.count, "unique citations")
        for topic in HealthKnowledge.topics { try check(!topic.sourceIDs.isEmpty && topic.sourceIDs.allSatisfy(ids.contains), "citation resolution") }
        try check(LiteratureSearchService.suggestedTerms(for: "私人信息和未知情况").isEmpty, "never send original unmatched consultation")
        let request = try LiteratureSearchService.request(for: "feline vomiting")
        try check(request.url?.host == "www.ebi.ac.uk" && request.url?.scheme == "https", "official HTTPS endpoint")
        let fixture = Data("{\"resultList\":{\"result\":[{\"id\":\"1\",\"source\":\"MED\",\"title\":\"Real response\",\"abstractText\":\"<b>Text</b>\"}]}}".utf8)
        let decoded = try LiteratureSearchService.decode(fixture)
        try check(decoded.count == 1 && decoded[0].abstractPreview == "Text", "parse real contract and strip markup")
        print("PASS: real legacy inventory migration; independent dry/wet; edits/deletes/calibration; pet isolation; source integrity; adviser missing data and urgent/unknown cases; query privacy; literature decoding")
    }
}
