import Foundation

struct DaySummary {
    let date: Date
    let food: [FoodType: Double]
    let stoolCount: Int?
    let weight: WeightRecord?
    var totalGram: Double? { food.isEmpty ? nil : food.values.reduce(0, +) }
}

enum StatisticsService {
    static func summary(on date: Date, feedings: [FeedingRecord], stools: [StoolRecord],
                        weights: [WeightRecord], calendar: Calendar = .current) -> DaySummary {
        let meals = feedings.filter { calendar.isDate($0.eventAt, inSameDayAs: date) }
        let events = stools.filter { calendar.isDate($0.eventAt, inSameDayAs: date) }
        let food = Dictionary(grouping: meals, by: \.foodType).mapValues { $0.reduce(0) { $0 + $1.amountGram } }
        return DaySummary(date: calendar.startOfDay(for: date), food: food,
                          stoolCount: events.isEmpty ? nil : events.reduce(0) { $0 + $1.count },
                          weight: weights.filter { calendar.isDate($0.eventAt, inSameDayAs: date) }
                            .max { $0.eventAt < $1.eventAt })
    }

    static func recentDays(ending date: Date, count: Int = 7, calendar: Calendar = .current) -> [Date] {
        (0..<count).reversed().compactMap {
            calendar.date(byAdding: .day, value: -$0, to: calendar.startOfDay(for: date))
        }
    }

    static func week(containing date: Date, calendar: Calendar = .current) -> [Date] {
        let day = calendar.startOfDay(for: date)
        let weekday = calendar.component(.weekday, from: day)
        let mondayOffset = (weekday + 5) % 7
        guard let start = calendar.date(byAdding: .day, value: -mondayOffset, to: day) else { return [] }
        return (0..<7).compactMap { calendar.date(byAdding: .day, value: $0, to: start) }
    }
}

extension StatisticsService {
    static func dayIndex(feedings: [FeedingRecord], stools: [StoolRecord], weights: [WeightRecord], calendar: Calendar = .current) -> [Date: DaySummary] {
        let meals = Dictionary(grouping: feedings, by: { calendar.startOfDay(for: $0.eventAt) })
        let toilet = Dictionary(grouping: stools, by: { calendar.startOfDay(for: $0.eventAt) })
        let weighing = Dictionary(grouping: weights, by: { calendar.startOfDay(for: $0.eventAt) })
        let days = Set(meals.keys).union(toilet.keys).union(weighing.keys)
        return Dictionary(uniqueKeysWithValues: days.map { day in
            (day, summary(on: day, feedings: meals[day] ?? [], stools: toilet[day] ?? [], weights: weighing[day] ?? [], calendar: calendar))
        })
    }
    static func foodAverage(_ records: [FeedingRecord], calendar: Calendar = .current) -> Double? {
        let count = Set(records.map { calendar.startOfDay(for: $0.eventAt) }).count
        return count > 0 ? records.reduce(0) { $0 + $1.amountGram } / Double(count) : nil
    }
    static func stoolAverage(_ records: [StoolRecord], calendar: Calendar = .current) -> Double? {
        let count = Set(records.map { calendar.startOfDay(for: $0.eventAt) }).count
        return count > 0 ? Double(records.reduce(0) { $0 + $1.count }) / Double(count) : nil
    }
}
