"""Validate a real arm64 iPhone IPA; does not claim signing or installation success."""
from pathlib import Path, PurePosixPath
import plistlib
import struct
import sys
import zipfile


def verify(path):
    path = Path(path)
    if not path.is_file():
        raise ValueError(f"IPA not found: {path}")
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        if len(names) != len(set(names)):
            raise ValueError("Duplicate archive paths")
        for name in names:
            p = PurePosixPath(name)
            if p.is_absolute() or ".." in p.parts or "\\" in name:
                raise ValueError(f"Invalid archive path: {name}")
        damaged = z.testzip()
        if damaged:
            raise ValueError(f"Archive CRC failure: {damaged}")
        apps = [n for n in names if n.startswith("Payload/") and n.endswith(".app/Info.plist") and len(PurePosixPath(n).parts) == 3]
        if len(apps) != 1:
            raise ValueError("Expected exactly one Payload/*.app/Info.plist")
        info = plistlib.loads(z.read(apps[0]))
        if "iPhoneOS" not in info.get("CFBundleSupportedPlatforms", []):
            raise ValueError("Not an iPhoneOS device build")
        if 1 not in info.get("UIDeviceFamily", []):
            raise ValueError("Build does not support iPhone")
        if info.get("CFBundleIdentifier") != "com.personal.miaoji":
            raise ValueError("Unexpected bundle identifier")
        executable = info.get("CFBundleExecutable", "")
        if not executable or PurePosixPath(executable).name != executable:
            raise ValueError("Invalid executable name")
        binary = z.read(str(PurePosixPath(apps[0]).parent / executable))
        if len(binary) < 32:
            raise ValueError("Missing Mach-O executable")
        magic, cpu, _, file_type, commands, command_bytes, _, _ = struct.unpack_from("<8I", binary)
        if magic != 0xFEEDFACF or cpu != 0x0100000C or file_type != 2:
            raise ValueError("Expected a thin arm64 Mach-O application executable")
        if 32 + command_bytes > len(binary):
            raise ValueError("Truncated Mach-O load commands")
        offset, platform = 32, None
        for _ in range(commands):
            if offset + 8 > 32 + command_bytes:
                raise ValueError("Load command outside Mach-O header")
            command, size = struct.unpack_from("<2I", binary, offset)
            if size < 8 or offset + size > 32 + command_bytes:
                raise ValueError("Invalid Mach-O load command size")
            if command == 0x32:
                if size < 24:
                    raise ValueError("Truncated LC_BUILD_VERSION")
                platform = struct.unpack_from("<I", binary, offset + 8)[0]
            if command == 0x2C:
                if size < 24 or struct.unpack_from("<I", binary, offset + 16)[0] != 0:
                    raise ValueError("Encrypted or malformed executable")
            offset += size
        if platform != 2:
            raise ValueError("Mach-O is not an iOS device build (simulator is rejected)")
    return info


if __name__ == "__main__":
    try:
        if len(sys.argv) != 2:
            raise ValueError("Usage: python3 Scripts/verify-ipa.py path/to/app.ipa")
        info = verify(sys.argv[1])
        print(f"Device IPA structure verified: {info['CFBundleIdentifier']}, arm64 iOS, version {info.get('CFBundleShortVersionString', '?')}")
        print("Unsigned artifact only; signing and iPhone installation are separate steps.")
    except (ValueError, OSError, KeyError, zipfile.BadZipFile, plistlib.InvalidFileException) as error:
        print(f"IPA verification failed: {error}", file=sys.stderr)
        sys.exit(1)
