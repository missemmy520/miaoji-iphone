import SwiftUI

struct DiaryCalendarView: View {
    let petID: UUID
    let feedings: [FeedingRecord]
    let stools: [StoolRecord]
    let weights: [WeightRecord]
    let dailyNotes: [DailyNoteRecord]
    @State private var selected = Date.now
    @State private var mode = CalendarMode.month
    @State private var showsJump = false
    @State private var feedback = 0
    enum CalendarMode: String, CaseIterable { case year = "全年", month = "整月", week = "一周" }

    var body: some View {
        let index = StatisticsService.dayIndex(feedings: feedings, stools: stools, weights: weights)
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                HStack {
                    Text("日历 🐾").font(.largeTitle.bold())
                    Spacer()
                    Button("今天") { animate { selected = .now; mode = .month } }
                }
                DiaryCard {
                    VStack(spacing: 16) {
                        HStack {
                            Button { shift(-1) } label: { Image(systemName: "chevron.left").padding(8) }.accessibilityLabel("上一页")
                            Spacer()
                            Button { showsJump = true } label: {
                                Text(mode == .year ? selected.formatted(.dateTime.year()) : selected.formatted(.dateTime.year().month(.wide)))
                                    .font(.headline)
                                Image(systemName: "chevron.down").font(.caption)
                            }
                            Spacer()
                            Button { shift(1) } label: { Image(systemName: "chevron.right").padding(8) }.accessibilityLabel("下一页")
                        }
                        Picker("日历范围", selection: $mode) {
                            ForEach(CalendarMode.allCases, id: \.self) { Text($0.rawValue) }
                        }.pickerStyle(.segmented)
                        if mode == .year {
                            LazyVGrid(columns: [GridItem(.adaptive(minimum: 145))], spacing: 18) {
                                ForEach(DiaryDates.months(selected), id: \.self) { month in
                                    VStack(spacing: 8) {
                                        Button(month.formatted(.dateTime.month(.wide))) { animate { selected = month; mode = .month } }
                                            .font(.headline)
                                        monthGrid(month, compact: true, index: index)
                                    }.padding(6).background(.white.opacity(0.025), in: RoundedRectangle(cornerRadius: 14))
                                }
                            }.transition(.opacity.combined(with: .move(edge: .top)))
                            Button("收起年度，查看所选月", systemImage: "chevron.up") { animate { mode = .month } }.font(.caption)
                        } else if mode == .month {
                            monthGrid(selected, compact: false, index: index).transition(.opacity.combined(with: .move(edge: .top)))
                            Button("收起到所选周", systemImage: "chevron.up") { animate { mode = .week } }.font(.caption)
                        } else {
                            daysGrid(StatisticsService.week(containing: selected), compact: false, index: index)
                            Button("展开完整月历", systemImage: "chevron.down") { animate { mode = .month } }.font(.caption)
                        }
                    }
                }
                Text(selected.formatted(.dateTime.month().day().weekday(.wide))).font(.title2.bold())
                SummaryCards(summary: summary, previous: previous, latestWeight: summary.weight,
                             isToday: Calendar.current.isDateInToday(selected), dayWeightOnly: true)
                Text("当日记录").font(.title3.bold())
                EditableTimeline(date: selected, feedings: feedings, stools: stools, weights: weights)
                DailyNoteCard(date: selected, petID: petID, records: dailyNotes)
            }.padding(16)
        }
        .background(DiaryStyle.background)
        .animation(.spring(response: 0.35, dampingFraction: 0.88), value: mode)
        .sensoryFeedback(.selection, trigger: feedback)
        .sheet(isPresented: $showsJump) { CalendarJumpView(date: $selected) }
    }
    private var summary: DaySummary { StatisticsService.summary(on: selected, feedings: feedings, stools: stools, weights: weights) }
    private var previous: DaySummary {
        StatisticsService.summary(on: Calendar.current.date(byAdding: .day, value: -1, to: selected) ?? selected,
                                  feedings: feedings, stools: stools, weights: weights)
    }
    private func animate(_ change: () -> Void) {
        withAnimation(.spring(response: 0.35, dampingFraction: 0.88), change)
        feedback += 1
    }
    private func shift(_ direction: Int) {
        let unit: Calendar.Component = mode == .year ? .year : mode == .month ? .month : .day
        let step = mode == .week ? direction * 7 : direction
        if let next = Calendar.current.date(byAdding: unit, value: step, to: selected) { animate { selected = next } }
    }
    private func monthGrid(_ month: Date, compact: Bool, index: [Date: DaySummary]) -> some View {
        daysGrid(DiaryDates.monthDays(month), compact: compact, month: month, index: index)
    }
    private func daysGrid(_ days: [Date], compact: Bool, month: Date? = nil, index: [Date: DaySummary]) -> some View {
        LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 0), count: 7), spacing: compact ? 3 : 10) {
            ForEach(Array(["一", "二", "三", "四", "五", "六", "日"].enumerated()), id: \.offset) { _, label in
                Text(label).font(compact ? .system(size: 9) : .caption).foregroundStyle(.secondary)
            }
            ForEach(days, id: \.self) { day in
                Button {
                    animate { selected = day; mode = compact ? .month : .week }
                } label: {
                    VStack(spacing: compact ? 2 : 4) {
                        Text(String(Calendar.current.component(.day, from: day)))
                            .font(compact ? .system(size: 11) : .subheadline)
                            .lineLimit(1)
                            .minimumScaleFactor(0.85)
                            .frame(maxWidth: .infinity).frame(height: compact ? 20 : 34)
                            .foregroundStyle(dayColor(day))
                            .background(Calendar.current.isDate(day, inSameDayAs: selected) ? (DiaryDates.isFutureDay(day) ? DiaryStyle.card : DiaryStyle.pink) : .clear, in: Capsule())
                            .overlay(Capsule().stroke(Calendar.current.isDateInToday(day) ? DiaryStyle.pink : .clear, lineWidth: 1))
                        HStack(spacing: 2) {
                            ForEach(Array(colors(day, index: index).prefix(3).enumerated()), id: \.offset) { _, color in
                                Circle().fill(color).frame(width: compact ? 2 : 4, height: compact ? 2 : 4)
                            }
                        }.frame(height: compact ? 2 : 4)
                    }.opacity(month.map { Calendar.current.isDate(day, equalTo: $0, toGranularity: .month) ? 1 : 0.25 } ?? 1)
                }.buttonStyle(.plain).accessibilityLabel(day.formatted(date: .complete, time: .omitted))
            }
        }
    }
    private func colors(_ day: Date, index: [Date: DaySummary]) -> [Color] {
        let s = index[Calendar.current.startOfDay(for: day)] ?? DaySummary(date: day, food: [:], stoolCount: nil, weight: nil)
        var result: [Color] = []
        if s.food[.wet] != nil { result.append(DiaryStyle.pink) }
        if s.food[.dry] != nil { result.append(DiaryStyle.green) }
        if s.stoolCount != nil { result.append(DiaryStyle.amber) }
        if s.weight != nil { result.append(DiaryStyle.blue) }
        if result.isEmpty && !s.food.isEmpty { result.append(.gray) }
        if dailyNotes.contains(where: { Calendar.current.isDate($0.eventAt, inSameDayAs: day) }) { result.append(.gray) }
        return result
    }
    private func dayColor(_ day: Date) -> Color {
        if DiaryDates.isFutureDay(day) { return .gray }
        return Calendar.current.isDate(day, inSameDayAs: selected) ? DiaryStyle.background : .white
    }
}

private struct CalendarJumpView: View {
    @Binding var date: Date
    @Environment(\.dismiss) private var dismiss
    @State private var year = ""
    @State private var month = 1
    @State private var error = false
    var body: some View {
        NavigationStack {
            VStack(spacing: 24) {
                DiaryCard {
                    VStack(spacing: 18) {
                        TextField("年份，例如 2026", text: $year).keyboardType(.numberPad)
                        Picker("月份", selection: $month) { ForEach(1...12, id: \.self) { Text("\($0)月").tag($0) } }
                    }
                }
                if error { Text("请输入有效年份（1—9999）。").foregroundStyle(.pink) }
                Button("查看") {
                    guard let value = Int(year), (1...9999).contains(value),
                          let result = Calendar.current.date(from: DateComponents(year: value, month: month, day: 1)) else { error = true; return }
                    date = result; dismiss()
                }.buttonStyle(PinkButtonStyle())
                Spacer()
            }.padding(20).background(DiaryStyle.background)
             .navigationTitle("跳转年月").toolbar { Button("取消") { dismiss() } }
             .onAppear { year = String(Calendar.current.component(.year, from: date)); month = Calendar.current.component(.month, from: date) }
        }
    }
}


