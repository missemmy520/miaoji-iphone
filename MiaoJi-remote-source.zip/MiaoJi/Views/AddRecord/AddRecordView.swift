import SwiftUI
import SwiftData
import UIKit

struct AddRecordView: View {
    let petID: UUID
    var editing: RecordTarget? = nil
    @State private var loadedDraft = false
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var modelContext
    @State private var draft = RecordDraft()
    @State private var showsTime = false
    @State private var errorMessage: String?
    @State private var saving = false
    @State private var selectionFeedback = 0
    @FocusState private var inputFocused: Bool

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 14) {
                    kindSelector.disabled(editing != nil)
                    switch draft.kind {
                    case .feeding: feedingFields
                    case .stool: stoolFields
                    case .weight: weightFields
                    }
                    timeFields
                    DiaryCard {
                        VStack(alignment: .leading, spacing: 14) {
                            Text("备注（可选）").font(.headline)
                            TextField("例如：换了新猫粮、食欲很好…", text: $draft.note, axis: .vertical)
                                .lineLimit(3...5)
                                .focused($inputFocused)
                        }
                    }
                }
                .padding(16)
            }
            .scrollDismissesKeyboard(.interactively)
            .background(DiaryStyle.background)
            .navigationTitle(editing == nil ? "新增记录" : "编辑记录")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("取消") { dismiss() }
                }
                ToolbarItemGroup(placement: .keyboard) {
                    Spacer()
                    Button("完成") { inputFocused = false }
                }
            }
            .safeAreaInset(edge: .bottom) {
                Button(action: save) {
                    Label(saving ? "正在保存…" : "保存记录", systemImage: "checkmark")
                }
                .buttonStyle(PinkButtonStyle())
                .disabled(saving)
                .padding(.horizontal, 16).padding(.vertical, 10)
                .background(DiaryStyle.background)
            }
            .alert("未能保存记录", isPresented: Binding(
                get: { errorMessage != nil },
                set: { if !$0 { errorMessage = nil } }
            )) {
                Button("好", role: .cancel) { errorMessage = nil }
            } message: { Text(errorMessage ?? "请重试") }
            .sensoryFeedback(.selection, trigger: selectionFeedback)
        }
        .interactiveDismissDisabled(saving)
        .onAppear {
            if !loadedDraft { if let editing { draft = editing.draft }; loadedDraft = true }
        }
    }

    private var kindSelector: some View {
        HStack(spacing: 8) {
            ForEach(RecordKind.allCases) { kind in
                Button {
                    inputFocused = false
                    draft.kind = kind
                    selectionFeedback += 1
                } label: {
                    Label(kind.rawValue, systemImage: kind.symbol)
                        .font(.headline)
                        .frame(maxWidth: .infinity).padding(.vertical, 18)
                        .foregroundStyle(draft.kind == kind ? DiaryStyle.background : .white)
                        .background(draft.kind == kind ? DiaryStyle.pink : DiaryStyle.card,
                                    in: RoundedRectangle(cornerRadius: 20))
                }.buttonStyle(.plain)
            }
        }
    }

    private var feedingFields: some View {
        Group {
            DiaryCard {
                VStack(alignment: .leading, spacing: 16) {
                    Text("食物类型").font(.headline)
                    HStack(spacing: 8) {
                        ForEach(FoodType.allCases) { type in
                            Button {
                                draft.foodType = type
                                selectionFeedback += 1
                            } label: {
                                VStack(spacing: 12) {
                                    Image(systemName: type.symbol).font(.title2)
                                    Text(type.title).font(.subheadline)
                                }
                                .frame(maxWidth: .infinity).padding(.vertical, 18)
                                .foregroundStyle(type.color)
                                .background(type.color.opacity(0.12), in: RoundedRectangle(cornerRadius: 18))
                                .overlay(RoundedRectangle(cornerRadius: 18)
                                    .stroke(draft.foodType == type ? DiaryStyle.pink : .clear, lineWidth: 2))
                            }
                            .buttonStyle(.plain)
                            .accessibilityAddTraits(draft.foodType == type ? .isSelected : [])
                        }
                    }
                }
            }
            DiaryCard {
                VStack(alignment: .leading, spacing: 16) {
                    Text("进食量").font(.headline)
                    numberField("输入克数", text: $draft.amount, unit: "g")
                    HStack(spacing: 6) {
                        ForEach([5, 10, 15, 20, 30], id: \.self) { amount in
                            Button("\(amount) g") {
                                draft.amount = String(amount)
                                selectionFeedback += 1
                            }
                            .font(.subheadline)
                            .frame(maxWidth: .infinity).padding(.vertical, 12)
                            .background(.white.opacity(0.06), in: Capsule())
                            .foregroundStyle(.white)
                        }
                    }
                }
            }
        }
    }

    private var stoolFields: some View {
        DiaryCard {
            VStack(alignment: .leading, spacing: 20) {
                Text("排便次数").font(.headline)
                Stepper("\(draft.count) 次", value: $draft.count, in: 1...999)
                    .font(.title2.bold())
                Text("状态（可选）").font(.headline)
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 85))], spacing: 10) {
                    ForEach(StoolCondition.allCases) { condition in
                        Button {
                            draft.condition = draft.condition == condition ? nil : condition
                            selectionFeedback += 1
                        } label: {
                            Text(condition.title).frame(maxWidth: .infinity).padding(.vertical, 12)
                                .foregroundStyle(draft.condition == condition ? DiaryStyle.background : .white)
                                .background(draft.condition == condition ? DiaryStyle.amber : Color.white.opacity(0.06), in: Capsule())
                        }.buttonStyle(.plain)
                    }
                }
                Text("大小 / 描述（可选）").font(.headline)
                TextField("例如：2 条、约 2.5 cm", text: $draft.descriptionText, axis: .vertical)
                    .focused($inputFocused)
            }
        }
    }

    private var weightFields: some View {
        DiaryCard {
            VStack(alignment: .leading, spacing: 16) {
                Text("体重").font(.headline)
                numberField("例如 6.80", text: $draft.weight, unit: "kg")
                Text("支持两位小数，保存实际测量值。")
                    .font(.footnote).foregroundStyle(.secondary)
            }
        }
    }

    private func numberField(_ placeholder: String, text: Binding<String>, unit: String) -> some View {
        HStack {
            TextField(placeholder, text: text)
                .keyboardType(.decimalPad).focused($inputFocused)
                .font(.system(size: 36, weight: .semibold, design: .rounded))
            Text(unit).font(.title2).foregroundStyle(.secondary)
        }
        .padding(16)
        .background(.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 16))
    }

    private var timeFields: some View {
        Group {
            DiaryCard {
                VStack(alignment: .leading, spacing: 14) {
                    Text("实际时间").font(.headline)
                    Button {
                        inputFocused = false
                        withAnimation(.easeInOut(duration: 0.25)) { showsTime.toggle() }
                    } label: {
                        HStack {
                            Image(systemName: "clock.fill").foregroundStyle(DiaryStyle.pink)
                            Text(draft.eventAt.formatted(date: .abbreviated, time: .shortened))
                            Spacer()
                            Text("修改时间").font(.caption)
                            Image(systemName: "chevron.down").font(.caption)
                        }
                    }.buttonStyle(.plain)
                    if showsTime {
                        DatePicker("实际发生时间", selection: $draft.eventAt, in: ...Date.now,
                                   displayedComponents: [.date, .hourAndMinute])
                            .datePickerStyle(.compact)
                    }
                    Text("默认当前时间，可补录历史记录。")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }
            DiaryCard {
                VStack(alignment: .leading, spacing: 10) {
                    Text("录入时间").font(.headline)
                    Label(editing.map { $0.createdAt.formatted(date: .abbreviated, time: .shortened) } ?? "保存时自动记录", systemImage: "doc.text")
                        .foregroundStyle(.secondary)
                    Text("与实际发生时间独立保存，不可修改。")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }
        }
    }

    private func save() {
        guard !saving else { return }
        inputFocused = false
        saving = true
        do {
            try RecordService.save(draft, petID: petID, editing: editing, in: modelContext)
            UINotificationFeedbackGenerator().notificationOccurred(.success)
            dismiss()
        } catch {
            saving = false
            errorMessage = error.localizedDescription
        }
    }
}


