import Foundation
import SwiftData

@main
struct DailyNotesCheck {
    enum Failure: Error { case failed(String) }
    @MainActor static func main() throws {
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent("MiaoJiNoteCheck-" + UUID().uuidString)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: folder) }
        let store = folder.appendingPathComponent("diary.store")
        let petID = UUID(), otherID = UUID()
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone(identifier: "Asia/Shanghai") ?? .current
        guard let day = calendar.date(from: DateComponents(year: 2020, month: 12, day: 31, hour: 23, minute: 50)),
              let next = calendar.date(byAdding: .minute, value: 20, to: day) else { throw Failure.failed("test date") }
        func check(_ valid: Bool, _ message: String) throws { if !valid { throw Failure.failed(message) } }

        // Create a real on-disk store using the six-model schema shipped before daily notes.
        try autoreleasepool {
            let schema = Schema([FeedingRecord.self, StoolRecord.self, WeightRecord.self, CatProfile.self, DryFoodInventory.self, InventoryAdjustment.self])
            let container = try ModelContainer(for: schema, configurations: [ModelConfiguration(schema: schema, url: store)])
            let pet = CatProfile(); pet.id = petID
            let other = CatProfile(name: "另一只宠物"); other.id = otherID
            container.mainContext.insert(pet); container.mainContext.insert(other)
            let meal = FeedingRecord(foodType: .wet, amountGram: 13, eventAt: day); meal.petID = petID
            container.mainContext.insert(meal)
            try container.mainContext.save()
        }
        let schema = Schema([FeedingRecord.self, StoolRecord.self, WeightRecord.self, CatProfile.self, DryFoodInventory.self, InventoryAdjustment.self, DailyNoteRecord.self])
        try autoreleasepool {
            let container = try ModelContainer(for: schema, configurations: [ModelConfiguration(schema: schema, url: store)])
            let context = container.mainContext
            try check(try context.fetch(FetchDescriptor<FeedingRecord>()).count == 1, "upgrade lost feeding")
            try DailyNoteService.save("换粮", on: day, petID: petID, in: context, calendar: calendar)
            let created = try context.fetch(FetchDescriptor<DailyNoteRecord>()).first?.createdAt
            try DailyNoteService.save("换粮，精神正常 <&>", on: day, petID: petID, in: context, calendar: calendar)
            let edited = try context.fetch(FetchDescriptor<DailyNoteRecord>())
            try check(edited.count == 1 && edited.first?.createdAt == created, "edit duplicated note or changed creation time")
            try DailyNoteService.save("次日备注", on: next, petID: petID, in: context, calendar: calendar)
            try DailyNoteService.save("另一只宠物", on: day, petID: otherID, in: context, calendar: calendar)
        }
        // Reopen the store to verify persistence, local-day/year boundaries and pet isolation.
        try autoreleasepool {
            let container = try ModelContainer(for: schema, configurations: [ModelConfiguration(schema: schema, url: store)])
            let context = container.mainContext
            let notes = try context.fetch(FetchDescriptor<DailyNoteRecord>())
            try check(notes.count == 3, "notes lost after reopen")
            try check(DailyNoteService.note(on: day, petID: petID, records: notes, calendar: calendar)?.text == "换粮，精神正常 <&>", "pet or day mismatch")
            try check(DailyNoteService.note(on: next, petID: petID, records: notes, calendar: calendar)?.text == "次日备注", "cross-year day mismatch")
            let exportNotes = notes.filter { $0.petID == petID && calendar.isDate($0.eventAt, inSameDayAs: next) }
            let sheets = ExcelExportService.sheets(feedings: [], stools: [], weights: [], dailyNotes: exportNotes)
            try check(sheets.count == 4 && sheets[0].rows.count == 2, "note-only day missing in export")
            try check(sheets[0].rows[1].count == 9, "daily note column missing")
            if case .text("次日备注") = sheets[0].rows[1][8] {} else { throw Failure.failed("wrong exported note") }
            for cell in sheets[0].rows[1][1...7] {
                if case .empty = cell {} else { throw Failure.failed("note-only day fabricated health data") }
            }
            try DailyNoteService.save("  \n", on: day, petID: petID, in: context, calendar: calendar)
            let remaining = try context.fetch(FetchDescriptor<DailyNoteRecord>())
            try check(remaining.count == 2 && DailyNoteService.note(on: day, petID: otherID, records: remaining, calendar: calendar) != nil, "clear affected another pet")
            try check(try context.fetch(FetchDescriptor<FeedingRecord>()).count == 1, "note operation changed feeding")
        }
        print("Daily notes: legacy-store upgrade, disk persistence, edit, clear, pet isolation, local-day/year boundary and note-only export checks passed.")
    }
}
