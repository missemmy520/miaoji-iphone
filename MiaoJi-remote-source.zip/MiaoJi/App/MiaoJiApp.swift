import SwiftUI
import SwiftData

@main
struct MiaoJiApp: App {
    private let container: ModelContainer?
    private let startupError: String?

    init() {
        do {
            let schema = Schema([
                FeedingRecord.self, StoolRecord.self, WeightRecord.self,
                CatProfile.self, DryFoodInventory.self, InventoryAdjustment.self, DailyNoteRecord.self, UrineRecord.self
            ])
            let configuration = ModelConfiguration(schema: schema, isStoredInMemoryOnly: false)
            container = try ModelContainer(for: schema, configurations: [configuration])
            startupError = nil
        } catch {
            container = nil
            startupError = error.localizedDescription
        }
    }

    var body: some Scene {
        WindowGroup {
            Group {
                if let container {
                    FoundationView().modelContainer(container)
                } else {
                    ContentUnavailableView {
                        Label("无法打开本地记录", systemImage: "externaldrive.badge.exclamationmark")
                    } description: {
                        Text("请重新启动 App。原有数据不会被自动删除。\n\(startupError ?? "未知错误")")
                    }
                }
            }
            .preferredColorScheme(.dark)
            .tint(Color(red: 0.96, green: 0.59, blue: 0.64))
        }
    }
}
