import Foundation
import SwiftData

@Model
final class InventoryAdjustment {
    @Attribute(.unique) var id: UUID
    var inventoryID: UUID
    var beforeGram: Double
    var afterGram: Double
    var eventAt: Date
    private(set) var createdAt: Date
    var note: String?

    init(inventoryID: UUID, beforeGram: Double, afterGram: Double, eventAt: Date = .now, note: String? = nil) {
        self.id = UUID()
        self.inventoryID = inventoryID
        self.beforeGram = beforeGram
        self.afterGram = afterGram
        self.eventAt = eventAt
        self.createdAt = .now
        self.note = note
    }
    // Restore original metadata only during a user-confirmed data import.
    func restoreImportCreatedAt(_ date: Date) { createdAt = date }
}
