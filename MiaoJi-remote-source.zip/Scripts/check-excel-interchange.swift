import Foundation
import SwiftData

@main struct ExcelInterchangeCheck {
    enum Failure: Error { case failed(String) }
    @MainActor static func main() throws {
        func check(_ value: Bool, _ name: String) throws { if !value { throw Failure.failed(name) } }
        let schema = Schema([FeedingRecord.self, StoolRecord.self, WeightRecord.self, CatProfile.self, DryFoodInventory.self, InventoryAdjustment.self, DailyNoteRecord.self, UrineRecord.self])
        let config = ModelConfiguration(schema: schema, isStoredInMemoryOnly: true)
        let source = try ModelContainer(for: schema, configurations: [config])
        let p = CatProfile(name: "同名猫"), q = CatProfile(name: "同名猫")
        source.mainContext.insert(p); source.mainContext.insert(q)
        let event = Date(timeIntervalSince1970: 1_700_000_000.123)
        p.birthday = event.addingTimeInterval(-86400)
        let f = FeedingRecord(foodType: .wet, amountGram: 13.5, eventAt: event); f.petID = p.id; f.restoreImportCreatedAt(event); source.mainContext.insert(f)
        let u = UrineRecord(clumpCount: 0, size: .small, shape: .flat, eventAt: event); u.petID = q.id; source.mainContext.insert(u)
        let b = DryFoodInventory(foodName: "湿粮", bagTotalGram: 800, openedAt: event.addingTimeInterval(-3600), foodKind: .wet); b.petID = p.id; source.mainContext.insert(b)
        source.mainContext.insert(InventoryAdjustment(inventoryID: b.id, beforeGram: 786.5, afterGram: 750, eventAt: event.addingTimeInterval(1)))
        try source.mainContext.save()
        let file = try ExcelInterchangeService.export(in: source.mainContext); defer { ExcelExportService.cleanup(file) }
        let rows = try DataInterchangeService.parse(ExcelInterchangeService.parse(Data(contentsOf: file)))
        let destination = try ModelContainer(for: schema, configurations: [ModelConfiguration(schema: schema, isStoredInMemoryOnly: true)])
        _ = try DataInterchangeService.apply(rows, overwrite: false, preservePetIDs: true, in: destination.mainContext)
        try check(try destination.mainContext.fetch(FetchDescriptor<CatProfile>()).count == 2, "same-name pets remain distinct")
        let result = try destination.mainContext.fetch(FetchDescriptor<FeedingRecord>()).first
        try check(result?.petID == p.id && result?.amountGram == 13.5, "feeding pet and decimal")
        try check(abs((result?.eventAt.timeIntervalSince1970 ?? 0) - event.timeIntervalSince1970) < 0.001, "milliseconds")
        try check(try destination.mainContext.fetch(FetchDescriptor<UrineRecord>()).first?.clumpCount == 0, "explicit urine zero")
        try check(try destination.mainContext.fetch(FetchDescriptor<InventoryAdjustment>()).first?.afterGram == 750, "inventory calibration")
        _ = try DataInterchangeService.apply(rows, overwrite: false, preservePetIDs: true, in: destination.mainContext)
        try check(try destination.mainContext.fetch(FetchDescriptor<FeedingRecord>()).count == 1, "repeated import")
        let damaged = Data("not an xlsx".utf8)
        do { _ = try ExcelInterchangeService.parse(damaged); throw Failure.failed("invalid archive accepted") } catch is ExcelWorkbookReader.ReadError { }
        print("PASS: genuine XLSX roundtrip; same-name pets isolated; precise dates; wet inventory/calibration; explicit urine zero; repeated import; invalid ZIP rejected")
    }
}
