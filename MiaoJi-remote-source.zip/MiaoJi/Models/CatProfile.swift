import Foundation
import SwiftData

@Model
final class CatProfile {
    @Attribute(.unique) var id: UUID
    var species: String = "猫"
    var name: String
    @Attribute(.externalStorage) var avatarData: Data?
    var birthday: Date?
    var note: String?

    init(name: String = "花卷", avatarData: Data? = nil, birthday: Date? = nil, note: String? = nil) {
        self.id = UUID()
        self.name = name
        self.avatarData = avatarData
        self.birthday = birthday
        self.note = note
    }
}

