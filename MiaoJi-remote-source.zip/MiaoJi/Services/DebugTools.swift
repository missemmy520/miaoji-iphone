#if DEBUG
import Foundation
import SwiftData

enum DebugTools {
    enum CheckFailure: LocalizedError {
        case failed(String)
        var errorDescription: String? { switch self { case .failed(let text): return text } }
    }
    @MainActor static func runChecks() throws -> String {
        let schema = Schema([FeedingRecord.self, StoolRecord.self, WeightRecord.self, CatProfile.self, DryFoodInventory.self, InventoryAdjustment.self, DailyNoteRecord.self, UrineRecord.self])
        let container = try ModelContainer(for: schema, configurations: [ModelConfiguration(schema: schema, isStoredInMemoryOnly: true)])
        let context = container.mainContext
        func check(_ condition: Bool, _ message: String) throws { if !condition { throw CheckFailure.failed(message) } }
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone(identifier: "Asia/Shanghai") ?? .current
        func date(_ year: Int, _ month: Int, _ day: Int, _ hour: Int = 12) throws -> Date {
            guard let result = calendar.date(from: DateComponents(year: year, month: month, day: day, hour: hour)) else { throw CheckFailure.failed("测试日期错误") }
            return result
        }
        let pet = CatProfile(), other = CatProfile(name: "测试宠物")
        context.insert(pet); context.insert(other)
        let bag = DryFoodInventory(foodName: "测试粮", bagTotalGram: 2000, openedAt: try date(2020, 1, 1, 0)); bag.petID = pet.id; context.insert(bag)
        var draft = RecordDraft(); draft.foodType = .dry; draft.amount = "10"; draft.eventAt = try date(2020, 1, 2)
        try RecordService.save(draft, petID: pet.id, in: context)
        var records = try context.fetch(FetchDescriptor<FeedingRecord>())
        guard let first = records.first else { throw CheckFailure.failed("新增失败") }
        let created = first.createdAt
        try check(InventoryService.snapshot(bag: bag, feedings: records, adjustments: []).remaining == 1990, "新增后扣减错误")
        draft.amount = "15"; try RecordService.save(draft, petID: pet.id, editing: .feeding(first), in: context)
        try check(first.createdAt == created, "编辑改变了 createdAt")
        try check(InventoryService.snapshot(bag: bag, feedings: records, adjustments: []).remaining == 1985, "编辑后重复扣减")
        try RecordTarget.feeding(first).delete(in: context)
        records = try context.fetch(FetchDescriptor<FeedingRecord>())
        try check(InventoryService.snapshot(bag: bag, feedings: records, adjustments: []).remaining == 2000, "删除后未恢复库存")
        let old = FeedingRecord(foodType: .dry, amountGram: 30, eventAt: try date(2020, 1, 2)); old.petID = pet.id
        let recent = FeedingRecord(foodType: .dry, amountGram: 20, eventAt: try date(2020, 1, 4)); recent.petID = pet.id
        let foreign = FeedingRecord(foodType: .dry, amountGram: 100, eventAt: try date(2020, 1, 4)); foreign.petID = other.id
        let correction = InventoryAdjustment(inventoryID: bag.id, beforeGram: 1970, afterGram: 620, eventAt: try date(2020, 1, 3))
        let corrected = InventoryService.snapshot(bag: bag, feedings: [old, recent, foreign], adjustments: [correction])
        try check(corrected.remaining == 600, "校准基准或宠物隔离错误")
        old.amountGram = 50
        try check(InventoryService.snapshot(bag: bag, feedings: [old, recent], adjustments: [correction]).remaining == 600, "校准前补录影响了已称重基准")
        bag.closedAt = try date(2020, 1, 4)
        try check(InventoryService.snapshot(bag: bag, feedings: [old, recent], adjustments: [correction]).remaining == 620, "换袋边界记录被重复扣减")
        let nextBag = DryFoodInventory(foodName: "新袋", bagTotalGram: 1000, openedAt: try date(2020, 1, 4)); nextBag.petID = pet.id
        try check(InventoryService.snapshot(bag: nextBag, feedings: [old, recent], adjustments: [correction]).remaining == 980, "换袋边界未归属新袋")
        let december = try date(2023, 12, 31), january = try date(2024, 1, 1)
        try check(StatisticsService.week(containing: january, calendar: calendar).count == 7, "跨年周日期错误")
        let february = try date(2024, 2, 10)
        try check(DiaryDates.monthDays(february, calendar: calendar).contains(where: { calendar.component(.month, from: $0) == 2 && calendar.component(.day, from: $0) == 29 }), "闰年日历缺失 29 日")
        let late = FeedingRecord(foodType: .wet, amountGram: 13, eventAt: try date(2023, 12, 31, 23))
        let summary = StatisticsService.summary(on: december, feedings: [late], stools: [], weights: [], calendar: calendar)
        try check(summary.totalGram == 13 && summary.stoolCount == nil && summary.weight == nil, "自然日汇总或缺失数据错误")
        let blank = StatisticsService.summary(on: january, feedings: [late], stools: [], weights: [], calendar: calendar)
        try check(blank.totalGram == nil, "跨年记录归属错误")
        var sheets = ExcelExportService.sheets(feedings: [late], stools: [], weights: [])
        try check(sheets.count == 5 && sheets[0].rows.count == 2, "Excel 工作表或汇总行数错误")
        sheets.append(ExcelSheet(name: "转义检查", rows: [[.text("<&\"🐾\n=1+1"), .number(6.8)]]))
        var vectorZIP = WorkbookZIP()
        try vectorZIP.add("hello.txt", content: "hello")
        let vector = try vectorZIP.finish()
        try check(Array(vector[14..<18]) == [0x86, 0xa6, 0x10, 0x36], "ZIP CRC-32 标准向量错误")
        let url = try ExcelExportService.write(sheets, petName: "测试")
        defer { ExcelExportService.cleanup(url) }
        let bytes = try Data(contentsOf: url)
        try check(Array(bytes.prefix(4)) == [0x50, 0x4b, 0x03, 0x04], "XLSX 不是 ZIP 容器")
        let text = String(decoding: bytes, as: UTF8.self)
        try check(text.contains("xl/workbook.xml") && text.contains("&lt;&amp;&quot;") && text.contains("inlineStr"), "OOXML 目录或文本转义错误")
        return "逻辑自检通过：\n新增、编辑、删除库存重算\ncreatedAt 保留\n校准基准\n多宠物库存隔离\n跨年与闰年日历\n自然日和缺失数据\nXLSX ZIP 容器与文本转义\n\n这些检查不替代 Excel/Numbers 打开验证、磁盘持久化和页面操作测试。"
    }
    @MainActor static func seed(petID: UUID, in context: ModelContext) throws {
        let existing = try context.fetch(FetchDescriptor<FeedingRecord>()).contains { $0.petID == petID && $0.note == "喵记示例数据" }
        guard !existing else { throw CheckFailure.failed("此宠物已载入示例数据，不重复添加。") }
        let calendar = Calendar.current
        func date(_ day: Int, _ hour: Int, _ minute: Int = 0) throws -> Date {
            guard let result = calendar.date(from: DateComponents(year: 2026, month: 10, day: day, hour: hour, minute: minute)) else { throw CheckFailure.failed("示例日期错误") }
            return result
        }
        let mealSpecs: [(Int, FoodType, Double, Int, Int)] = [(13,.wet,45,8,0),(13,.dry,13,15,0),(14,.wet,60,8,0),(14,.dry,16,15,0),(15,.wet,70,8,0),(15,.dry,26,15,0),(16,.wet,13,8,13),(16,.dry,6,15,42)]
        for (day,type,grams,hour,minute) in mealSpecs {
            let meal = FeedingRecord(foodType: type, amountGram: grams, eventAt: try date(day,hour,minute), note: "喵记示例数据"); meal.petID = petID; context.insert(meal)
        }
        let stool = StoolRecord(condition: .normal, eventAt: try date(16,11,25), note: "喵记示例数据"); stool.petID = petID; context.insert(stool)
        for (day,kg) in [(13,6.90),(14,6.85),(16,6.80)] {
            let weight = WeightRecord(weightKg: kg, eventAt: try date(day,21,10), note: "喵记示例数据"); weight.petID = petID; context.insert(weight)
        }
        let allBags = try context.fetch(FetchDescriptor<DryFoodInventory>())
        if !allBags.contains(where: { $0.petID == petID && $0.isCurrent }) {
            let bag = DryFoodInventory(foodName: "示例干粮", bagTotalGram: 2000, openedAt: try date(10,9,12)); bag.petID = petID; context.insert(bag)
        }
        do { try context.save() } catch { context.rollback(); throw error }
    }
}
#endif


