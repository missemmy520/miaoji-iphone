import Foundation
import SwiftData

@Model
final class StoolRecord {
    @Attribute(.unique) var id: UUID
    var petID: UUID? = nil
    var count: Int
    var condition: StoolCondition?
    var descriptionText: String?
    var eventAt: Date
    private(set) var createdAt: Date
    var note: String?

    init(count: Int = 1, condition: StoolCondition? = nil, descriptionText: String? = nil, eventAt: Date = .now, note: String? = nil) {
        self.id = UUID()
        self.count = count
        self.condition = condition
        self.descriptionText = descriptionText
        self.eventAt = eventAt
        self.createdAt = .now
        self.note = note
    }
}

