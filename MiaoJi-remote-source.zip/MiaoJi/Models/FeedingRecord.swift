import Foundation
import SwiftData

@Model
final class FeedingRecord {
    @Attribute(.unique) var id: UUID
    var petID: UUID? = nil
    var foodType: FoodType
    var amountGram: Double
    var eventAt: Date
    private(set) var createdAt: Date
    var note: String?

    init(foodType: FoodType, amountGram: Double, eventAt: Date = .now, note: String? = nil) {
        self.id = UUID()
        self.foodType = foodType
        self.amountGram = amountGram
        self.eventAt = eventAt
        self.createdAt = .now
        self.note = note
    }
}

