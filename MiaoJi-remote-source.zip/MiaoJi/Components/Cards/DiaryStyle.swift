import SwiftUI

enum DiaryStyle {
    static let background = Color(red: 0.051, green: 0.059, blue: 0.071)
    static let card = Color(red: 0.09, green: 0.098, blue: 0.114)
    static let pink = Color(red: 0.96, green: 0.59, blue: 0.64)
    static let green = Color(red: 0.65, green: 0.75, blue: 0.46)
    static let amber = Color(red: 0.91, green: 0.72, blue: 0.40)
    static let blue = Color(red: 0.53, green: 0.68, blue: 0.86)
}

struct DiaryCard<Content: View>: View {
    private let content: Content
    init(@ViewBuilder content: () -> Content) { self.content = content() }
    var body: some View {
        content
            .padding(18)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(LinearGradient(colors: [DiaryStyle.card, Color(red: 0.075, green: 0.082, blue: 0.098)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 24))
            .overlay(RoundedRectangle(cornerRadius: 24).stroke(.white.opacity(0.06)))
    }
}

struct PinkButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.headline)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 18)
            .foregroundStyle(DiaryStyle.background)
            .background(DiaryStyle.pink.gradient, in: Capsule())
            .opacity(configuration.isPressed ? 0.75 : 1)
    }
}

extension FoodType {
    var color: Color {
        switch self {
        case .dry: return DiaryStyle.green
        case .wet: return DiaryStyle.pink
        case .treat: return DiaryStyle.amber
        case .other: return .gray
        }
    }
    var symbol: String {
        switch self {
        case .dry, .wet: return "takeoutbag.and.cup.and.straw.fill"
        case .treat: return "carrot.fill"
        case .other: return "ellipsis"
        }
    }
}
