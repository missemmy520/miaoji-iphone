import Foundation

enum RecordInput {
    /// Decimal is parsed using the device separator, without accepting grouping or exponents.
    static func positiveNumber(_ input: String, fractionDigits: Int, locale: Locale = .current) -> Double? {
        let separator = locale.decimalSeparator ?? "."
        let normalized = input.trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: separator, with: ".")
        let parts = normalized.split(separator: ".", omittingEmptySubsequences: false)
        guard parts.count <= 2, let first = parts.first, !first.isEmpty,
              first.allSatisfy({ $0.isASCII && $0.isNumber }),
              parts.count == 1 || (parts[1].count <= fractionDigits && parts[1].allSatisfy({ $0.isASCII && $0.isNumber })),
              let value = Double(normalized), value.isFinite, value > 0 else { return nil }
        return value
    }

    static func note(_ text: String) -> String? {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        return trimmed.isEmpty ? nil : trimmed
    }
}
