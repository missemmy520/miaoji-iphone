import SwiftUI

struct HealthAdvisorView: View {
    let profile: CatProfile
    let feedings: [FeedingRecord]
    let stools: [StoolRecord]
    let weights: [WeightRecord]
    let urines: [UrineRecord]
    @Environment(\.dismiss) private var dismiss
    @State private var question = ""
    @State private var submitted = ""
    @State private var terms = ""
    @State private var papers: [LiteraturePaper] = []
    @State private var searching = false
    @State private var searchedAt: Date?
    @State private var searchedTerms = ""
    @State private var error: String?
    @State private var requestTask: Task<Void, Never>?
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    Text("陪你多了解一点小日常").font(.title2.bold())
                    Text("本地记录分析与精选资料问答；不提供诊断、用药剂量或健康评分。联网检索为可选项。").font(.caption).foregroundStyle(.secondary)
                    if profile.species == "猫" {
                        ForEach(HealthAnalysisService.observations(petID: profile.id, feedings: feedings, weights: weights, stools: stools, urines: urines)) { item in
                            DiaryCard {
                                VStack(alignment: .leading, spacing: 10) {
                                    Text(item.title).font(.headline)
                                    Text(item.text).font(.subheadline)
                                    sourceLinks(item.sourceIDs)
                                }
                            }
                        }
                        questionCard
                        if !submitted.isEmpty { responseCard; onlineCard }
                        DisclosureGroup("本地资料库 · \(HealthKnowledge.sources.count) 个核验来源") {
                            VStack(alignment: .leading, spacing: 16) {
                                ForEach(HealthKnowledge.sources) { source in
                                    VStack(alignment: .leading, spacing: 6) {
                                        sourceLink(source)
                                        Text(source.organization + " · " + source.year)
                                        Text("依据章节：" + source.section)
                                        Text(source.scope)
                                        Text("最后核验：" + source.checkedAt)
                                    }.font(.caption)
                                }
                            }.padding(.top, 10)
                        }.padding(18).background(DiaryStyle.card, in: RoundedRectangle(cornerRadius: 20))
                    } else {
                        ContentUnavailableView("当前资料库适用于猫", systemImage: "pawprint", description: Text("其他宠物可以继续记录日常；猫科资料不用于判断其他物种的健康。"))
                    }
                }.padding(16)
            }.background(DiaryStyle.background).navigationTitle("健康小顾问")
                .toolbar { Button("完成") { dismiss() } }
        }.onDisappear { requestTask?.cancel() }
    }
    private var questionCard: some View {
        DiaryCard {
            VStack(alignment: .leading, spacing: 12) {
                Text("说说你观察到的情况").font(.headline)
                TextField("可补充精神、呕吐、饮水、环境、病史及持续时间…", text: $question, axis: .vertical).lineLimit(3...8)
                    .onChange(of: question) { _, value in if value.count > 2000 { question = String(value.prefix(2000)) } }
                Button("查看资料回答", action: submit).buttonStyle(PinkButtonStyle()).disabled(question.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                ForEach(HealthKnowledge.topics) { topic in Button(topic.title) { question = topic.title; submit() }.font(.subheadline) }
            }
        }
    }
    private var responseCard: some View {
        let reply = HealthAnalysisService.reply(to: submitted, species: profile.species)
        return DiaryCard {
            VStack(alignment: .leading, spacing: 14) {
                Text("你的描述").font(.caption).foregroundStyle(.secondary)
                Text(submitted).textSelection(.enabled)
                Text(reply.text).font(.subheadline).foregroundStyle(DiaryStyle.pink)
                ForEach(reply.topics) { topic in
                    VStack(alignment: .leading, spacing: 8) {
                        Text(topic.title).font(.headline)
                        Text(topic.answer).font(.subheadline).textSelection(.enabled)
                        sourceLinks(topic.sourceIDs)
                    }
                }
            }
        }
    }
    private var onlineCard: some View {
        DiaryCard {
            VStack(alignment: .leading, spacing: 12) {
                Text("需要更多来源？").font(.headline)
                Text("通过 Europe PMC 联网查找已发表文献。仅发送下方关键词，不上传档案、日记或完整咨询。未匹配的咨询不会自动填入。结果未经逐篇临床审核，不代表适用于当前猫咪。").font(.caption).foregroundStyle(.secondary)
                TextField("独立检索关键词（建议英文）", text: $terms, axis: .vertical).lineLimit(2...4).autocorrectionDisabled()
                Button(searching ? "正在查询…" : "联网查询来源", action: search).buttonStyle(PinkButtonStyle()).disabled(searching || terms.isEmpty)
                if let error { Text(error).font(.caption).foregroundStyle(DiaryStyle.pink) }
                if let searchedAt {
                    Text("查询：" + searchedTerms + "\n时间：" + searchedAt.formatted(date: .abbreviated, time: .shortened)).font(.caption).foregroundStyle(.secondary)
                    Text(papers.isEmpty ? "这次没有找到匹配文献，不据此生成回答。可修改关键词，或咨询兽医。" : "找到以下相关文献，供进一步阅读；不据摘要推断病因。英文节选保持原文，避免误译。").font(.subheadline)
                }
                ForEach(papers) { paper in
                    VStack(alignment: .leading, spacing: 8) {
                        if let url = paper.url { Link(paper.title, destination: url).font(.headline) }
                        else { Text(paper.title).font(.headline) }
                        Text((paper.pubYear ?? "年份未提供") + " · " + (paper.authorString ?? "作者未提供")).font(.caption).foregroundStyle(.secondary)
                        if let doi = paper.doi { Text("DOI: " + doi).font(.caption).textSelection(.enabled) }
                        Text(paper.abstractPreview).font(.caption).textSelection(.enabled)
                        Divider()
                    }
                }
            }
        }
    }
    private func submit() {
        requestTask?.cancel(); searching = false
        submitted = question.trimmingCharacters(in: .whitespacesAndNewlines)
        terms = LiteratureSearchService.suggestedTerms(for: submitted)
        papers = []; searchedAt = nil; error = nil
    }
    private func search() {
        let query = terms
        searching = true; error = nil; papers = []; searchedAt = nil
        requestTask = Task { @MainActor in
            defer { if !Task.isCancelled { searching = false } }
            do {
                let results = try await LiteratureSearchService.search(query)
                guard !Task.isCancelled else { return }
                papers = results; searchedTerms = query; searchedAt = .now
            } catch {
                guard !Task.isCancelled else { return }
                self.error = "查询未完成：" + error.localizedDescription + " 不会生成没有来源的回答。"
            }
        }
    }
    private func sourceLinks(_ ids: [String]) -> some View {
        ForEach(HealthKnowledge.sources(for: ids)) { source in sourceLink(source).font(.caption) }
    }
    @ViewBuilder private func sourceLink(_ source: HealthSource) -> some View {
        if let url = URL(string: source.url) { Link("来源：" + source.title, destination: url) }
    }
}
