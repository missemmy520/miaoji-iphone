import SwiftUI
import SwiftData
import PhotosUI
import UIKit

struct CatProfileView: View {
    var petID: UUID? = nil
    var isNew = false
    var didSave: ((UUID) -> Void)? = nil
    @State private var species = "猫"
    private var existingProfile: CatProfile? { isNew ? nil : profiles.first { $0.id == petID } }
    @Environment(\.modelContext) private var modelContext
    @Environment(\.dismiss) private var dismiss
    @Query private var profiles: [CatProfile]
    @State private var name = "花卷"
    @State private var hasBirthday = false
    @State private var birthday = Date.now
    @State private var note = ""
    @State private var avatarData: Data?
    @State private var selectedPhoto: PhotosPickerItem?
    @State private var loadingPhoto = false
    @State private var errorMessage: String?
    @State private var loaded = false
    @State private var saving = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    DiaryCard {
                        VStack(alignment: .leading, spacing: 18) {
                            PhotosPicker(selection: $selectedPhoto, matching: .images) {
                                HStack(spacing: 16) {
                                    avatar
                                    Text(loadingPhoto ? "正在读取头像…" : "选择猫咪头像")
                                }
                            }.disabled(loadingPhoto || saving)
                            if avatarData != nil { Button("移除头像", role: .destructive) { avatarData = nil } }
                            TextField("宠物种类，例如猫、狗", text: $species)
                            Text("名字").font(.headline)
                            TextField("花卷", text: $name)
                            Toggle("填写生日", isOn: $hasBirthday)
                            if hasBirthday {
                                DatePicker("生日", selection: $birthday, in: ...Date.now, displayedComponents: .date)
                            }
                            Text("未填写生日时不显示年龄。")
                                .font(.caption).foregroundStyle(.secondary)
                        }
                    }
                    DiaryCard {
                        VStack(alignment: .leading, spacing: 12) {
                            Text("备注（可选）").font(.headline)
                            TextField("记录宠物的小习惯…", text: $note, axis: .vertical).lineLimit(3...6)
                        }
                    }
                }.padding(16)
            }
            .background(DiaryStyle.background)
            .navigationTitle(isNew ? "新增宠物" : "宠物资料").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarLeading) { Button("取消") { dismiss() } } }
            .safeAreaInset(edge: .bottom) {
                Button("保存资料", action: save).buttonStyle(PinkButtonStyle())
                    .disabled(loadingPhoto || saving).padding(16).background(DiaryStyle.background)
            }
            .task {
                guard !loaded else { return }
                loaded = true
                if isNew { name = "" }
                if let profile = existingProfile {
                    name = profile.name
                    species = profile.species
                    avatarData = profile.avatarData
                    hasBirthday = profile.birthday != nil
                    birthday = profile.birthday ?? .now
                    note = profile.note ?? ""
                }
            }
            .task(id: selectedPhoto) { await loadPhoto() }
            .alert("无法保存或读取资料", isPresented: Binding(get: { errorMessage != nil }, set: { if !$0 { errorMessage = nil } })) {
                Button("好", role: .cancel) { errorMessage = nil }
            } message: { Text(errorMessage ?? "请重试") }
        }
    }

    @ViewBuilder private var avatar: some View {
        if let data = avatarData, let image = UIImage(data: data) {
            Image(uiImage: image).resizable().scaledToFill().frame(width: 72, height: 72).clipShape(Circle())
        } else {
            Image(systemName: "cat.fill").font(.largeTitle).foregroundStyle(DiaryStyle.pink)
                .frame(width: 72, height: 72).background(DiaryStyle.pink.opacity(0.12), in: Circle())
        }
    }

    @MainActor private func loadPhoto() async {
        guard let selectedPhoto else { return }
        loadingPhoto = true
        defer { loadingPhoto = false }
        do {
            guard let data = try await selectedPhoto.loadTransferable(type: Data.self),
                  let image = UIImage(data: data) else { throw ProfileError.unreadableImage }
            try Task.checkCancellation()
            let scale = min(1, 512 / max(image.size.width, image.size.height))
            let size = CGSize(width: max(1, image.size.width * scale), height: max(1, image.size.height * scale))
            let format = UIGraphicsImageRendererFormat()
            format.scale = 1
            let resized = UIGraphicsImageRenderer(size: size, format: format).image { _ in
                image.draw(in: CGRect(origin: .zero, size: size))
            }
            guard let jpeg = resized.jpegData(compressionQuality: 0.85) else { throw ProfileError.unreadableImage }
            avatarData = jpeg
        } catch is CancellationError { return }
        catch { errorMessage = error.localizedDescription }
    }

    private func save() {
        guard !saving else { return }
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { errorMessage = "请填写宠物名字。"; return }
        saving = true
        let profile: CatProfile
        if let existing = existingProfile { profile = existing }
        else { profile = CatProfile(); modelContext.insert(profile) }
        profile.species = species.trimmingCharacters(in: .whitespacesAndNewlines)
        profile.name = trimmed
        profile.avatarData = avatarData
        profile.birthday = hasBirthday ? birthday : nil
        profile.note = RecordInput.note(note)
        do {
            try modelContext.save()
            UINotificationFeedbackGenerator().notificationOccurred(.success)
            didSave?(profile.id)
            dismiss()
        } catch { modelContext.rollback(); saving = false; errorMessage = error.localizedDescription }
    }
}

private enum ProfileError: LocalizedError {
    case unreadableImage
    var errorDescription: String? { "无法读取这张图片，请选择其他照片。" }
}



