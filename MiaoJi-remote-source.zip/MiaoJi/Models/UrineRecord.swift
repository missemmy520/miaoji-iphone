import Foundation
import SwiftData

enum UrineClumpSize: String, Codable, CaseIterable, Identifiable {
    case usual, large, small, other
    var id: String { rawValue }
    var title: String {
        switch self {
        case .usual: return "常规（约鸡蛋大小）"
        case .large: return "偏大"
        case .small: return "偏小"
        case .other: return "其他"
        }
    }
}

enum UrineClumpShape: String, Codable, CaseIterable, Identifiable {
    case rounded, flat, other
    var id: String { rawValue }
    var title: String {
        switch self {
        case .rounded: return "团状"
        case .flat: return "扁平"
        case .other: return "其他"
        }
    }
}

@Model
final class UrineRecord {
    @Attribute(.unique) var id: UUID
    var petID: UUID? = nil
    var clumpCount: Int
    var size: UrineClumpSize?
    var shape: UrineClumpShape?
    var eventAt: Date
    private(set) var createdAt: Date
    var note: String?

    init(clumpCount: Int = 1, size: UrineClumpSize? = nil, shape: UrineClumpShape? = nil,
         eventAt: Date = .now, note: String? = nil) {
        id = UUID()
        self.clumpCount = clumpCount
        self.size = size
        self.shape = shape
        self.eventAt = eventAt
        createdAt = .now
        self.note = note
    }
}
