import SwiftUI
import Charts

struct StatisticsView: View {
    let feedings: [FeedingRecord]
    let stools: [StoolRecord]
    let weights: [WeightRecord]
    let urines: [UrineRecord]
    @State private var range = StatisticsRange.week
    @State private var grouping = TrendGrouping.daily
    @State private var selectedFoodDate: Date?
    private var interval: DateInterval { range.interval() }
    private var meals: [FeedingRecord] { feedings.filter { $0.eventAt >= interval.start && $0.eventAt <= interval.end } }
    private var toilets: [StoolRecord] { stools.filter { $0.eventAt >= interval.start && $0.eventAt <= interval.end } }
    private var clumps: [UrineRecord] { urines.filter { $0.eventAt >= interval.start && $0.eventAt <= interval.end } }
    private var measurements: [WeightRecord] { weights.filter { $0.eventAt >= interval.start && $0.eventAt <= interval.end }.sorted { $0.eventAt < $1.eventAt } }
    private var buckets: [FoodBucket] { StatisticsService.foodBuckets(meals, grouping: grouping) }
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Text("统计 🐾").font(.largeTitle.bold())
                Text("用数据记录健康变化").foregroundStyle(.secondary)
                Picker("统计范围", selection: $range) { ForEach(StatisticsRange.allCases) { Text($0.rawValue).tag($0) } }.pickerStyle(.segmented)
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 120))], spacing: 10) {
                    metric("平均进食", meanFood, "有进食记录日均", DiaryStyle.green)
                    metric("最新体重", weights.filter { $0.eventAt <= .now }.max { $0.eventAt < $1.eventAt }.map { $0.weightKg.formatted(.number.precision(.fractionLength(2))) + " kg" } ?? "未记录", "最近一次实际称重", DiaryStyle.blue)
                    metric("排便频率", meanStool, "有排便记录日均", DiaryStyle.amber)
                    metric("日均尿团", StatisticsService.urineAverage(clumps).map { $0.formatted(.number.precision(.fractionLength(1))) + " 坨/天" } ?? "未记录", "有排尿记录日均", DiaryStyle.blue)
                }
                DiaryCard {
                    VStack(alignment: .leading, spacing: 14) {
                        Text("进食量趋势").font(.title3.bold())
                        Picker("聚合方式", selection: $grouping) { ForEach(TrendGrouping.allCases, id: \.self) { Text($0.rawValue) } }.pickerStyle(.segmented)
                        if meals.isEmpty { empty }
                        else {
                            Chart {
                                ForEach(buckets) { bucket in
                                    ForEach(FoodType.allCases) { type in
                                        if let grams = bucket.food[type] {
                                            BarMark(x: .value("日期", bucket.date, unit: grouping.component), y: .value("克", grams))
                                                .foregroundStyle(by: .value("食物", type.title))
                                        }
                                    }
                                }
                                if let selectedFoodDate, let bucket = selectedBucket(selectedFoodDate) {
                                    RuleMark(x: .value("选中日期", bucket.date, unit: grouping.component))
                                        .foregroundStyle(DiaryStyle.pink.opacity(0.6))
                                        .lineStyle(StrokeStyle(lineWidth: 1, dash: [4]))
                                }
                            }
                            .chartForegroundStyleScale(domain: FoodType.allCases.map(\.title), range: FoodType.allCases.map(\.color))
                            .chartXScale(domain: foodDomain)
                            .modifier(ChartTapSelection(selected: $selectedFoodDate))
                            .chartYAxisLabel("g").frame(height: 220)
                            if let selectedFoodDate, let bucket = selectedBucket(selectedFoodDate) {
                                FeedingBreakdown(title: bucket.date.formatted(.dateTime.month().day()) + " · " + grouping.rawValue + "进食",
                                                 food: bucket.food, close: { self.selectedFoodDate = nil })
                            } else if let selectedFoodDate {
                                FeedingBreakdown(title: selectedFoodDate.formatted(.dateTime.month().day()) + " · 未记录",
                                                 food: [:], close: { self.selectedFoodDate = nil })
                            } else {
                                Text("点击柱状条，查看总量及干粮、湿粮的精确克数")
                                    .font(.caption).foregroundStyle(.secondary)
                            }
                        }
                        Text("按实际时间聚合；未记录日期不当作零。周/月仅汇总当前筛选范围内的记录。").font(.caption2).foregroundStyle(.secondary)
                    }
                }
                DiaryCard {
                    VStack(alignment: .leading, spacing: 14) {
                        Text("体重变化").font(.title3.bold())
                        if measurements.isEmpty { empty }
                        else {
                            Chart(measurements) { record in
                                LineMark(x: .value("时间", record.eventAt), y: .value("kg", record.weightKg)).foregroundStyle(DiaryStyle.blue)
                                PointMark(x: .value("时间", record.eventAt), y: .value("kg", record.weightKg)).foregroundStyle(DiaryStyle.blue)
                            }.chartYScale(domain: weightDomain).chartYAxisLabel("kg").frame(height: 210)
                            Text("\(measurements.count) 次实际测量；只绘制真实数据点，不补齐缺失日期。").font(.caption2).foregroundStyle(.secondary)
                        }
                    }
                }
                DiaryCard {
                    VStack(alignment: .leading, spacing: 14) {
                        Text("排便频率").font(.title3.bold())
                        if toilets.isEmpty { empty }
                        else {
                            Chart(stoolDays, id: \.date) { day in
                                if let count = day.stoolCount {
                                    BarMark(x: .value("日期", day.date, unit: .day), y: .value("次数", count)).foregroundStyle(DiaryStyle.amber)
                                }
                            }.chartXScale(domain: interval.start...max(interval.end, interval.start.addingTimeInterval(1)))
                             .frame(height: 180)
                            Text("未记录不等于没有排便，不将空白日期计为 0 次。").font(.caption2).foregroundStyle(.secondary)
                        }
                    }
                }
                DiaryCard {
                    VStack(alignment: .leading, spacing: 14) {
                        Text("每日尿团数").font(.title3.bold())
                        if clumps.isEmpty { empty }
                        else {
                            Chart(urineDays, id: \.date) { day in
                                if let count = day.urineClumpCount {
                                    BarMark(x: .value("日期", day.date, unit: .day), y: .value("坨", count)).foregroundStyle(DiaryStyle.blue)
                                    PointMark(x: .value("日期", day.date, unit: .day), y: .value("坨", count)).foregroundStyle(DiaryStyle.blue)
                                }
                            }.chartYAxisLabel("坨").frame(height: 180)
                            Text("尿团数是清理观察记录，不等于排尿次数或毫升尿量；明确填写的 0 显示圆点，未记录日留空。")
                                .font(.caption2).foregroundStyle(.secondary)
                        }
                    }
                }
            }.padding(16)
        }.background(DiaryStyle.background)
         .animation(.easeInOut(duration: 0.25), value: range)
         .animation(.easeInOut(duration: 0.25), value: grouping)
         .onChange(of: range) { _, _ in selectedFoodDate = nil }
         .onChange(of: grouping) { _, _ in selectedFoodDate = nil }
    }
    private var empty: some View { ContentUnavailableView("暂时没有数据", systemImage: "chart.bar", description: Text("记录几天后，这里会开始出现趋势")) }
    private var meanFood: String {
        StatisticsService.foodAverage(meals).map { $0.formatted(.number.precision(.fractionLength(0...1))) + " g" } ?? "未记录"
    }
    private var meanStool: String {
        StatisticsService.stoolAverage(toilets).map { $0.formatted(.number.precision(.fractionLength(1))) + " 次/天" } ?? "未记录"
    }
    private var urineDays: [DaySummary] {
        StatisticsService.dayIndex(feedings: [], stools: [], weights: [], urines: clumps).values.sorted { $0.date < $1.date }
    }
    private var stoolDays: [DaySummary] {
        StatisticsService.dayIndex(feedings: [], stools: toilets, weights: []).values.sorted { $0.date < $1.date }
    }
    private var foodDomain: ClosedRange<Date> {
        let start = Calendar.current.dateInterval(of: grouping.component, for: interval.start)?.start ?? interval.start
        let end = Calendar.current.dateInterval(of: grouping.component, for: interval.end)?.end ?? interval.end
        return start...max(start.addingTimeInterval(1), end)
    }
    private var weightDomain: ClosedRange<Double> {
        let minValue = measurements.map(\.weightKg).min() ?? 0
        let maxValue = measurements.map(\.weightKg).max() ?? 1
        let pad = max(0.1, (maxValue - minValue) * 0.2)
        return max(0, minValue - pad)...(maxValue + pad)
    }
    private func metric(_ title: String, _ value: String, _ note: String, _ color: Color) -> some View {
        DiaryCard { VStack(alignment: .leading, spacing: 10) { Text(title).font(.caption).foregroundStyle(color); Text(value).font(.title3.bold()); Text(note).font(.caption2).foregroundStyle(.secondary) } }
    }
    private func selectedBucket(_ date: Date) -> FoodBucket? {
        buckets.first { Calendar.current.isDate($0.date, equalTo: date, toGranularity: grouping.component) }
    }
}


