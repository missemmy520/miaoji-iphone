import Foundation
import SwiftData

enum RecordTarget: Identifiable {
    case feeding(FeedingRecord), stool(StoolRecord), weight(WeightRecord)
    var id: UUID {
        switch self { case .feeding(let r): return r.id; case .stool(let r): return r.id; case .weight(let r): return r.id }
    }
    var petID: UUID? {
        switch self { case .feeding(let r): return r.petID; case .stool(let r): return r.petID; case .weight(let r): return r.petID }
    }
    var createdAt: Date {
        switch self { case .feeding(let r): return r.createdAt; case .stool(let r): return r.createdAt; case .weight(let r): return r.createdAt }
    }
    var draft: RecordDraft {
        var d = RecordDraft()
        switch self {
        case .feeding(let r): d.kind = .feeding; d.foodType = r.foodType; d.amount = r.amountGram.formatted(.number.grouping(.never).precision(.fractionLength(0...1))); d.eventAt = r.eventAt; d.note = r.note ?? ""
        case .stool(let r): d.kind = .stool; d.count = r.count; d.condition = r.condition; d.descriptionText = r.descriptionText ?? ""; d.eventAt = r.eventAt; d.note = r.note ?? ""
        case .weight(let r): d.kind = .weight; d.weight = r.weightKg.formatted(.number.grouping(.never).precision(.fractionLength(2))); d.eventAt = r.eventAt; d.note = r.note ?? ""
        }
        return d
    }
    @MainActor func delete(in context: ModelContext) throws {
        switch self { case .feeding(let r): context.delete(r); case .stool(let r): context.delete(r); case .weight(let r): context.delete(r) }
        do { try context.save() } catch { context.rollback(); throw error }
    }
}

enum RecordService {
    enum ValidationError: LocalizedError {
        case invalidAmount, invalidWeight, invalidCount, invalidDate, differentPet
        var errorDescription: String? {
            switch self {
            case .invalidAmount: return "请输入大于 0 的克数，最多保留一位小数。"
            case .invalidWeight: return "请输入大于 0 的体重，最多保留两位小数。"
            case .invalidCount: return "排便次数必须为 1—999 次。"
            case .invalidDate: return "实际发生时间不能晚于当前时间。"
            case .differentPet: return "记录不属于当前宠物，请关闭后重新打开。"
            }
        }
    }
    @MainActor static func save(_ draft: RecordDraft, petID: UUID, editing: RecordTarget? = nil, in context: ModelContext) throws {
        guard draft.eventAt <= .now else { throw ValidationError.invalidDate }
        guard editing.map({ $0.petID == petID && $0.draft.kind == draft.kind }) ?? true else { throw ValidationError.differentPet }
        switch draft.kind {
        case .feeding:
            guard let amount = RecordInput.positiveNumber(draft.amount, fractionDigits: 1) else { throw ValidationError.invalidAmount }
            let record: FeedingRecord
            if case .feeding(let existing) = editing { record = existing }
            else { record = FeedingRecord(foodType: draft.foodType, amountGram: amount); context.insert(record) }
            record.petID = petID; record.foodType = draft.foodType; record.amountGram = amount
            record.eventAt = draft.eventAt; record.note = RecordInput.note(draft.note)
        case .stool:
            guard (1...999).contains(draft.count) else { throw ValidationError.invalidCount }
            let record: StoolRecord
            if case .stool(let existing) = editing { record = existing }
            else { record = StoolRecord(); context.insert(record) }
            record.petID = petID; record.count = draft.count; record.condition = draft.condition
            record.descriptionText = RecordInput.note(draft.descriptionText); record.eventAt = draft.eventAt; record.note = RecordInput.note(draft.note)
        case .weight:
            guard let weight = RecordInput.positiveNumber(draft.weight, fractionDigits: 2) else { throw ValidationError.invalidWeight }
            let record: WeightRecord
            if case .weight(let existing) = editing { record = existing }
            else { record = WeightRecord(weightKg: weight); context.insert(record) }
            record.petID = petID; record.weightKg = weight; record.eventAt = draft.eventAt; record.note = RecordInput.note(draft.note)
        }
        do { try context.save() } catch { context.rollback(); throw error }
    }
}

enum RecordKind: String, CaseIterable, Identifiable {
    case feeding = "进食", stool = "排便", weight = "体重"
    var id: String { rawValue }
    var symbol: String {
        switch self { case .feeding: return "fork.knife"; case .stool: return "circle.grid.2x2.fill"; case .weight: return "scalemass.fill" }
    }
}
struct RecordDraft {
    var kind: RecordKind = .feeding
    var foodType: FoodType = .wet
    var amount = ""
    var weight = ""
    var count = 1
    var condition: StoolCondition?
    var descriptionText = ""
    var eventAt = Date.now
    var note = ""
}
