import Foundation

struct InventorySnapshot {
    let total: Double
    let consumed: Double
    let rawRemaining: Double
    let average: Double?
    var remaining: Double { max(0, rawRemaining) }
    var fraction: Double { total > 0 ? min(1, remaining / total) : 0 }
    var days: Int? {
        guard let average, average > 0 else { return nil }
        let result = floor(remaining / average)
        guard result.isFinite, result < Double(Int.max) else { return nil }
        return Int(result)
    }
    var low: Bool { fraction < 0.2 || (days.map { $0 <= 7 } ?? false) }
    var forecast: String { days.map { "预计还可食用 \($0) 天" } ?? "暂无足够饮食数据" }
}

enum InventoryService {
    static func snapshot(bag: DryFoodInventory, feedings: [FeedingRecord], adjustments: [InventoryAdjustment],
                         at date: Date = .now, calendar: Calendar = .current) -> InventorySnapshot {
        let end = min(date, bag.closedAt ?? date)
        let meals = feedings.filter { record in record.petID == bag.petID && record.foodType == .dry && record.eventAt >= bag.openedAt && record.eventAt <= end && (bag.closedAt.map { record.eventAt < $0 } ?? true) }
        let calibration = adjustments.filter { adjustment in adjustment.inventoryID == bag.id && adjustment.eventAt >= bag.openedAt && adjustment.eventAt <= end && (bag.closedAt.map { adjustment.eventAt < $0 } ?? true) }
            .max { $0.eventAt == $1.eventAt ? $0.createdAt < $1.createdAt : $0.eventAt < $1.eventAt }
        let baseline = calibration?.afterGram ?? (bag.bagTotalGram + bag.manualAdjustmentGram)
        // A weighed baseline supersedes all consumption up to its actual time.
        let afterBaseline = meals.filter { meal in calibration.map { meal.eventAt > $0.eventAt } ?? true }
        let remaining = baseline - afterBaseline.reduce(0) { $0 + $1.amountGram }
        return InventorySnapshot(total: bag.bagTotalGram, consumed: meals.reduce(0) { $0 + $1.amountGram },
                                 rawRemaining: remaining, average: averageDry(feedings, petID: bag.petID, at: date, calendar: calendar))
    }
    static func averageDry(_ feedings: [FeedingRecord], petID: UUID?, at date: Date, calendar: Calendar = .current) -> Double? {
        for count in [7, 30] {
            guard let start = calendar.date(byAdding: .day, value: -(count - 1), to: calendar.startOfDay(for: date)) else { continue }
            let records = feedings.filter { $0.petID == petID && $0.foodType == .dry && $0.eventAt >= start && $0.eventAt <= date }
            let days = Dictionary(grouping: records, by: { calendar.startOfDay(for: $0.eventAt) })
            guard days.count >= 2 else { continue }
            let average = records.reduce(0) { $0 + $1.amountGram } / Double(days.count)
            if average > 0 && average.isFinite { return average }
        }
        return nil
    }
}




struct InventoryTrendPoint {
    let date: Date
    let remaining: Double
    let unit: Calendar.Component
}
struct InventoryHistoryEvent: Identifiable {
    let id: String
    let date: Date
    let title: String
    let value: String
    let note: String
}
extension InventoryService {
    static func trend(bag: DryFoodInventory, feedings: [FeedingRecord], adjustments: [InventoryAdjustment], count: Int, at now: Date = .now, calendar: Calendar = .current) -> [InventoryTrendPoint] {
        let openedDay = calendar.startOfDay(for: bag.openedAt)
        let elapsed = (calendar.dateComponents([.day], from: openedDay, to: calendar.startOfDay(for: now)).day ?? 0) + 1
        let monthly = count == 0 && elapsed > 366
        var dates: [Date] = []
        if monthly {
            var cursor = calendar.dateInterval(of: .month, for: openedDay)?.start ?? openedDay
            while cursor <= now {
                dates.append(cursor)
                guard let next = calendar.date(byAdding: .month, value: 1, to: cursor), next > cursor else { break }
                cursor = next
            }
        } else {
            dates = StatisticsService.recentDays(ending: now, count: count == 0 ? max(1, elapsed) : count, calendar: calendar)
        }
        return dates.compactMap { day in
            let unit: Calendar.Component = monthly ? .month : .day
            guard let next = calendar.date(byAdding: unit, value: 1, to: day) else { return nil }
            let end = min(now, next.addingTimeInterval(-0.001))
            guard end >= bag.openedAt else { return nil }
            return InventoryTrendPoint(date: day, remaining: snapshot(bag: bag, feedings: feedings, adjustments: adjustments, at: end, calendar: calendar).remaining, unit: unit)
        }
    }
    static func history(bag: DryFoodInventory, feedings: [FeedingRecord], adjustments: [InventoryAdjustment], at now: Date = .now, calendar: Calendar = .current) -> [InventoryHistoryEvent] {
        func amount(_ value: Double) -> String { value.formatted(.number.precision(.fractionLength(0...1))) + " g" }
        var events = [InventoryHistoryEvent(id: "open", date: bag.openedAt, title: "开新袋", value: amount(bag.bagTotalGram), note: bag.foodName)]
        events += adjustments.filter { $0.inventoryID == bag.id }.map {
            InventoryHistoryEvent(id: $0.id.uuidString, date: $0.eventAt, title: "手动校准", value: amount($0.afterGram), note: "调整前 " + amount($0.beforeGram) + ($0.note.map { " · " + $0 } ?? ""))
        }
        let meals = feedings.filter { meal in meal.petID == bag.petID && meal.foodType == .dry && meal.eventAt >= bag.openedAt && meal.eventAt <= now && (bag.closedAt.map { meal.eventAt < $0 } ?? true) }
        let grouped = Dictionary(grouping: meals, by: { calendar.startOfDay(for: $0.eventAt) })
        events += grouped.map { day, records in
            InventoryHistoryEvent(id: "day-\(day.timeIntervalSince1970)", date: records.map(\.eventAt).max() ?? day,
                                  title: "当日消耗", value: "−" + amount(records.reduce(0) { $0 + $1.amountGram }), note: "根据实际干粮记录自动汇总")
        }
        return events.sorted { $0.date > $1.date }
    }
}
