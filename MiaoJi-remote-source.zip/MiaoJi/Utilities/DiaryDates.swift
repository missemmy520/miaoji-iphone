import Foundation

enum DiaryDates {
    static func isFutureDay(_ date: Date, now: Date = .now, calendar: Calendar = .current) -> Bool {
        calendar.startOfDay(for: date) > calendar.startOfDay(for: now)
    }
    static func monthDays(_ date: Date, calendar: Calendar = .current) -> [Date] {
        guard let interval = calendar.dateInterval(of: .month, for: date) else { return [] }
        let offset = (calendar.component(.weekday, from: interval.start) + 5) % 7
        guard let start = calendar.date(byAdding: .day, value: -offset, to: interval.start),
              let days = calendar.range(of: .day, in: .month, for: date) else { return [] }
        let cells = max(35, ((offset + days.count + 6) / 7) * 7)
        return (0..<cells).compactMap { calendar.date(byAdding: .day, value: $0, to: start) }
    }
    static func months(_ date: Date, calendar: Calendar = .current) -> [Date] {
        guard let start = calendar.dateInterval(of: .year, for: date)?.start,
              let months = calendar.range(of: .month, in: .year, for: date) else { return [] }
        return (0..<months.count).compactMap { calendar.date(byAdding: .month, value: $0, to: start) }
    }
}
