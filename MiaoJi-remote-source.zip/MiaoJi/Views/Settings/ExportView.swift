import SwiftUI
import UIKit

struct ExportView: View {
    let petName: String
    let feedings: [FeedingRecord]
    let stools: [StoolRecord]
    let weights: [WeightRecord]
    let dailyNotes: [DailyNoteRecord]
    @Environment(\.dismiss) private var dismiss
    @State private var range = ExportRange.all
    @State private var start = Calendar.current.startOfDay(for: .now)
    @State private var end = Date.now
    @State private var busy = false
    @State private var errorMessage: String?
    @State private var share: ExportFile?
    @State private var generatedURL: URL?
    enum ExportRange: String, CaseIterable { case week = "最近7天", month = "最近30天", currentMonth = "本月", all = "全部", custom = "自定义日期" }
    struct ExportFile: Identifiable { let url: URL; var id: URL { url } }
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    DiaryCard {
                        VStack(alignment: .leading, spacing: 16) {
                            Text("导出 \(petName) 的记录").font(.headline)
                            Picker("范围", selection: $range) { ForEach(ExportRange.allCases, id: \.self) { Text($0.rawValue) } }
                            if range == .custom {
                                DatePicker("开始日期", selection: $start, displayedComponents: .date)
                                DatePicker("结束日期", selection: $end, displayedComponents: .date)
                            }
                            Text("真正的 Excel 文件，包含每日汇总、进食明细、排便明细、体重明细。每日汇总带上当日情况备注，只有备注的日期也会保留；未称重留空。").font(.caption).foregroundStyle(.secondary)
                        }
                    }
                    if let errorMessage { Text(errorMessage).foregroundStyle(.pink) }
                    Button { Task { await generate() } } label: {
                        Label(busy ? "正在生成…" : "生成并分享 Excel", systemImage: "square.and.arrow.up")
                    }.buttonStyle(PinkButtonStyle()).disabled(busy)
                }.padding(16)
            }.background(DiaryStyle.background).navigationTitle("数据导出")
             .toolbar { Button("关闭") { dismiss() }.disabled(busy) }
             .interactiveDismissDisabled(busy)
             .sheet(item: $share, onDismiss: cleanup) { file in ActivityShareView(url: file.url) }
             .onDisappear { if share == nil { cleanup() } }
        }
    }
    @MainActor private func generate() async {
        guard !busy else { return }
        errorMessage = nil
        let calendar = Calendar.current
        let dateInterval: DateInterval?
        switch range {
        case .all: dateInterval = nil
        case .week: dateInterval = StatisticsRange.week.interval()
        case .month: dateInterval = StatisticsRange.month.interval()
        case .currentMonth: dateInterval = StatisticsRange.currentMonth.interval()
        case .custom:
            guard calendar.startOfDay(for: start) <= calendar.startOfDay(for: end),
                  let exclusiveEnd = calendar.date(byAdding: .day, value: 1, to: calendar.startOfDay(for: end)) else { errorMessage = "结束日期不能早于开始日期。"; return }
            dateInterval = DateInterval(start: calendar.startOfDay(for: start), end: exclusiveEnd)
        }
        func includes(_ date: Date) -> Bool { dateInterval.map { date >= $0.start && date < $0.end } ?? true }
        let meals = feedings.filter { includes($0.eventAt) }
        let toilets = stools.filter { includes($0.eventAt) }
        let measures = weights.filter { includes($0.eventAt) }
        let notes = dailyNotes.filter { includes($0.eventAt) }
        guard !meals.isEmpty || !toilets.isEmpty || !measures.isEmpty || !notes.isEmpty else { errorMessage = "所选范围没有记录，请调整日期。"; return }
        busy = true
        defer { busy = false }
        let sheets = ExcelExportService.sheets(feedings: meals, stools: toilets, weights: measures, dailyNotes: notes)
        let name = petName
        do {
            let url = try await Task.detached(priority: .userInitiated) { try ExcelExportService.write(sheets, petName: name) }.value
            generatedURL = url; share = ExportFile(url: url)
        } catch { errorMessage = error.localizedDescription }
    }
    private func cleanup() { if let generatedURL { ExcelExportService.cleanup(generatedURL) }; generatedURL = nil }
}
private struct ActivityShareView: UIViewControllerRepresentable {
    let url: URL
    func makeUIViewController(context: Context) -> UIActivityViewController { UIActivityViewController(activityItems: [url], applicationActivities: nil) }
    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}

