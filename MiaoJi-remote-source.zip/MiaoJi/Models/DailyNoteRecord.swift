import Foundation
import SwiftData

@Model
final class DailyNoteRecord {
    @Attribute(.unique) var id: UUID
    var petID: UUID
    var eventAt: Date
    var text: String
    private(set) var createdAt: Date
    var updatedAt: Date

    init(petID: UUID, eventAt: Date, text: String) {
        id = UUID()
        self.petID = petID
        self.eventAt = eventAt
        self.text = text
        createdAt = .now
        updatedAt = .now
    }
    // Restore original metadata only during a user-confirmed data import.
    func restoreImportCreatedAt(_ date: Date) { createdAt = date }
}
