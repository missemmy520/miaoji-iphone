import SwiftUI
import SwiftData
import UIKit

struct HomeView: View {
    let profile: CatProfile
    let feedings: [FeedingRecord]
    let stools: [StoolRecord]
    let weights: [WeightRecord]
    let urines: [UrineRecord]
    let bags: [DryFoodInventory]
    let adjustments: [InventoryAdjustment]
    let dailyNotes: [DailyNoteRecord]
    @State private var selectedDate = Date.now
    let openProfile: () -> Void
    let openInventory: (InventoryFoodKind) -> Void
    let openHealth: () -> Void

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                HStack(alignment: .top) {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("\(profile.name)日记 🐾").font(.largeTitle.bold())
                        Text("记录小日常 · 守护大健康").font(.subheadline).foregroundStyle(.secondary)
                    }
                    Spacer(minLength: 8)
                    Button(action: openProfile) {
                        VStack(spacing: 6) {
                            avatar
                            Text((profile.name) + " ›").font(.caption)
                        }
                    }.buttonStyle(.plain).accessibilityLabel("猫咪资料")
                }
                WeekStrip(selectedDate: $selectedDate, feedings: feedings, stools: stools, weights: weights, urines: urines, dailyNotes: dailyNotes)
                SummaryCards(summary: summary, previous: previous,
                             latestWeight: weights.filter { $0.eventAt <= endOfSelectedDay }.max { $0.eventAt < $1.eventAt },
                             isToday: Calendar.current.isDateInToday(selectedDate))
                FeedingChart(summaries: StatisticsService.recentDays(ending: selectedDate).map {
                    StatisticsService.summary(on: $0, feedings: feedings, stools: stools, weights: weights, urines: urines)
                })
                ForEach(InventoryFoodKind.allCases) { kind in
                    inventoryShortcut(kind)
                }
                Button(action: openHealth) {
                    DiaryCard {
                        HStack(spacing: 12) {
                            Image(systemName: "heart.text.clipboard").font(.title2).foregroundStyle(DiaryStyle.pink)
                            VStack(alignment: .leading, spacing: 6) {
                                Text("健康小顾问").font(.headline)
                                Text("看看记录变化 · 带来源的日常问答").font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer(); Image(systemName: "chevron.right").foregroundStyle(.secondary)
                        }
                    }
                }.buttonStyle(.plain)
                Text(Calendar.current.isDateInToday(selectedDate) ? "今日记录" : selectedDate.formatted(.dateTime.month().day()) + " · 当日记录")
                    .font(.title2.bold())
                EditableTimeline(date: selectedDate, feedings: feedings, stools: stools, weights: weights, urines: urines)
                    .animation(.easeInOut(duration: 0.3), value: entries.map(\.id))
                DailyNoteCard(date: selectedDate, petID: profile.id, records: dailyNotes)
            }.padding(16)
        }
        .background(DiaryStyle.background)
    }
    private func inventoryShortcut(_ kind: InventoryFoodKind) -> some View {
        let bag = bags.filter { $0.isCurrent && $0.foodKind == kind }.max { $0.openedAt < $1.openedAt }
        let stock = bag.map { InventoryService.snapshot(bag: $0, feedings: feedings, adjustments: adjustments) }
        let color = kind == .dry ? DiaryStyle.green : DiaryStyle.pink
        return Button { openInventory(kind) } label: {
            DiaryCard {
                HStack {
                    Image(systemName: "shippingbox").font(.title).foregroundStyle(color)
                    VStack(alignment: .leading, spacing: 6) {
                        Text(kind.title + "剩余").font(.headline)
                        if let stock {
                            Text(stock.remaining.formatted(.number.precision(.fractionLength(0...1))) + " g · " + stock.forecast).font(.caption).foregroundStyle(.secondary)
                        } else { Text("还没有设置当前" + kind.title).font(.caption).foregroundStyle(.secondary) }
                    }
                    Spacer()
                    if let stock { ProgressRing(fraction: stock.fraction, color: color) }
                    else { Image(systemName: "chevron.right").foregroundStyle(.secondary) }
                }
            }
        }.buttonStyle(.plain)
    }
    private var summary: DaySummary {
        StatisticsService.summary(on: selectedDate, feedings: feedings, stools: stools, weights: weights, urines: urines)
    }
    private var entries: [TimelineEntry] {
        TimelineEntry.entries(on: selectedDate, feedings: feedings, stools: stools, weights: weights, urines: urines)
    }
    private var previous: DaySummary {
        StatisticsService.summary(on: Calendar.current.date(byAdding: .day, value: -1, to: selectedDate) ?? selectedDate,
                                  feedings: feedings, stools: stools, weights: weights, urines: urines)
    }
    private var endOfSelectedDay: Date {
        (Calendar.current.date(byAdding: .day, value: 1, to: Calendar.current.startOfDay(for: selectedDate)) ?? selectedDate).addingTimeInterval(-0.001)
    }
    @ViewBuilder private var avatar: some View {
        if let data = profile.avatarData, let image = UIImage(data: data) {
            Image(uiImage: image).resizable().scaledToFill().frame(width: 52, height: 52).clipShape(Circle())
        } else {
            Image(systemName: "cat.fill").font(.title2).foregroundStyle(DiaryStyle.pink)
                .frame(width: 52, height: 52).background(DiaryStyle.pink.opacity(0.12), in: Circle())
        }
    }
}



