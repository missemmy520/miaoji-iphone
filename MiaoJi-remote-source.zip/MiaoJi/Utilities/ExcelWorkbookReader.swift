import Foundation
import zlib

/// Bounded OOXML reader for text/number workbooks, including ZIP DEFLATE and shared strings.
enum ExcelWorkbookReader {
    enum ReadError: LocalizedError {
        case invalid, tooLarge, unsupported
        var errorDescription: String? {
            switch self {
            case .invalid: return "Excel 文件不完整或格式无效，未导入。"
            case .tooLarge: return "Excel 超出 10 MB 或解压后 30 MB 上限，请分批导入。"
            case .unsupported: return "不支持加密、公式或特殊格式的 Excel，请使用喵记导出的多宠物 .xlsx 文件。"
            }
        }
    }
    struct Sheet { let name: String; let rows: [[String]] }
    static func read(_ data: Data) throws -> [Sheet] {
        let files = try unzip(data)
        guard let workbook = files["xl/workbook.xml"], let rel = files["xl/_rels/workbook.xml.rels"] else { throw ReadError.invalid }
        let relationships = try parse(rel)
        var paths: [String: String] = [:]
        for attributes in relationships.relationships {
            guard attributes["TargetMode"] != "External", let id = attributes["Id"], let target = attributes["Target"], !target.contains("..") else { throw ReadError.unsupported }
            paths[id] = target.hasPrefix("/") ? String(target.dropFirst()) : "xl/" + target
        }
        let names = try parse(workbook).sheets
        let strings = try files["xl/sharedStrings.xml"].map { try parse($0).strings } ?? []
        return try names.map { attributes in
            guard let name = attributes["name"], let id = attributes["r:id"], let path = paths[id], let bytes = files[path] else { throw ReadError.invalid }
            let parsed = try parse(bytes, strings: strings)
            guard !parsed.formula else { throw ReadError.unsupported }
            return Sheet(name: name, rows: parsed.rows)
        }
    }
    private static func parse(_ data: Data, strings: [String] = []) throws -> XML {
        let delegate = XML(strings: strings), parser = XMLParser(data: data)
        parser.shouldResolveExternalEntities = false; parser.delegate = delegate
        guard parser.parse(), !delegate.invalid else { throw ReadError.invalid }
        return delegate
    }
    private final class XML: NSObject, XMLParserDelegate {
        var relationships: [[String: String]] = [], sheets: [[String: String]] = [], strings: [String] = [], rows: [[String]] = []
        var invalid = false, formula = false
        private let shared: [String]
        private var row: [String] = [], type = "", col = 0, value = "", inValue = false, inString = false, sharedText = "", inSI = false
        init(strings: [String]) { shared = strings }
        func parser(_ parser: XMLParser, didStartElement name: String, namespaceURI: String?, qualifiedName qName: String?, attributes: [String: String]) {
            if name == "Relationship" { relationships.append(attributes) }
            if name == "sheet" { sheets.append(attributes) }
            if name == "row" { row = [] }
            if name == "si" { inSI = true; sharedText = "" }
            if name == "c" {
                type = attributes["t"] ?? "n"; value = ""; col = 0
                for scalar in (attributes["r"] ?? "").unicodeScalars {
                    if (65...90).contains(scalar.value) { col = col * 26 + Int(scalar.value - 64) } else { break }
                }
                if col < 1 || col > 128 { invalid = true; parser.abortParsing() }
            }
            if name == "v" { inValue = true }
            if name == "t" { inString = true }
            if name == "f" { formula = true }
        }
        func parser(_ parser: XMLParser, foundCharacters string: String) {
            if inSI && inString { sharedText += string }
            else if inValue || inString { value += string }
            if value.count > 32767 || sharedText.count > 32767 { invalid = true; parser.abortParsing() }
        }
        func parser(_ parser: XMLParser, didEndElement name: String, namespaceURI: String?, qualifiedName qName: String?) {
            if name == "v" { inValue = false }; if name == "t" { inString = false }
            if name == "si" { strings.append(sharedText); inSI = false }
            if name == "c" && col > 0 {
                var text = value
                if type == "s" { if let n = Int(value), shared.indices.contains(n) { text = shared[n] } else { invalid = true } }
                if row.count < col { row += Array(repeating: "", count: col - row.count) }; row[col - 1] = text
            }
            if name == "row" { rows.append(row); if rows.count > 50001 { invalid = true; parser.abortParsing() } }
        }
        func parser(_ parser: XMLParser, foundExternalEntityDeclarationWithName name: String, publicID: String?, systemID: String?) { invalid = true; parser.abortParsing() }
    }
    private static func unzip(_ bytes: Data) throws -> [String: Data] {
        let data = [UInt8](bytes)
        guard data.count <= 10_000_000, data.count >= 22 else { throw ReadError.tooLarge }
        func word(_ offset: Int, _ size: Int) throws -> Int {
            guard offset >= 0, offset + size <= data.count else { throw ReadError.invalid }
            return (0..<size).reduce(0) { $0 | Int(data[offset + $1]) << ($1 * 8) }
        }
        var end: Int?
        for n in stride(from: data.count - 22, through: max(0, data.count - 65557), by: -1) {
            if try word(n, 4) == 0x06054b50, n + 22 + (try word(n + 20, 2)) == data.count { end = n; break }
        }
        guard let end, try word(end + 4, 2) == 0, try word(end + 6, 2) == 0 else { throw ReadError.unsupported }
        let count = try word(end + 10, 2); var cursor = try word(end + 16, 4), total = 0
        guard count <= 1500 else { throw ReadError.tooLarge }
        var output: [String: Data] = [:]
        for _ in 0..<count {
            guard try word(cursor, 4) == 0x02014b50 else { throw ReadError.invalid }
            let flags = try word(cursor + 8, 2), method = try word(cursor + 10, 2), crc = try word(cursor + 16, 4)
            let packed = try word(cursor + 20, 4), size = try word(cursor + 24, 4), names = try word(cursor + 28, 2)
            let extra = try word(cursor + 30, 2), comment = try word(cursor + 32, 2), local = try word(cursor + 42, 4)
            total += size; guard total <= 30_000_000, size < 30_000_000 else { throw ReadError.tooLarge }
            guard flags & 1 == 0, [0,8].contains(method), cursor + 46 + names <= data.count else { throw ReadError.unsupported }
            let name = String(decoding: data[(cursor + 46)..<(cursor + 46 + names)], as: UTF8.self)
            guard !name.hasPrefix("/"), !name.contains(".."), !name.contains("\\"), output[name] == nil, try word(local, 4) == 0x04034b50 else { throw ReadError.invalid }
            let start = local + 30 + (try word(local + 26, 2)) + (try word(local + 28, 2))
            guard start >= 0, start + packed <= data.count else { throw ReadError.invalid }
            let content: Data
            if method == 0 { content = Data(data[start..<(start + packed)]) }
            else {
                var stream = z_stream(), result = [UInt8](repeating: 0, count: max(size, 1))
                guard inflateInit2_(&stream, -MAX_WBITS, ZLIB_VERSION, Int32(MemoryLayout<z_stream>.size)) == Z_OK else { throw ReadError.invalid }
                defer { inflateEnd(&stream) }
                let status = data.withUnsafeBytes { source in result.withUnsafeMutableBytes { dest in
                    guard let input = source.bindMemory(to: Bytef.self).baseAddress else { return Z_DATA_ERROR }
                    stream.next_in = UnsafeMutablePointer(mutating: input.advanced(by: start)); stream.avail_in = uInt(packed)
                    stream.next_out = dest.bindMemory(to: Bytef.self).baseAddress; stream.avail_out = uInt(max(size, 1))
                    return inflate(&stream, Z_FINISH)
                } }
                guard status == Z_STREAM_END, stream.total_out == size, stream.total_in == packed else { throw ReadError.invalid }
                content = Data(result.prefix(size))
            }
            guard content.count == size else { throw ReadError.invalid }
            let actualCRC = content.withUnsafeBytes { zlib.crc32(0, $0.bindMemory(to: Bytef.self).baseAddress, uInt(content.count)) }
            guard UInt32(actualCRC) == UInt32(crc) else { throw ReadError.invalid }
            output[name] = content; cursor += 46 + names + extra + comment
        }
        return output
    }
}
