import SwiftUI
import SwiftData
import Charts
import UIKit

struct InventoryView: View {
    let petID: UUID
    let bags: [DryFoodInventory]
    let feedings: [FeedingRecord]
    let adjustments: [InventoryAdjustment]
    @State private var showsNew = false
    @State private var showsCalibration = false
    @State private var trendDays = 7
    private var current: DryFoodInventory? { bags.filter(\.isCurrent).max { $0.openedAt < $1.openedAt } }
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Text("干粮库存 🐾").font(.largeTitle.bold())
                Text("记录干粮库存，合理安排喂食").foregroundStyle(.secondary)
                if let bag = current {
                    let stock = InventoryService.snapshot(bag: bag, feedings: feedings, adjustments: adjustments)
                    DiaryCard {
                        VStack(alignment: .leading, spacing: 16) {
                            Text(bag.foodName).font(.headline)
                            HStack {
                                VStack(alignment: .leading, spacing: 10) {
                                    Text("当前剩余").foregroundStyle(.secondary)
                                    Text(amount(stock.remaining)).font(.system(size: 38, weight: .semibold, design: .rounded))
                                    Text("/ " + amount(stock.total)).foregroundStyle(.secondary)
                                }
                                Spacer()
                                ProgressRing(fraction: stock.fraction)
                            }
                            Text(stock.forecast).foregroundStyle(DiaryStyle.green)
                            if stock.low { Label("库存偏低，请安排补货", systemImage: "exclamationmark.circle.fill").foregroundStyle(DiaryStyle.pink) }
                            if stock.rawRemaining < 0 { Text("记录消耗已超出库存 \(amount(-stock.rawRemaining))，请核对开袋时间或校准。").font(.caption).foregroundStyle(DiaryStyle.pink) }
                        }
                    }
                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                        smallCard("本袋总量", amount(stock.total)); smallCard("已记录食用", amount(stock.consumed))
                        smallCard("剩余", amount(stock.remaining)); smallCard("预计可食用", stock.days.map { "\($0) 天" } ?? "数据不足")
                    }
                    HStack {
                        Button("开新袋") { showsNew = true }.buttonStyle(PinkButtonStyle())
                        Button("手动校准") { showsCalibration = true }.buttonStyle(PinkButtonStyle())
                    }
                    DiaryCard {
                        VStack(alignment: .leading, spacing: 12) {
                            Text("库存趋势").font(.title3.bold())
                            Picker("范围", selection: $trendDays) { Text("近7天").tag(7); Text("近30天").tag(30); Text("全部").tag(0) }.pickerStyle(.segmented)
                            Chart(InventoryService.trend(bag: bag, feedings: feedings, adjustments: adjustments, count: trendDays), id: \.date) { point in
                                BarMark(x: .value("日期", point.date, unit: point.unit), y: .value("克", point.remaining)).foregroundStyle(DiaryStyle.green)
                            }.frame(height: 180).chartYAxisLabel("g")
                            Text("按记录与校准重算，每日结束时的剩余量；今天截至当前。").font(.caption2).foregroundStyle(.secondary)
                        }
                    }
                    Text("库存记录").font(.title2.bold())
                    ForEach(InventoryService.history(bag: bag, feedings: feedings, adjustments: adjustments)) { event in
                        DiaryCard {
                            VStack(alignment: .leading, spacing: 8) {
                                HStack { Text(event.title).font(.headline); Spacer(); Text(event.value).foregroundStyle(DiaryStyle.green) }
                                Text(event.date.formatted(date: .abbreviated, time: .shortened)).font(.caption).foregroundStyle(.secondary)
                                if !event.note.isEmpty { Text(event.note).font(.caption).foregroundStyle(.secondary) }
                            }
                        }
                    }
                    if bags.count > 1 {
                        Text("历史粮袋").font(.title3.bold())
                        ForEach(bags.filter { !$0.isCurrent }.sorted { $0.openedAt > $1.openedAt }) { old in
                            DiaryCard {
                                VStack(alignment: .leading, spacing: 6) {
                                    Text(old.foodName).font(.headline)
                                    Text(old.openedAt.formatted(date: .abbreviated, time: .shortened) + " · " + amount(old.bagTotalGram)).font(.caption).foregroundStyle(.secondary)
                                }
                            }
                        }
                    }
                } else {
                    ContentUnavailableView("还没有设置当前干粮", systemImage: "shippingbox", description: Text("开新袋后，干粮记录会自动关联库存"))
                    Button("开新袋") { showsNew = true }.buttonStyle(PinkButtonStyle())
                }
            }.padding(16)
        }.background(DiaryStyle.background)
         .sheet(isPresented: $showsNew) { InventoryEntryView(petID: petID, current: current, feedings: feedings, adjustments: adjustments, calibrating: false) }
         .sheet(isPresented: $showsCalibration) { InventoryEntryView(petID: petID, current: current, feedings: feedings, adjustments: adjustments, calibrating: true) }
    }
    private func amount(_ value: Double) -> String { value.formatted(.number.precision(.fractionLength(0...1))) + " g" }
    private func smallCard(_ title: String, _ value: String) -> some View {
        DiaryCard { VStack(alignment: .leading, spacing: 10) { Text(title).font(.caption).foregroundStyle(.secondary); Text(value).font(.title3.bold()) } }
    }

}

struct ProgressRing: View {
    let fraction: Double
    var body: some View {
        ZStack {
            Circle().stroke(DiaryStyle.green.opacity(0.18), lineWidth: 14)
            Circle().trim(from: 0, to: fraction).stroke(DiaryStyle.green, style: StrokeStyle(lineWidth: 14, lineCap: .round)).rotationEffect(.degrees(-90))
            VStack { Text((fraction * 100).formatted(.number.precision(.fractionLength(0))) + "%").font(.title.bold()); Text("剩余").font(.caption).foregroundStyle(.secondary) }
        }.frame(width: 116, height: 116).padding(8).animation(.easeInOut(duration: 0.3), value: fraction)
    }
}

private struct InventoryEntryView: View {
    let petID: UUID
    let current: DryFoodInventory?
    let feedings: [FeedingRecord]
    let adjustments: [InventoryAdjustment]
    let calibrating: Bool
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    @State private var name = ""
    @State private var grams = ""
    @State private var eventAt = Date.now
    @State private var note = ""
    @State private var errorMessage: String?
    @State private var saving = false
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 18) {
                    DiaryCard {
                        VStack(alignment: .leading, spacing: 18) {
                            if !calibrating { TextField("猫粮名称", text: $name) }
                            TextField(calibrating ? "实际剩余克数（允许 0）" : "本袋总克数", text: $grams).keyboardType(.decimalPad)
                            Text("单位 g，最多一位小数").font(.caption).foregroundStyle(.secondary)
                            if !calibrating { DatePicker("开袋时间", selection: $eventAt, in: ...Date.now) }
                            else { Text("校准时间为保存时的当前时间，以本次称重为新基准。").font(.caption).foregroundStyle(.secondary) }
                            TextField("备注（可选）", text: $note, axis: .vertical)
                        }
                    }
                    if let errorMessage { Text(errorMessage).foregroundStyle(.pink) }
                    Button(saving ? "正在保存…" : "保存", action: save).buttonStyle(PinkButtonStyle()).disabled(saving)
                }.padding(16)
            }.background(DiaryStyle.background).navigationTitle(calibrating ? "校准库存" : "开新袋")
             .toolbar { Button("取消") { dismiss() } }
        }
    }
    private func save() {
        guard !saving else { return }
        let trimmed = grams.trimmingCharacters(in: .whitespacesAndNewlines)
        let value = RecordInput.positiveNumber(trimmed, fractionDigits: 1) ?? (["0", "0.0", "0,0"].contains(trimmed) ? 0 : nil)
        guard let value, calibrating || value > 0 else { errorMessage = "请输入有效克数，最多一位小数。"; return }
        if calibrating {
            guard let current else { errorMessage = "请先开新袋。"; return }
            let now = Date.now
            let before = InventoryService.snapshot(bag: current, feedings: feedings, adjustments: adjustments, at: now).remaining
            context.insert(InventoryAdjustment(inventoryID: current.id, beforeGram: before, afterGram: value, eventAt: now, note: RecordInput.note(note)))
        } else {
            let foodName = name.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !foodName.isEmpty else { errorMessage = "请填写猫粮名称。"; return }
            guard current.map({ eventAt > $0.openedAt }) ?? true else { errorMessage = "新袋开袋时间必须晚于当前袋。"; return }
            if let current, let last = adjustments.filter({ $0.inventoryID == current.id }).map(\.eventAt).max(), eventAt < last { errorMessage = "开袋时间不能早于当前袋最后一次校准。"; return }
            current?.isCurrent = false; current?.closedAt = eventAt
            let bag = DryFoodInventory(foodName: foodName, bagTotalGram: value, openedAt: eventAt)
            bag.petID = petID; context.insert(bag)
        }
        saving = true
        do { try context.save(); UIImpactFeedbackGenerator(style: .light).impactOccurred(); dismiss() }
        catch { context.rollback(); saving = false; errorMessage = error.localizedDescription }
    }
}




