import SwiftUI
import SwiftData

struct FoundationView: View {
    @Environment(\.modelContext) private var context
    @Query private var pets: [CatProfile]
    @AppStorage("selectedPetID") private var selectedID = ""
    @State private var ready = false
    @State private var errorMessage: String?
    @State private var showsNewPet = false
    private var selected: CatProfile? { pets.first { $0.id.uuidString == selectedID } ?? pets.first }

    var body: some View {
        Group {
            if ready, let pet = selected {
                PetWorkspace(profile: pet, pets: pets, choosePet: { selectedID = $0.uuidString },
                             newPet: { showsNewPet = true }).id(pet.id)
            } else {
                VStack(spacing: 16) {
                    Text(errorMessage ?? "正在打开本地记录…")
                    if errorMessage != nil { Button("重试") { prepare() } }
                }.frame(maxWidth: .infinity, maxHeight: .infinity).background(DiaryStyle.background)
            }
        }
        .task { prepare() }
        .sheet(isPresented: $showsNewPet) {
            CatProfileView(isNew: true, didSave: { selectedID = $0.uuidString })
        }
    }
    private func prepare() {
        do { try PetDataService.prepare(in: context); ready = true; errorMessage = nil }
        catch { errorMessage = "本地数据准备失败：\(error.localizedDescription)" }
    }
}

private enum DiaryTab: CaseIterable {
    case home, calendar, statistics, inventory, settings
    var title: String {
        switch self {
        case .home: return "首页"
        case .calendar: return "日历"
        case .statistics: return "统计"
        case .inventory: return "库存"
        case .settings: return "设置"
        }
    }
    var symbol: String {
        switch self {
        case .home: return "house.fill"
        case .calendar: return "calendar"
        case .statistics: return "chart.bar.fill"
        case .inventory: return "shippingbox"
        case .settings: return "gearshape"
        }
    }
}

private struct PetWorkspace: View {
    let profile: CatProfile
    let pets: [CatProfile]
    let choosePet: (UUID) -> Void
    let newPet: () -> Void
    @Query private var feedings: [FeedingRecord]
    @Query private var stools: [StoolRecord]
    @Query private var weights: [WeightRecord]
    @Query private var bags: [DryFoodInventory]
    @Query private var adjustments: [InventoryAdjustment]
    @Query private var dailyNotes: [DailyNoteRecord]
    @Query private var urines: [UrineRecord]
    @State private var tab = DiaryTab.home
    @State private var showsAdd = false
    @State private var showsProfile = false
    @State private var showsExport = false
    @State private var showsHealth = false
    @State private var showsWebSync = false
    @State private var showsExcel = false
    @State private var inventoryKind = InventoryFoodKind.dry
    #if DEBUG
    @Environment(\.modelContext) private var debugContext
    @State private var debugReport = ""
    @State private var showsSeedConfirmation = false
    #endif

    init(profile: CatProfile, pets: [CatProfile], choosePet: @escaping (UUID) -> Void, newPet: @escaping () -> Void) {
        self.profile = profile; self.pets = pets; self.choosePet = choosePet; self.newPet = newPet
        let id: UUID? = profile.id
        _feedings = Query(filter: #Predicate<FeedingRecord> { $0.petID == id }, sort: \FeedingRecord.eventAt)
        _stools = Query(filter: #Predicate<StoolRecord> { $0.petID == id }, sort: \StoolRecord.eventAt)
        _weights = Query(filter: #Predicate<WeightRecord> { $0.petID == id }, sort: \WeightRecord.eventAt)
        _bags = Query(filter: #Predicate<DryFoodInventory> { $0.petID == id }, sort: \DryFoodInventory.openedAt)
        _urines = Query(filter: #Predicate<UrineRecord> { $0.petID == id }, sort: \UrineRecord.eventAt)
        let notePetID = profile.id
        _dailyNotes = Query(filter: #Predicate<DailyNoteRecord> { $0.petID == notePetID }, sort: \DailyNoteRecord.eventAt)
    }

    var body: some View {
        Group {
            switch tab {
            case .home:
                HomeView(profile: profile, feedings: feedings, stools: stools, weights: weights, urines: urines,
                         bags: bags, adjustments: adjustments, dailyNotes: dailyNotes, openProfile: { showsProfile = true },
                         openInventory: { inventoryKind = $0; tab = .inventory }, openHealth: { showsHealth = true })
            case .calendar: DiaryCalendarView(petID: profile.id, feedings: feedings, stools: stools, weights: weights, urines: urines, dailyNotes: dailyNotes)
            case .statistics: StatisticsView(feedings: feedings, stools: stools, weights: weights, urines: urines)
            case .inventory: InventoryView(petID: profile.id, bags: bags, feedings: feedings, adjustments: adjustments, kind: $inventoryKind)
            case .settings: settings
            }
        }
        .safeAreaInset(edge: .top, spacing: 0) {
            HStack {
                Menu {
                    ForEach(pets) { pet in Button(pet.name) { choosePet(pet.id) } }
                    Divider()
                    Button("新增宠物", systemImage: "plus", action: newPet)
                } label: { Label(profile.name + " ▾", systemImage: "pawprint.fill").font(.subheadline.bold()) }
                Spacer()
                Text("本地日记").font(.caption).foregroundStyle(.secondary)
            }.padding(.horizontal, 18).padding(.vertical, 10).background(DiaryStyle.background)
        }
        .safeAreaInset(edge: .bottom, spacing: 0) { tabBar }
        .sheet(isPresented: $showsAdd) { AddRecordView(petID: profile.id) }
        .sheet(isPresented: $showsWebSync) { WebDataSyncView() }
        .sheet(isPresented: $showsExcel) { ExcelDataView(petID: profile.id) }
        .sheet(isPresented: $showsHealth) { HealthAdvisorView(profile: profile, feedings: feedings, stools: stools, weights: weights, urines: urines) }
        .sheet(isPresented: $showsProfile) { CatProfileView(petID: profile.id) }
        .sheet(isPresented: $showsExport) { ExportView(petName: profile.name, feedings: feedings, stools: stools, weights: weights, urines: urines, dailyNotes: dailyNotes) }
    }
    private var settings: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Text("设置").font(.largeTitle.bold())
                Button { showsProfile = true } label: { DiaryCard { Label("\(profile.name)资料", systemImage: "cat.fill") } }.buttonStyle(.plain)
                DiaryCard {
                    VStack(alignment: .leading, spacing: 14) {
                        Text("我的宠物").font(.headline)
                        ForEach(pets) { pet in
                            Button { choosePet(pet.id) } label: {
                                HStack { Text(pet.name); Spacer(); if pet.id == profile.id { Image(systemName: "checkmark") } }
                            }
                        }
                        Button("新增宠物", systemImage: "plus", action: newPet)
                    }
                }
                #if DEBUG
                DiaryCard {
                    VStack(alignment: .leading, spacing: 14) {
                        Text("开发测试").font(.headline)
                        Button("运行逻辑自检（不修改你的记录）") {
                            do { debugReport = try DebugTools.runChecks() }
                            catch { debugReport = "自检失败：" + error.localizedDescription }
                        }
                        Button("载入示例数据到当前宠物") { showsSeedConfirmation = true }
                        if !debugReport.isEmpty { Text(debugReport).font(.caption).textSelection(.enabled) }
                    }
                }
                .confirmationDialog("向当前宠物添加 2026年10月13—16日的示例记录？", isPresented: $showsSeedConfirmation, titleVisibility: .visible) {
                    Button("添加示例数据") {
                        do { try DebugTools.seed(petID: profile.id, in: debugContext); debugReport = "已载入示例数据。" }
                        catch { debugContext.rollback(); debugReport = error.localizedDescription }
                    }
                }
                #endif
                Button { showsExcel = true } label: { DiaryCard { Label("Excel 导入导出", systemImage: "tablecells") } }.buttonStyle(.plain)
                Button { showsWebSync = true } label: { DiaryCard { Label("联网数据同步", systemImage: "arrow.triangle.2.circlepath") } }.buttonStyle(.plain)
                Button { showsHealth = true } label: { DiaryCard { Label("健康小顾问", systemImage: "heart.text.clipboard") } }.buttonStyle(.plain)
                Button { showsExport = true } label: { DiaryCard { Label("导出 Excel", systemImage: "square.and.arrow.up") } }.buttonStyle(.plain)
                DiaryCard {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("喵记 · 0.11.2").font(.headline)
                        Text("本地记录 · 可选网页数据互通与文献检索").font(.caption).foregroundStyle(.secondary)
                        Text("设计者：emmyhuang").font(.subheadline)
                        Text("© 2026 emmyhuang · 仅限个人非商业使用").font(.caption).foregroundStyle(.secondary)
                        if let sourceURL = URL(string: "https://github.com/missemmy520/miaoji-iphone") {
                            Link("官方源码与使用许可", destination: sourceURL).font(.caption)
                        }
                        Text("修改或分享时请保留原始设计署名。版本来源以官方仓库发布记录为准。").font(.caption).foregroundStyle(.secondary)
                    }
                }
            }.padding(16)
        }.background(DiaryStyle.background)
    }
    private var tabBar: some View {
        HStack(spacing: 0) {
            tabButton(.home); tabButton(.calendar)
            Button { showsAdd = true } label: {
                Image(systemName: "plus").font(.system(size: 30, weight: .medium)).foregroundStyle(DiaryStyle.background)
                    .frame(width: 58, height: 58).background(DiaryStyle.pink.gradient, in: Circle()).frame(maxWidth: .infinity)
            }.buttonStyle(.plain).accessibilityLabel("新增记录")
            tabButton(.statistics); tabButton(.inventory); tabButton(.settings)
        }.padding(.horizontal, 8).padding(.top, 10).padding(.bottom, 6)
         .background {
             UnevenRoundedRectangle(topLeadingRadius: 26, topTrailingRadius: 26)
                 .fill(Color(red: 0.12, green: 0.13, blue: 0.145))
                 .ignoresSafeArea(.container, edges: .bottom)
         }
    }
    private func tabButton(_ item: DiaryTab) -> some View {
        Button { tab = item } label: {
            VStack(spacing: 6) { Image(systemName: item.symbol).font(.system(size: 21)); Text(item.title).font(.caption2) }
                .foregroundStyle(tab == item ? DiaryStyle.pink : .gray).frame(maxWidth: .infinity).frame(minHeight: 48)
        }.buttonStyle(.plain).accessibilityAddTraits(tab == item ? .isSelected : [])
    }
}

