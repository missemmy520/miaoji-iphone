import Foundation
import SwiftData

enum DataInterchangeService {
    static let website = "https://miaoji-emmy-diary.warmbox1030.chatgpt.site"
    struct Report { var inserted = 0; var updated = 0; var skipped = 0; var unsupported = 0
        var text: String { "新增 \(inserted) 条，更新 \(updated) 条，保留/跳过 \(skipped) 条，仅汇总未转为明细 \(unsupported) 条。" }
    }
    enum ImportError: LocalizedError {
        case invalid
        var errorDescription: String? { "互通文件格式或内容无效，未修改本地数据。请使用喵记网页版下载的 JSON 备份。" }
    }
    struct Row {
        let id: UUID; let petID: UUID; let kind: String; let data: [String: Any]
        func string(_ key: String) -> String { data[key] as? String ?? "" }
        func number(_ key: String) -> Double { (data[key] as? NSNumber)?.doubleValue ?? 0 }
        func date(_ key: String) throws -> Date {
            let text = string(key)
            let fractional = ISO8601DateFormatter(); fractional.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
            guard let value = fractional.date(from: text) ?? ISO8601DateFormatter().date(from: text) else { throw ImportError.invalid }
            return value
        }
    }
    static func parse(_ bytes: Data) throws -> [Row] {
        guard bytes.count <= 20_000_000,
              let document = try JSONSerialization.jsonObject(with: bytes) as? [String: Any], document["format"] as? String == "miaoji-sync-1",
              let records = document["records"] as? [[String: Any]], records.count <= 50000 else { throw ImportError.invalid }
        let rows = try records.map { record -> Row in
            guard let idText = record["id"] as? String, let id = UUID(uuidString: idText),
                  let petText = record["petID"] as? String, let petID = UUID(uuidString: petText),
                  let kind = record["kind"] as? String, let data = record["data"] as? [String: Any],
                  ["pet", "feeding", "stool", "urine", "weight", "note", "inventory", "adjustment", "summary"].contains(kind),
                  record["deleted"] as? Bool != true else { throw ImportError.invalid }
            let row = Row(id: id, petID: petID, kind: kind, data: data)
            if kind == "pet" { guard !row.string("name").trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { throw ImportError.invalid } }
            else if kind == "inventory" {
                _ = try row.date("openedAt")
                guard row.number("bagTotalGram") > 0, ["dry", "wet"].contains(row.string("foodType")) else { throw ImportError.invalid }
                if data["closedAt"] is String { _ = try row.date("closedAt") }
            } else {
                _ = try row.date("eventAt"); _ = try row.date("createdAt")
                if kind == "feeding" { guard FoodType(rawValue: row.string("foodType")) != nil, row.number("amountGram") > 0 else { throw ImportError.invalid } }
                if kind == "weight" { guard row.number("weightKg") > 0 else { throw ImportError.invalid } }
                if kind == "stool" || kind == "urine" {
                    let count = row.number(kind == "stool" ? "count" : "clumpCount")
                    guard count >= (kind == "stool" ? 1 : 0), count <= 999, count.rounded() == count else { throw ImportError.invalid }
                }
                if kind == "adjustment" { guard UUID(uuidString: row.string("inventoryID")) != nil, row.number("afterGram") >= 0 else { throw ImportError.invalid } }
            }
            guard data.values.allSatisfy({ value in ((value as? String)?.count ?? 0) <= 10000 }) else { throw ImportError.invalid }
            return row
        }
        guard Set(rows.map(\.id)).count == rows.count else { throw ImportError.invalid }
        return rows
    }
    @MainActor static func export(in context: ModelContext) throws -> Data {
        let iso = ISO8601DateFormatter(); iso.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        func date(_ value: Date) -> String { iso.string(from: value) }
        var rows: [[String: Any]] = []
        func add(_ id: UUID, _ kind: String, _ pet: UUID?, _ data: [String: Any]) {
            guard let pet else { return }
            rows.append(["id": id.uuidString.lowercased(), "petID": pet.uuidString.lowercased(), "kind": kind, "version": 0, "data": data])
        }
        for p in try context.fetch(FetchDescriptor<CatProfile>()) { add(p.id, "pet", p.id, ["name": p.name, "species": p.species, "note": p.note ?? ""]) }
        for r in try context.fetch(FetchDescriptor<FeedingRecord>()) { add(r.id, "feeding", r.petID, ["eventAt": date(r.eventAt), "createdAt": date(r.createdAt), "foodType": r.foodType.rawValue, "amountGram": r.amountGram, "note": r.note ?? ""]) }
        for r in try context.fetch(FetchDescriptor<StoolRecord>()) { add(r.id, "stool", r.petID, ["eventAt": date(r.eventAt), "createdAt": date(r.createdAt), "count": r.count, "condition": r.condition?.title ?? "", "descriptionText": r.descriptionText ?? "", "note": r.note ?? ""]) }
        for r in try context.fetch(FetchDescriptor<UrineRecord>()) { add(r.id, "urine", r.petID, ["eventAt": date(r.eventAt), "createdAt": date(r.createdAt), "clumpCount": r.clumpCount, "size": r.size?.title ?? "", "shape": r.shape?.title ?? "", "note": r.note ?? ""]) }
        for r in try context.fetch(FetchDescriptor<WeightRecord>()) { add(r.id, "weight", r.petID, ["eventAt": date(r.eventAt), "createdAt": date(r.createdAt), "weightKg": r.weightKg, "note": r.note ?? ""]) }
        for r in try context.fetch(FetchDescriptor<DailyNoteRecord>()) { add(r.id, "note", r.petID, ["eventAt": date(r.eventAt), "createdAt": date(r.createdAt), "note": r.text]) }
        let bags = try context.fetch(FetchDescriptor<DryFoodInventory>())
        for b in bags {
            var data: [String: Any] = ["foodName": b.foodName, "foodType": b.foodKind.rawValue, "bagTotalGram": b.bagTotalGram, "openedAt": date(b.openedAt), "manualAdjustmentGram": b.manualAdjustmentGram, "isCurrent": b.isCurrent]
            if let closed = b.closedAt { data["closedAt"] = date(closed) }
            add(b.id, "inventory", b.petID, data)
        }
        for r in try context.fetch(FetchDescriptor<InventoryAdjustment>()) {
            add(r.id, "adjustment", bags.first { $0.id == r.inventoryID }?.petID, ["eventAt": date(r.eventAt), "createdAt": date(r.createdAt), "inventoryID": r.inventoryID.uuidString.lowercased(), "beforeGram": r.beforeGram, "afterGram": r.afterGram, "note": r.note ?? ""])
        }
        return try JSONSerialization.data(withJSONObject: ["format": "miaoji-sync-1", "records": rows], options: [.sortedKeys])
    }
    @MainActor static func apply(_ rows: [Row], overwrite: Bool, in context: ModelContext) throws -> Report {
        var report = Report()
        var pets = try context.fetch(FetchDescriptor<CatProfile>())
        var mapping: [UUID: UUID] = [:]
        for row in rows where row.kind == "pet" {
            if let existing = pets.first(where: { $0.id == row.id }) {
                mapping[row.id] = existing.id
                if overwrite { existing.name = row.string("name"); existing.note = row.string("note"); report.updated += 1 } else { report.skipped += 1 }
            } else if pets.filter({ $0.name == row.string("name") && $0.species == (row.data["species"] as? String ?? "猫") }).count == 1,
                      let same = pets.first(where: { $0.name == row.string("name") }) {
                mapping[row.id] = same.id; report.skipped += 1
            } else {
                let p = CatProfile(name: row.string("name")); p.id = row.id; p.species = row.data["species"] as? String ?? "猫"
                context.insert(p); pets.append(p); mapping[row.id] = p.id; report.inserted += 1
            }
        }
        for p in pets { mapping[p.id] = p.id }
        var feeding = try context.fetch(FetchDescriptor<FeedingRecord>())
        var stools = try context.fetch(FetchDescriptor<StoolRecord>())
        var urine = try context.fetch(FetchDescriptor<UrineRecord>())
        var weights = try context.fetch(FetchDescriptor<WeightRecord>())
        var notes = try context.fetch(FetchDescriptor<DailyNoteRecord>())
        var bags = try context.fetch(FetchDescriptor<DryFoodInventory>())
        var adjustments = try context.fetch(FetchDescriptor<InventoryAdjustment>())
        let initialIDs = Set(feeding.map(\.id) + stools.map(\.id) + urine.map(\.id) + weights.map(\.id))
        var consumedDuplicates = Set<UUID>()
        func consumeDuplicate<T>(_ list: [T], id: (T) -> UUID, matches: (T) -> Bool) -> Bool {
            guard let duplicate = list.first(where: { initialIDs.contains(id($0)) && !consumedDuplicates.contains(id($0)) && matches($0) }) else { return false }
            consumedDuplicates.insert(id(duplicate)); return true
        }
        func sameMinute(_ a: Date, _ b: Date) -> Bool { floor(a.timeIntervalSince1970 / 60) == floor(b.timeIntervalSince1970 / 60) }
        for row in rows where row.kind != "pet" && row.kind != "adjustment" {
            guard let pet = mapping[row.petID] else { throw ImportError.invalid }
            if row.kind == "summary" { report.unsupported += 1; continue }
            if row.kind == "inventory" {
                let old = bags.first { $0.id == row.id }
                if old != nil && !overwrite { report.skipped += 1; continue }
                let b = old ?? DryFoodInventory(foodName: row.string("foodName"), bagTotalGram: row.number("bagTotalGram"))
                b.id = row.id; b.petID = pet; b.foodName = row.string("foodName"); b.bagTotalGram = row.number("bagTotalGram"); b.foodKindRaw = row.string("foodType")
                b.openedAt = try row.date("openedAt"); b.closedAt = row.data["closedAt"] is String ? try row.date("closedAt") : nil
                b.isCurrent = row.data["isCurrent"] as? Bool ?? true; b.manualAdjustmentGram = row.number("manualAdjustmentGram")
                if old == nil { context.insert(b); bags.append(b); report.inserted += 1 } else { report.updated += 1 }; continue
            }
            let event = try row.date("eventAt"), created = try row.date("createdAt"), note = row.string("note")
            switch row.kind {
            case "feeding":
                guard let food = FoodType(rawValue: row.string("foodType")) else { throw ImportError.invalid }
                let old = feeding.first { $0.id == row.id }; if let old { consumedDuplicates.insert(old.id) }
                if old != nil && !overwrite { report.skipped += 1; continue }
                if old == nil && consumeDuplicate(feeding, id: { $0.id }, matches: { $0.petID == pet && $0.foodType == food && $0.amountGram == row.number("amountGram") && sameMinute($0.eventAt, event) && sameMinute($0.createdAt, created) && ($0.note ?? "") == note }) { report.skipped += 1; continue }
                let r = old ?? FeedingRecord(foodType: food, amountGram: row.number("amountGram")); r.id = row.id; r.petID = pet; r.foodType = food; r.amountGram = row.number("amountGram"); r.eventAt = event; r.note = note; r.restoreImportCreatedAt(created)
                if old == nil { context.insert(r); feeding.append(r); report.inserted += 1 } else { report.updated += 1 }
            case "stool":
                let old = stools.first { $0.id == row.id }; if let old { consumedDuplicates.insert(old.id) }; if old != nil && !overwrite { report.skipped += 1; continue }
                if old == nil && consumeDuplicate(stools, id: { $0.id }, matches: { $0.petID == pet && $0.count == Int(row.number("count")) && ($0.condition?.title ?? "") == row.string("condition") && ($0.descriptionText ?? "") == row.string("descriptionText") && sameMinute($0.eventAt, event) && sameMinute($0.createdAt, created) && ($0.note ?? "") == note }) { report.skipped += 1; continue }
                let r = old ?? StoolRecord(); r.id = row.id; r.petID = pet; r.count = Int(row.number("count")); r.condition = StoolCondition.allCases.first { $0.title == row.string("condition") }; r.descriptionText = row.string("descriptionText"); r.eventAt = event; r.note = note; r.restoreImportCreatedAt(created)
                if old == nil { context.insert(r); stools.append(r); report.inserted += 1 } else { report.updated += 1 }
            case "urine":
                let old = urine.first { $0.id == row.id }; if let old { consumedDuplicates.insert(old.id) }; if old != nil && !overwrite { report.skipped += 1; continue }
                if old == nil && consumeDuplicate(urine, id: { $0.id }, matches: { $0.petID == pet && $0.clumpCount == Int(row.number("clumpCount")) && ($0.size?.title ?? "") == row.string("size") && ($0.shape?.title ?? "") == row.string("shape") && sameMinute($0.eventAt, event) && sameMinute($0.createdAt, created) && ($0.note ?? "") == note }) { report.skipped += 1; continue }
                let r = old ?? UrineRecord(); r.id = row.id; r.petID = pet; r.clumpCount = Int(row.number("clumpCount")); r.size = UrineClumpSize.allCases.first { $0.title == row.string("size") }; r.shape = UrineClumpShape.allCases.first { $0.title == row.string("shape") }; r.eventAt = event; r.note = note; r.restoreImportCreatedAt(created)
                if old == nil { context.insert(r); urine.append(r); report.inserted += 1 } else { report.updated += 1 }
            case "weight":
                let old = weights.first { $0.id == row.id }; if let old { consumedDuplicates.insert(old.id) }; if old != nil && !overwrite { report.skipped += 1; continue }
                if old == nil && consumeDuplicate(weights, id: { $0.id }, matches: { $0.petID == pet && $0.weightKg == row.number("weightKg") && sameMinute($0.eventAt, event) && sameMinute($0.createdAt, created) && ($0.note ?? "") == note }) { report.skipped += 1; continue }
                let r = old ?? WeightRecord(weightKg: row.number("weightKg")); r.id = row.id; r.petID = pet; r.weightKg = row.number("weightKg"); r.eventAt = event; r.note = note; r.restoreImportCreatedAt(created)
                if old == nil { context.insert(r); weights.append(r); report.inserted += 1 } else { report.updated += 1 }
            case "note":
                let old = notes.first { $0.id == row.id } ?? notes.first { $0.petID == pet && Calendar.current.isDate($0.eventAt, inSameDayAs: event) }
                if old != nil && !overwrite { report.skipped += 1; continue }
                let r = old ?? DailyNoteRecord(petID: pet, eventAt: event, text: note); if old == nil { r.id = row.id }
                r.eventAt = event; r.text = note; r.updatedAt = .now; r.restoreImportCreatedAt(created)
                if old == nil { context.insert(r); notes.append(r); report.inserted += 1 } else { report.updated += 1 }
            default: throw ImportError.invalid
            }
        }
        for row in rows where row.kind == "adjustment" {
            guard let bagID = UUID(uuidString: row.string("inventoryID")), bags.contains(where: { $0.id == bagID }) else { throw ImportError.invalid }
            let old = adjustments.first { $0.id == row.id }; if old != nil && !overwrite { report.skipped += 1; continue }
            let r = old ?? InventoryAdjustment(inventoryID: bagID, beforeGram: row.number("beforeGram"), afterGram: row.number("afterGram"))
            r.id = row.id; r.inventoryID = bagID; r.beforeGram = row.number("beforeGram"); r.afterGram = row.number("afterGram"); r.eventAt = try row.date("eventAt"); r.note = row.string("note"); r.restoreImportCreatedAt(try row.date("createdAt"))
            if old == nil { context.insert(r); adjustments.append(r); report.inserted += 1 } else { report.updated += 1 }
        }
        // At most one current batch per pet/category, including independently created batches.
        let current = bags.filter(\.isCurrent)
        let groups = Dictionary(grouping: current, by: { ($0.petID?.uuidString ?? "") + $0.foodKindRaw })
        for list in groups.values where list.count > 1 {
            let sorted = list.sorted { $0.openedAt < $1.openedAt }
            for index in 0..<(sorted.count - 1) { sorted[index].isCurrent = false; sorted[index].closedAt = sorted[index + 1].openedAt }
        }
        do { try context.save() } catch { context.rollback(); throw error }
        return report
    }
}
