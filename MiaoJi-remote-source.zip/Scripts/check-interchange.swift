import Foundation
import SwiftData

@main struct InterchangeCheck {
    enum Failure: Error { case failed(String) }
    @MainActor static func main() throws {
        func check(_ value: Bool, _ name: String) throws { if !value { throw Failure.failed(name) } }
        let schema = Schema([FeedingRecord.self, StoolRecord.self, WeightRecord.self, CatProfile.self, DryFoodInventory.self, InventoryAdjustment.self, DailyNoteRecord.self, UrineRecord.self])
        let source = try ModelContainer(for: schema, configurations: [ModelConfiguration(schema: schema, isStoredInMemoryOnly: true)])
        let pet = CatProfile(name: "互通检查"); source.mainContext.insert(pet)
        let event = Date(timeIntervalSince1970: 1_700_000_000)
        let feeding = FeedingRecord(foodType: .wet, amountGram: 13.5, eventAt: event); feeding.petID = pet.id; feeding.restoreImportCreatedAt(event.addingTimeInterval(3600)); source.mainContext.insert(feeding)
        let second = FeedingRecord(foodType: .wet, amountGram: 13.5, eventAt: event); second.petID = pet.id; second.restoreImportCreatedAt(feeding.createdAt); source.mainContext.insert(second)
        let zero = UrineRecord(clumpCount: 0, size: .small, shape: .flat, eventAt: event); zero.petID = pet.id; source.mainContext.insert(zero)
        let bag = DryFoodInventory(foodName: "测试湿粮", bagTotalGram: 800, openedAt: event.addingTimeInterval(-3600), foodKind: .wet); bag.petID = pet.id; source.mainContext.insert(bag)
        source.mainContext.insert(InventoryAdjustment(inventoryID: bag.id, beforeGram: 773, afterGram: 750, eventAt: event.addingTimeInterval(7200)))
        source.mainContext.insert(DailyNoteRecord(petID: pet.id, eventAt: event, text: "原备注"))
        try source.mainContext.save()
        let bytes = try DataInterchangeService.export(in: source.mainContext)
        let rows = try DataInterchangeService.parse(bytes)
        let destination = try ModelContainer(for: schema, configurations: [ModelConfiguration(schema: schema, isStoredInMemoryOnly: true)])
        _ = try DataInterchangeService.apply(rows, overwrite: false, in: destination.mainContext)
        let feedings = try destination.mainContext.fetch(FetchDescriptor<FeedingRecord>())
        try check(feedings.count == 2, "legitimate identical occurrences")
        try check(feedings.first(where: { $0.id == feeding.id })?.createdAt == feeding.createdAt, "original creation time")
        try check(try destination.mainContext.fetch(FetchDescriptor<UrineRecord>()).first?.clumpCount == 0, "explicit urine zero")
        try check(try destination.mainContext.fetch(FetchDescriptor<DryFoodInventory>()).first?.foodKind == .wet, "wet category")
        _ = try DataInterchangeService.apply(rows, overwrite: false, in: destination.mainContext)
        try check(try destination.mainContext.fetch(FetchDescriptor<FeedingRecord>()).count == 2, "repeat import idempotence")
        feeding.amountGram = 20
        let changed = try DataInterchangeService.parse(DataInterchangeService.export(in: source.mainContext))
        _ = try DataInterchangeService.apply(changed, overwrite: false, in: destination.mainContext)
        try check(feedings.first(where: { $0.id == feeding.id })?.amountGram == 13.5, "default keep local conflict")
        _ = try DataInterchangeService.apply(changed, overwrite: true, in: destination.mainContext)
        try check(feedings.first(where: { $0.id == feeding.id })?.amountGram == 20, "explicit overwrite")
        print("PASS: JSON interchange; identical occurrences; UUID identity; original createdAt; wet inventory and calibration; explicit urine zero; repeated import; conflict keep/overwrite")
    }
}
