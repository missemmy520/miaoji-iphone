import Foundation
import SwiftData

@Model
final class DryFoodInventory {
    @Attribute(.unique) var id: UUID
    var petID: UUID? = nil
    var foodName: String
    var bagTotalGram: Double
    var openedAt: Date
    var closedAt: Date?
    var manualAdjustmentGram: Double
    var isCurrent: Bool

    init(foodName: String, bagTotalGram: Double, openedAt: Date = .now) {
        self.id = UUID()
        self.foodName = foodName
        self.bagTotalGram = bagTotalGram
        self.openedAt = openedAt
        self.closedAt = nil
        self.manualAdjustmentGram = 0
        self.isCurrent = true
    }
}

