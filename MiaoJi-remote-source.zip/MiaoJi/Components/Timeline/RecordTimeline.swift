import SwiftUI

struct TimelineEntry: Identifiable {
    let id: UUID
    let eventAt: Date
    let title: String
    let detail: String
    let value: String
    let color: Color
    let symbol: String

    static func entries(on date: Date, feedings: [FeedingRecord], stools: [StoolRecord], weights: [WeightRecord]) -> [TimelineEntry] {
        let meals = feedings.map {
            TimelineEntry(id: $0.id, eventAt: $0.eventAt, title: $0.foodType.title, detail: $0.note ?? "进食记录",
                          value: $0.amountGram.formatted(.number.precision(.fractionLength(0...1))) + " g",
                          color: $0.foodType.color, symbol: $0.foodType.symbol)
        }
        let toilet = stools.map {
            TimelineEntry(id: $0.id, eventAt: $0.eventAt, title: "排便",
                          detail: [$0.condition?.title, $0.descriptionText, $0.note].compactMap { $0 }.joined(separator: " · "),
                          value: "\($0.count) 次", color: DiaryStyle.amber, symbol: "circle.grid.2x2.fill")
        }
        let weighing = weights.map {
            TimelineEntry(id: $0.id, eventAt: $0.eventAt, title: "体重", detail: $0.note ?? "体重记录",
                          value: $0.weightKg.formatted(.number.precision(.fractionLength(2))) + " kg",
                          color: DiaryStyle.blue, symbol: "scalemass.fill")
        }
        return (meals + toilet + weighing).filter { Calendar.current.isDate($0.eventAt, inSameDayAs: date) }
            .sorted { $0.eventAt == $1.eventAt ? $0.id.uuidString < $1.id.uuidString : $0.eventAt < $1.eventAt }
    }
}

struct RecordTimeline: View {
    let entries: [TimelineEntry]
    var edit: ((UUID) -> Void)? = nil
    var delete: ((UUID) -> Void)? = nil
    var body: some View {
        if entries.isEmpty {
            ContentUnavailableView("这一天还没有记录", systemImage: "pawprint",
                                   description: Text("点击 + 记录宠物的情况，可修改实际时间补录"))
        } else {
            VStack(spacing: 0) {
                ForEach(entries) { entry in
                    HStack(alignment: .top, spacing: 10) {
                        Text(entry.eventAt.formatted(.dateTime.hour().minute()))
                            .font(.caption.monospacedDigit()).foregroundStyle(.secondary)
                            .frame(width: 42).padding(.top, 23)
                        VStack(spacing: 0) {
                            Circle().fill(entry.color).frame(width: 9, height: 9).padding(.top, 26)
                            Rectangle().fill(entry.color.opacity(0.2)).frame(width: 2)
                        }
                        DiaryCard {
                            HStack(spacing: 10) {
                                if let edit {
                                    Button { edit(entry.id) } label: { contents(entry) }.buttonStyle(.plain)
                                } else { contents(entry) }
                                if let edit, let delete {
                                    Menu {
                                        Button("编辑", systemImage: "pencil") { edit(entry.id) }
                                        Button("删除", systemImage: "trash", role: .destructive) { delete(entry.id) }
                                    } label: { Image(systemName: "ellipsis").padding(8) }
                                    .accessibilityLabel("编辑或删除" + entry.title)
                                }
                            }
                        }.padding(.bottom, 10)
                    }.fixedSize(horizontal: false, vertical: true)
                }
            }
        }
    }
    private func contents(_ entry: TimelineEntry) -> some View {
        HStack(spacing: 10) {
            Image(systemName: entry.symbol).foregroundStyle(entry.color)
            VStack(alignment: .leading, spacing: 6) {
                Text(entry.title).font(.headline)
                if !entry.detail.isEmpty { Text(entry.detail).font(.caption).foregroundStyle(.secondary) }
            }
            Spacer(minLength: 0)
            Text(entry.value).font(.subheadline.bold())
        }.frame(maxWidth: .infinity, alignment: .leading).contentShape(Rectangle())
    }
}
