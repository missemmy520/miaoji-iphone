#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$PROJECT_ROOT"
if [[ "$(uname -s)" != "Darwin" ]] || ! command -v xcodebuild >/dev/null 2>&1; then
  echo "A macOS host with Xcode is required; no IPA has been built." >&2
  exit 1
fi

BUILD_ROOT="$PROJECT_ROOT/Build/iPhone"
mkdir -p "$BUILD_ROOT/Output"
SESSION="$(mktemp -d "$BUILD_ROOT/session.XXXXXX")"
APP="$SESSION/DerivedData/Build/Products/Release-iphoneos/MiaoJi.app"
IPA="$BUILD_ROOT/Output/MiaoJi-unsigned.ipa"

xcodebuild -version
xcodebuild \
  -project "$PROJECT_ROOT/MiaoJi.xcodeproj" \
  -scheme MiaoJi \
  -configuration Release \
  -sdk iphoneos \
  -destination 'generic/platform=iOS' \
  -derivedDataPath "$SESSION/DerivedData" \
  -resultBundlePath "$SESSION/BuildResult.xcresult" \
  ARCHS=arm64 ONLY_ACTIVE_ARCH=NO \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY= \
  build 2>&1 | tee "$BUILD_ROOT/build.log"

if [[ ! -f "$APP/MiaoJi" ]] || [[ ! -f "$APP/Info.plist" ]]; then
  echo "Expected device app not found; refusing to package source or simulator output." >&2
  exit 1
fi
xcrun lipo "$APP/MiaoJi" -verify_arch arm64
if [[ -f "$SCRIPT_DIR/check-daily-notes.swift" ]]; then
  xcrun --sdk macosx swiftc -parse-as-library -swift-version 5 \
    MiaoJi/Models/*.swift MiaoJi/Services/DailyNoteService.swift \
    MiaoJi/Services/StatisticsService.swift MiaoJi/Services/ExcelExportService.swift \
    MiaoJi/Utilities/WorkbookZIP.swift "$SCRIPT_DIR/check-daily-notes.swift" \
    -o "$SESSION/check-daily-notes"
  "$SESSION/check-daily-notes" | tee "$BUILD_ROOT/daily-notes-check.log"
fi
xcrun --sdk macosx swiftc -parse-as-library -swift-version 5 -module-name InventoryMigration \
  MiaoJi/Models/FeedingRecord.swift MiaoJi/Models/InventoryAdjustment.swift \
  MiaoJi/Models/RecordTypes.swift "$SCRIPT_DIR/legacy-inventory-fixture.swift" -o "$SESSION/legacy-inventory"
"$SESSION/legacy-inventory" "$SESSION/inventory.store"
xcrun --sdk macosx swiftc -parse-as-library -swift-version 5 -module-name InventoryMigration \
  MiaoJi/Models/*.swift MiaoJi/Services/InventoryService.swift \
  MiaoJi/Services/StatisticsService.swift MiaoJi/Services/HealthKnowledge.swift \
  MiaoJi/Services/HealthAnalysisService.swift MiaoJi/Services/LiteratureSearchService.swift \
  "$SCRIPT_DIR/check-health-inventory.swift" -o "$SESSION/check-health-inventory"
"$SESSION/check-health-inventory" "$SESSION/inventory.store" | tee "$BUILD_ROOT/health-inventory-check.log"
mkdir -p "$SESSION/Payload"
if [[ -f "$SCRIPT_DIR/check-urine.swift" ]]; then
  xcrun --sdk macosx swiftc -parse-as-library -swift-version 5 \
    MiaoJi/Models/*.swift MiaoJi/Services/RecordService.swift \
    MiaoJi/Services/StatisticsService.swift MiaoJi/Services/ExcelExportService.swift \
    MiaoJi/Utilities/RecordInput.swift MiaoJi/Utilities/WorkbookZIP.swift \
    "$SCRIPT_DIR/check-urine.swift" -o "$SESSION/check-urine"
  "$SESSION/check-urine" | tee "$BUILD_ROOT/urine-check.log"
fi
/usr/bin/ditto "$APP" "$SESSION/Payload/MiaoJi.app"
/usr/bin/ditto -c -k --norsrc --noextattr --keepParent "$SESSION/Payload" "$IPA"
python3 "$SCRIPT_DIR/verify-ipa.py" "$IPA"
(cd "$BUILD_ROOT/Output" && shasum -a 256 MiaoJi-unsigned.ipa > MiaoJi-unsigned.ipa.sha256)
echo "Created unsigned device IPA: $IPA"
echo "Re-sign and install locally using your own account. This is not a pre-signed installer."
